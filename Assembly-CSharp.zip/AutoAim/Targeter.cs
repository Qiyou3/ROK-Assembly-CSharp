﻿// Decompiled with JetBrains decompiler
// Type: AutoAim.Targeter
// Assembly: Assembly-CSharp, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 7AE521BE-DDCA-4BB1-9869-8132CF2A08FD
// Assembly location: C:\Users\85206\Desktop\Oxide.ReignOfKings-develop\src\Dependencies\windows\ROK_Data\Managed\Assembly-CSharp.dll

using CodeHatch.AI;
using CodeHatch.Common;
using CodeHatch.Engine.Core.Cache;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using UnityEngine;

#nullable disable
namespace AutoAim
{
  [RequireComponent(typeof (Targetable))]
  [AddComponentMenu("AutoAim/Targeter")]
  public class Targeter : uLink.MonoBehaviour
  {
    public const float COROUTINE_DELAY = 0.25f;
    public string m_targetTag = "enemy";
    public bool m_switchToClosest = true;
    public bool m_switchOnInvalid = true;
    public float distanceFactor = 1f;
    public float heightDifferenceFactor = 5f;
    private Targetable _team;
    [SerializeField]
    private Targetable _target;
    private Vector3 _targetClosest;
    private readonly List<Targetable> _enemyList = new List<Targetable>();
    private Aimer m_aimer;
    private Limiter m_limiter;

    public GameObject Target => this._target.gameObject;

    public bool HasTarget => (Object) this._target != (Object) null;

    public void Start()
    {
      this.m_aimer = this.GetComponent<Aimer>();
      this.m_limiter = this.GetComponent<Limiter>();
      this._team = UnityObjectUtil.SearchComponent<Targetable>(this);
      this.StartCoroutine(this.Targeting());
    }

    public bool IsValidTarget(GameObject target)
    {
      return !(bool) (Object) this.m_limiter || !this.m_limiter.enabled || this.m_limiter.ViableTarget(target.transform.position);
    }

    [DebuggerHidden]
    public IEnumerator Targeting()
    {
      // ISSUE: object of a compiler-generated type is created
      return (IEnumerator) new Targeter.\u003CTargeting\u003Ec__Iterator11B()
      {
        \u003C\u003Ef__this = this
      };
    }

    private Vector3 GetClosest(Targetable target, Vector3 closestTo)
    {
      Rigidbody component = target.Entity.Get<MainRigidbody>().GetComponent<Rigidbody>();
      if ((Object) component != (Object) null)
        return component.ClosestPointOnColliders(closestTo);
      Collider collider = UnityObjectUtil.SearchComponent<Collider>(target.Entity);
      return (Object) collider != (Object) null ? collider.gameObject.ClosestPointOnColliders(closestTo) : target.Entity.gameObject.ClosestPointOnColliders(closestTo);
    }
  }
}
