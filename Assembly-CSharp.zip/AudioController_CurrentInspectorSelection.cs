﻿// Decompiled with JetBrains decompiler
// Type: AudioController_CurrentInspectorSelection
// Assembly: Assembly-CSharp, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 7AE521BE-DDCA-4BB1-9869-8132CF2A08FD
// Assembly location: C:\Users\85206\Desktop\Oxide.ReignOfKings-develop\src\Dependencies\windows\ROK_Data\Managed\Assembly-CSharp.dll

using System;

#nullable disable
[Serializable]
public class AudioController_CurrentInspectorSelection
{
  public int currentCategoryIndex;
  public int currentItemIndex;
  public int currentSubitemIndex;
  public int currentPlaylistIndex;
}
