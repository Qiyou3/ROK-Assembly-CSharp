﻿// Decompiled with JetBrains decompiler
// Type: Assets.CodeHatch.Merica.Scripts.Social.Supplier.Analytics.AnalyticsForm
// Assembly: Assembly-CSharp, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 7AE521BE-DDCA-4BB1-9869-8132CF2A08FD
// Assembly location: C:\Users\85206\Desktop\Oxide.ReignOfKings-develop\src\Dependencies\windows\ROK_Data\Managed\Assembly-CSharp.dll

using System;
using System.Drawing;
using System.Windows.Forms;

#nullable disable
namespace Assets.CodeHatch.Merica.Scripts.Social.Supplier.Analytics
{
  public class AnalyticsForm : Form
  {
    public TreeView displayView;
    public Panel mainPanel;
    private bool innerSet;
    private int yPos;

    public AnalyticsForm() => this.InitializeComponent();

    private void Form1_Load(object sender, EventArgs e)
    {
    }

    private void panel1_Paint(object sender, PaintEventArgs e)
    {
    }

    private void vScrollBar1_Scroll(object sender, ScrollEventArgs e)
    {
    }

    private void treeView1_AfterSelect(object sender, TreeViewEventArgs e)
    {
    }

    private void InitializeComponent()
    {
      this.mainPanel = new Panel();
      this.displayView = new TreeView();
      this.mainPanel.SuspendLayout();
      this.SuspendLayout();
      this.mainPanel.AutoScroll = true;
      this.mainPanel.Controls.Add((Control) this.displayView);
      this.mainPanel.Dock = DockStyle.Fill;
      this.mainPanel.Location = new Point(0, 0);
      this.mainPanel.Name = "mainPanel";
      this.mainPanel.Size = new Size(423, 389);
      this.mainPanel.TabIndex = 0;
      this.mainPanel.Paint += new PaintEventHandler(this.mainPanel_Paint);
      this.mainPanel.Scroll += new ScrollEventHandler(this.OnScroll);
      this.displayView.Dock = DockStyle.Fill;
      this.displayView.Location = new Point(0, 0);
      this.displayView.Name = "displayView";
      this.displayView.Size = new Size(423, 389);
      this.displayView.TabIndex = 0;
      this.displayView.AfterSelect += new TreeViewEventHandler(this.displayView_AfterSelect);
      this.displayView.NodeMouseClick += new TreeNodeMouseClickEventHandler(this.OnNodeClicked);
      this.ClientSize = new Size(423, 389);
      this.Controls.Add((Control) this.mainPanel);
      this.Name = nameof (AnalyticsForm);
      this.TopMost = true;
      this.Load += new EventHandler(this.AnalyticsForm_Load);
      this.FormClosing += new FormClosingEventHandler(this.OnFormClose);
      this.mainPanel.ResumeLayout(false);
      this.ResumeLayout(false);
    }

    private void OnScroll(object sender, ScrollEventArgs e)
    {
      if (this.innerSet)
        return;
      this.yPos = e.NewValue;
    }

    private void AnalyticsForm_Load(object sender, EventArgs e)
    {
    }

    private void OnFormClose(object sender, FormClosingEventArgs e)
    {
      this.Hide();
      e.Cancel = true;
    }

    private void mainPanel_Paint(object sender, PaintEventArgs e)
    {
      this.innerSet = true;
      this.mainPanel.AutoScrollPosition = new Point(this.mainPanel.AutoScrollPosition.X, this.yPos);
      this.innerSet = false;
    }

    private void displayView_AfterSelect(object sender, TreeViewEventArgs e)
    {
    }

    private void OnNodeClicked(object sender, TreeNodeMouseClickEventArgs e)
    {
      if (e.Node != null)
        ;
    }
  }
}
