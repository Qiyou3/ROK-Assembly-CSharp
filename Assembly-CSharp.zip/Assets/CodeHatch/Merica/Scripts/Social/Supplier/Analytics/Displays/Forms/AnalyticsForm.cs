﻿// Decompiled with JetBrains decompiler
// Type: Assets.CodeHatch.Merica.Scripts.Social.Supplier.Analytics.Displays.Forms.AnalyticsForm
// Assembly: Assembly-CSharp, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 7AE521BE-DDCA-4BB1-9869-8132CF2A08FD
// Assembly location: C:\Users\85206\Desktop\Oxide.ReignOfKings-develop\src\Dependencies\windows\ROK_Data\Managed\Assembly-CSharp.dll

using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;

#nullable disable
namespace Assets.CodeHatch.Merica.Scripts.Social.Supplier.Analytics.Displays.Forms
{
  [GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "4.0.0.0")]
  [CompilerGenerated]
  [DebuggerNonUserCode]
  internal class AnalyticsForm
  {
    private static ResourceManager resourceMan;
    private static CultureInfo resourceCulture;

    [SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
    internal AnalyticsForm()
    {
    }

    [EditorBrowsable(EditorBrowsableState.Advanced)]
    internal static ResourceManager ResourceManager
    {
      get
      {
        if (object.ReferenceEquals((object) AnalyticsForm.resourceMan, (object) null))
          AnalyticsForm.resourceMan = new ResourceManager("Assets.CodeHatch.Merica.Scripts.Social.Supplier.Analytics.Displays.Forms.AnalyticsForm", typeof (AnalyticsForm).Assembly);
        return AnalyticsForm.resourceMan;
      }
    }

    [EditorBrowsable(EditorBrowsableState.Advanced)]
    internal static CultureInfo Culture
    {
      get => AnalyticsForm.resourceCulture;
      set => AnalyticsForm.resourceCulture = value;
    }
  }
}
