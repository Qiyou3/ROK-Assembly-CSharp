﻿// Decompiled with JetBrains decompiler
// Type: Assets.CodeHatch.Engine.Core.Utility.ListDictionary`2
// Assembly: Assembly-CSharp, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 7AE521BE-DDCA-4BB1-9869-8132CF2A08FD
// Assembly location: C:\Users\85206\Desktop\Oxide.ReignOfKings-develop\src\Dependencies\windows\ROK_Data\Managed\Assembly-CSharp.dll

using CodeHatch.Common;
using System.Collections;
using System.Collections.Generic;

#nullable disable
namespace Assets.CodeHatch.Engine.Core.Utility
{
  public class ListDictionary<TKey, TValue> : 
    IEnumerable,
    IEnumerable<KeyValuePair<TKey, List<TValue>>>
  {
    private readonly Dictionary<TKey, List<TValue>> _dictionaryOfLists = new Dictionary<TKey, List<TValue>>();

    IEnumerator IEnumerable.GetEnumerator() => (IEnumerator) this.GetEnumerator();

    public List<TValue> GetList(TKey key)
    {
      List<TValue> list;
      this._dictionaryOfLists.TryGetValue(key, out list);
      if (list == null)
      {
        list = new List<TValue>();
        this._dictionaryOfLists[key] = list;
      }
      return list;
    }

    public void Add(TKey key, TValue value) => this.GetList(key).Add(value);

    public void AddDistinct(TKey key, TValue value) => this.GetList(key).AddDistinct<TValue>(value);

    public void Remove(TKey key, TValue value) => this.GetList(key).Remove(value);

    public void Clear(TKey key) => this.GetList(key).Clear();

    public void Clear() => this._dictionaryOfLists.Clear();

    public IEnumerator<KeyValuePair<TKey, List<TValue>>> GetEnumerator()
    {
      return (IEnumerator<KeyValuePair<TKey, List<TValue>>>) this._dictionaryOfLists.GetEnumerator();
    }
  }
}
