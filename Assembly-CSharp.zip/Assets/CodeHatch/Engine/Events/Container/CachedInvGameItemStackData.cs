﻿// Decompiled with JetBrains decompiler
// Type: Assets.CodeHatch.Engine.Events.Container.CachedInvGameItemStackData
// Assembly: Assembly-CSharp, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 7AE521BE-DDCA-4BB1-9869-8132CF2A08FD
// Assembly location: C:\Users\85206\Desktop\Oxide.ReignOfKings-develop\src\Dependencies\windows\ROK_Data\Managed\Assembly-CSharp.dll

using CodeHatch.Engine.Events.Instantiation;
using CodeHatch.Engine.Modules.Inventory.Equipment;
using CodeHatch.Engine.Networking;
using CodeHatch.Inventory.Blueprints;
using CodeHatch.Inventory.Equipment;
using CodeHatch.Networking.Events;
using System.Linq;
using UnityEngine;

#nullable disable
namespace Assets.CodeHatch.Engine.Events.Container
{
  public class CachedInvGameItemStackData
  {
    internal CachedInvGameItemStackData(InvGameItemStack stack)
    {
      if (stack != null && (Object) stack.Blueprint != (Object) null)
      {
        ulong num1 = ItemCache.Instance.GetServerGuid(stack);
        if (num1 == 0UL && Player.IsLocalServer)
          num1 = ItemCache.Instance.AddServer(stack);
        ulong num2 = ItemCache.Instance.GetClientGuid(Player.Local.Id, stack);
        if (num1 == 0UL && num2 == 0UL && !Player.IsLocalServer)
          num2 = ItemCache.Instance.AddClient(Player.Local.Id, stack);
        this.ServerGuid = num1;
        this.LocalGuid = num2;
        this.Blueprint = stack.Blueprint;
        this.Amount = stack.StackAmount;
        this.Components = stack.Components.Values.ToArray<StackComponent>();
        this.IsProcedural = stack is InvProceduralWeaponStack;
        this.ProceduralParts = !(stack is InvProceduralWeaponStack) ? (ProceduralWeaponFactory.Part[]) null : (stack as InvProceduralWeaponStack).build.build.Parts.ToArray<ProceduralWeaponFactory.Part>();
      }
      else
      {
        this.ServerGuid = 0UL;
        this.LocalGuid = 0UL;
        this.Blueprint = (InvItemBlueprint) null;
        this.Amount = 0;
        this.Components = (StackComponent[]) null;
        this.IsProcedural = false;
        this.ProceduralParts = (ProceduralWeaponFactory.Part[]) null;
      }
    }

    internal CachedInvGameItemStackData(
      ulong serverGuid,
      ulong localGuid,
      InvItemBlueprint blueprint,
      int stackAmount,
      StackComponent[] components,
      bool isProcedural,
      ProceduralWeaponFactory.Part[] parts)
    {
      this.ServerGuid = serverGuid;
      this.LocalGuid = localGuid;
      this.Blueprint = blueprint;
      this.Amount = stackAmount;
      this.Components = components;
      this.IsProcedural = isProcedural;
      this.ProceduralParts = parts;
    }

    internal ulong ServerGuid { get; private set; }

    internal ulong LocalGuid { get; private set; }

    internal InvItemBlueprint Blueprint { get; private set; }

    internal int Amount { get; private set; }

    internal StackComponent[] Components { get; private set; }

    internal bool IsProcedural { get; private set; }

    internal ProceduralWeaponFactory.Part[] ProceduralParts { get; private set; }

    internal InvGameItemStack GetStack(ulong senderId)
    {
      if ((Object) this.Blueprint == (Object) null)
        return (InvGameItemStack) null;
      InvGameItemStack stack = (InvGameItemStack) null;
      if (this.LocalGuid != 0UL && (Player.IsLocalServer || (long) Player.Local.Id == (long) senderId))
      {
        stack = ItemCache.Instance.GetClientStack(senderId, this.LocalGuid);
        ulong guid = 0;
        if (Player.IsLocalServer && stack != null && ItemCache.Instance.TryGetServerGuid(stack, out guid))
          this.ServerGuid = guid;
      }
      if (this.ServerGuid != 0UL && stack == null)
        stack = ItemCache.Instance.GetServerStack(senderId, this.ServerGuid);
      if (stack == null)
      {
        if (this.IsProcedural)
        {
          ProceduralWeaponFactory.Build build = new ProceduralWeaponFactory.Build();
          for (int index = 0; index < this.ProceduralParts.Length; ++index)
            build.AddPart(this.ProceduralParts[index]);
          stack = (InvGameItemStack) new InvProceduralWeaponStack(this.Blueprint, this.Amount, (BlueprintInstance) null, new ProceduralWeaponNetworking.NetworkedBuild(build));
        }
        else
          stack = new InvGameItemStack(this.Blueprint, this.Amount, (BlueprintInstance) null);
        stack.AddComponents(this.Components ?? new StackComponent[0]);
        if (Player.IsLocalServer)
        {
          ulong serverStackGuid = ItemCache.Instance.AddServer(stack);
          this.ServerGuid = serverStackGuid;
          ItemCache.Instance.AddClient(senderId, this.LocalGuid, stack);
          if ((long) senderId != (long) Player.Local.Id)
          {
            ItemStackSetGuidEvent theEvent = new ItemStackSetGuidEvent(serverStackGuid, this.LocalGuid);
            theEvent.Recipients.Clear();
            theEvent.Recipients.Add(CodeHatch.Engine.Networking.Server.GetPlayerById(senderId));
            EventManager.CallEvent((BaseEvent) theEvent);
          }
        }
        else if (this.ServerGuid != 0UL)
          ItemCache.Instance.AddServer(this.ServerGuid, stack);
        else if (this.LocalGuid != 0UL)
        {
          long num = (long) ItemCache.Instance.AddClient(Player.Local.Id, stack);
        }
      }
      return stack;
    }

    public static void ToBitStream(IStream stream, CachedInvGameItemStackData ItemData)
    {
      stream.WriteBoolean(ItemData != null);
      if (ItemData == null)
        return;
      stream.WriteUInt64(ItemData.ServerGuid);
      stream.WriteUInt64(ItemData.LocalGuid);
      stream.Write<InvItemBlueprint>(ItemData.Blueprint);
      stream.WriteInt32(ItemData.Amount);
      if (ItemData.Components == null)
      {
        stream.WriteInt32(0);
      }
      else
      {
        stream.WriteInt32(ItemData.Components.Length);
        for (int index = 0; index < ItemData.Components.Length; ++index)
          stream.Write<StackComponent>(ItemData.Components[index]);
      }
      stream.WriteBoolean(ItemData.IsProcedural);
      if (!ItemData.IsProcedural)
        return;
      stream.WriteInt32(ItemData.ProceduralParts.Length);
      for (int index = 0; index < ItemData.ProceduralParts.Length; ++index)
      {
        ProceduralWeaponFactory.Part proceduralPart = ItemData.ProceduralParts[index];
        stream.WriteInt32((int) proceduralPart.partDefinition.type);
        stream.Write<Vector3>(proceduralPart.position);
        stream.Write<Quaternion>(proceduralPart.rotation);
      }
    }

    public static CachedInvGameItemStackData FromBitStream(IStream stream)
    {
      if (!stream.ReadBoolean())
        return new CachedInvGameItemStackData((InvGameItemStack) null);
      ulong serverGuid = stream.ReadUInt64();
      ulong localGuid = stream.ReadUInt64();
      InvItemBlueprint blueprint = stream.Read<InvItemBlueprint>();
      int stackAmount = stream.ReadInt32();
      StackComponent[] components = (StackComponent[]) null;
      int length1 = stream.ReadInt32();
      if (length1 != 0)
      {
        components = new StackComponent[length1];
        for (int index = 0; index < components.Length; ++index)
          components[index] = stream.Read<StackComponent>();
      }
      bool isProcedural = stream.ReadBoolean();
      ProceduralWeaponFactory.Part[] parts = (ProceduralWeaponFactory.Part[]) null;
      if (isProcedural)
      {
        int length2 = stream.ReadInt32();
        parts = new ProceduralWeaponFactory.Part[length2];
        for (int partIndex = 0; partIndex < length2; ++partIndex)
        {
          int partID = stream.ReadInt32();
          Vector3 vector3 = stream.Read<Vector3>();
          Quaternion quaternion = stream.Read<Quaternion>();
          ProceduralWeaponFactory.Part part = new ProceduralWeaponFactory.Part(partIndex, ProceduralWeaponDefinitions.GetPartDefinition(partID));
          part = part with
          {
            position = vector3,
            rotation = quaternion
          };
          parts[partIndex] = part;
        }
      }
      return new CachedInvGameItemStackData(serverGuid, localGuid, blueprint, stackAmount, components, isProcedural, parts);
    }
  }
}
