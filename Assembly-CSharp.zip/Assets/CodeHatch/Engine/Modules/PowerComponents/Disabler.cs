﻿// Decompiled with JetBrains decompiler
// Type: Assets.CodeHatch.Engine.Modules.PowerComponents.Disabler
// Assembly: Assembly-CSharp, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 7AE521BE-DDCA-4BB1-9869-8132CF2A08FD
// Assembly location: C:\Users\85206\Desktop\Oxide.ReignOfKings-develop\src\Dependencies\windows\ROK_Data\Managed\Assembly-CSharp.dll

using CodeHatch.Engine.Behaviours;
using CodeHatch.Engine.Core.Cache;
using UnityEngine;

#nullable disable
namespace Assets.CodeHatch.Engine.Modules.PowerComponents
{
  public class Disabler : EntityBehaviour, IDisableable
  {
    public GameObject[] disableableObjects;
    public MonoBehaviour[] disableableScripts;

    public void Enable()
    {
      this.IsDisabled = false;
      this.DisableEnable(true);
    }

    public bool IsDisabled { get; private set; }

    public void Disable()
    {
      this.IsDisabled = true;
      this.DisableEnable(false);
    }

    private void DisableEnable(bool State)
    {
      foreach (GameObject disableableObject in this.disableableObjects)
        disableableObject.SetActive(State);
      foreach (Behaviour disableableScript in this.disableableScripts)
        disableableScript.enabled = State;
    }
  }
}
