﻿// Decompiled with JetBrains decompiler
// Type: Assets.CodeHatch.Engine.Modules.PowerComponents.PowerSoundEmitter
// Assembly: Assembly-CSharp, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 7AE521BE-DDCA-4BB1-9869-8132CF2A08FD
// Assembly location: C:\Users\85206\Desktop\Oxide.ReignOfKings-develop\src\Dependencies\windows\ROK_Data\Managed\Assembly-CSharp.dll

using CodeHatch.Engine.Behaviours;
using CodeHatch.Engine.Core.Cache;
using CodeHatch.Engine.Modules.Power;

#nullable disable
namespace Assets.CodeHatch.Engine.Modules.PowerComponents
{
  public class PowerSoundEmitter : EntityBehaviour, IDisableable, IPowerAware
  {
    public string powerOnSound;
    public string powerOffSound;
    public bool playPowerOnOnCreate;

    public bool IsDisabled { get; private set; }

    public void Start()
    {
      if (!this.playPowerOnOnCreate)
        return;
      this.PlaySound(this.powerOnSound);
    }

    public void OnPoweredStateChanged(bool poweredOn)
    {
      if (poweredOn && this.powerOnSound != string.Empty)
      {
        this.PlaySound(this.powerOnSound);
      }
      else
      {
        if (this.powerOffSound == null)
          return;
        this.PlaySound(this.powerOffSound);
      }
    }

    private void PlaySound(string SoundID)
    {
      AudioController.Play(SoundID, this.Entity.MainTransform);
    }

    public void Enable()
    {
      this.IsDisabled = false;
      this.PlaySound(this.powerOnSound);
    }

    public void Disable()
    {
      this.IsDisabled = true;
      this.PlaySound(this.powerOffSound);
    }
  }
}
