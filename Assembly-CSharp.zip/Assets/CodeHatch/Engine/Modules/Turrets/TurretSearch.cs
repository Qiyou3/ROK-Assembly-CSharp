﻿// Decompiled with JetBrains decompiler
// Type: Assets.CodeHatch.Engine.Modules.Turrets.TurretSearch
// Assembly: Assembly-CSharp, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 7AE521BE-DDCA-4BB1-9869-8132CF2A08FD
// Assembly location: C:\Users\85206\Desktop\Oxide.ReignOfKings-develop\src\Dependencies\windows\ROK_Data\Managed\Assembly-CSharp.dll

using CodeHatch.AI;
using CodeHatch.Engine.Core.Cache;
using UnityEngine;

#nullable disable
namespace Assets.CodeHatch.Engine.Modules.Turrets
{
  public class TurretSearch : EntityBehaviour
  {
    public Transform verticalSwivel;
    public Transform horizontalSwivel;
    public float HorizontalDegrees = 90f;
    public float VerticalDegrees = 30f;
    public float RotationSpeed = 5f;
    private TurretSearch.Directions _directionH;
    private TurretSearch.Directions _directionV;

    public void Update()
    {
      AIBridge aiBridge = this.Entity.TryGet<AIBridge>();
      if (!((Object) aiBridge == (Object) null) && !((Object) aiBridge.CurrentTarget == (Object) null))
        return;
      this.UpdateDirection();
      this.RotateComponents();
    }

    private void UpdateDirection()
    {
      float num = Time.deltaTime * this.RotationSpeed;
      float h = Mathf.Abs(this.horizontalSwivel.localEulerAngles.y);
      if ((double) h > 180.0)
        h = (float) -(360.0 - (double) h);
      float v = Mathf.Abs(this.verticalSwivel.localEulerAngles.x);
      if ((double) v > 180.0)
        v = (float) -(360.0 - (double) v);
      if (this._directionH == TurretSearch.Directions.Positive)
      {
        if ((double) h <= (double) this.HorizontalDegrees / 2.0)
          return;
        this._directionH = TurretSearch.Directions.Stop;
        this.ResolveV(v);
      }
      else if (this._directionH == TurretSearch.Directions.Negative)
      {
        if ((double) h >= -(double) this.HorizontalDegrees / 2.0)
          return;
        this._directionH = TurretSearch.Directions.Stop;
        this.ResolveV(v);
      }
      else if (this._directionV == TurretSearch.Directions.Positive)
      {
        if (((double) v <= 0.0 || (double) v - (double) num >= 0.0) && (double) v <= (double) this.VerticalDegrees / 2.0)
          return;
        this._directionV = TurretSearch.Directions.Stop;
        this.ResolveH(h);
      }
      else if (this._directionV == TurretSearch.Directions.Negative)
      {
        if (((double) v >= 0.0 || (double) v + (double) num <= 0.0) && (double) v >= -(double) this.VerticalDegrees / 2.0)
          return;
        this._directionV = TurretSearch.Directions.Stop;
        this.ResolveH(h);
      }
      else
      {
        this.ResolveH(h);
        if (this._directionH != TurretSearch.Directions.Stop)
          return;
        this.ResolveV(v);
      }
    }

    private void ResolveH(float h)
    {
      if ((double) h > 0.0)
        this._directionH = TurretSearch.Directions.Negative;
      else if ((double) h < 0.0)
        this._directionH = TurretSearch.Directions.Positive;
      else
        this._directionH = (TurretSearch.Directions) Random.Range(-1, 1);
    }

    private void ResolveV(float v)
    {
      if ((double) v > 0.0)
      {
        if ((double) v > (double) this.VerticalDegrees / 2.0)
          this._directionV = TurretSearch.Directions.Negative;
        else
          this._directionV = TurretSearch.Directions.Positive;
      }
      else if ((double) v < 0.0)
      {
        if ((double) v < -(double) this.VerticalDegrees / 2.0)
          this._directionV = TurretSearch.Directions.Positive;
        else
          this._directionV = TurretSearch.Directions.Negative;
      }
      else
        this._directionV = (TurretSearch.Directions) Random.Range(-1, 1);
    }

    private void RotateComponents()
    {
      float num = Time.deltaTime * this.RotationSpeed;
      this.horizontalSwivel.localEulerAngles += new Vector3(0.0f, num * (float) this._directionH, 0.0f);
      this.verticalSwivel.localEulerAngles += new Vector3(num * (float) this._directionV, 0.0f, 0.0f);
    }

    private enum Directions
    {
      Negative = -1, // 0xFFFFFFFF
      Stop = 0,
      Positive = 1,
    }
  }
}
