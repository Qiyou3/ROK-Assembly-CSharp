﻿// Decompiled with JetBrains decompiler
// Type: Assets.CodeHatch.Engine.Modules.Inventory.Holdable.PlaySoundOnEquip
// Assembly: Assembly-CSharp, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 7AE521BE-DDCA-4BB1-9869-8132CF2A08FD
// Assembly location: C:\Users\85206\Desktop\Oxide.ReignOfKings-develop\src\Dependencies\windows\ROK_Data\Managed\Assembly-CSharp.dll

using CodeHatch.Engine.Core.Cache;

#nullable disable
namespace Assets.CodeHatch.Engine.Modules.Inventory.Holdable
{
  public class PlaySoundOnEquip : EntityBehaviour, IActiveSwitchListener
  {
    public string soundToPlay;
    private bool playSound;

    public void OnItemSwitch(InvGameItemStack currentStack)
    {
      if (!this.Entity.IsLocallyOwned)
        return;
      this.playSound = true;
    }

    public void Update()
    {
      if (!this.playSound)
        return;
      AudioController.Play(this.soundToPlay, this.transform);
      this.playSound = false;
    }
  }
}
