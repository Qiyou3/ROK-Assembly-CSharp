﻿// Decompiled with JetBrains decompiler
// Type: Assets.CodeHatch.Engine.Behaviours.User_Interface.RepositionGridOnEnable
// Assembly: Assembly-CSharp, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 7AE521BE-DDCA-4BB1-9869-8132CF2A08FD
// Assembly location: C:\Users\85206\Desktop\Oxide.ReignOfKings-develop\src\Dependencies\windows\ROK_Data\Managed\Assembly-CSharp.dll

using CodeHatch.Engine.Core.Utility.Attributes;
using UnityEngine;

#nullable disable
namespace Assets.CodeHatch.Engine.Behaviours.User_Interface
{
  public class RepositionGridOnEnable : MonoBehaviour
  {
    [CanBeNull]
    public UIGrid Grid;
    private bool _reposition;

    public void OnEnable()
    {
      if ((Object) this.Grid == (Object) null)
        this.Grid = this.GetComponentInParent<UIGrid>();
      this._reposition = true;
    }

    public void Update()
    {
      if (!((Object) this.Grid != (Object) null) || !this._reposition)
        return;
      this._reposition = false;
      this.Grid.Reposition();
    }
  }
}
