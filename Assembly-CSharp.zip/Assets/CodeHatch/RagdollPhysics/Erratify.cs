﻿// Decompiled with JetBrains decompiler
// Type: Assets.CodeHatch.RagdollPhysics.Erratify
// Assembly: Assembly-CSharp, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 7AE521BE-DDCA-4BB1-9869-8132CF2A08FD
// Assembly location: C:\Users\85206\Desktop\Oxide.ReignOfKings-develop\src\Dependencies\windows\ROK_Data\Managed\Assembly-CSharp.dll

using CodeHatch.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

#nullable disable
namespace Assets.CodeHatch.RagdollPhysics
{
  public class Erratify : MonoBehaviour
  {
    private Vector3 _randomVector;
    public Rigidbody[] load;
    public Rigidbody[] feet;
    public float blend;
    public float force;
    public float smoothingTime = 0.5f;
    private float _loadMass;
    private float _feetMass;

    public void Start()
    {
      if (this.load == null || this.load.Length == 0)
        this.load = ((IEnumerable<Rigidbody>) this.GetComponentsInChildren<Rigidbody>()).Where<Rigidbody>((Func<Rigidbody, bool>) (r => !r.isKinematic && !this.feet.Contains<Rigidbody>(r))).ToArray<Rigidbody>();
      foreach (Rigidbody rigidbody in this.load)
        this._loadMass += rigidbody.mass;
      foreach (Rigidbody foot in this.feet)
        this._feetMass += foot.mass;
    }

    public void FixedUpdate()
    {
      this._randomVector = Vector3.Lerp(this._randomVector, UnityEngine.Random.insideUnitSphere, HalfLife.GetRate(this.smoothingTime));
      Vector3 vector = this._randomVector * (this.force * this.blend);
      if (!vector.IsValid())
        return;
      for (int index = 0; index < this.load.Length; ++index)
      {
        Rigidbody rigidbody = this.load[index];
        rigidbody.AddForce(vector * (rigidbody.mass / this._loadMass));
      }
      for (int index = 0; index < this.feet.Length; ++index)
      {
        Rigidbody foot = this.feet[index];
        foot.AddForce(vector * (float) -((double) foot.mass / (double) this._feetMass));
      }
    }
  }
}
