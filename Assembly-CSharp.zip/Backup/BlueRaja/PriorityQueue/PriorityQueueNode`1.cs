﻿// Decompiled with JetBrains decompiler
// Type: BlueRaja.PriorityQueue.PriorityQueueNode`1
// Assembly: Assembly-CSharp, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 7AE521BE-DDCA-4BB1-9869-8132CF2A08FD
// Assembly location: C:\Users\85206\Desktop\Oxide.ReignOfKings-develop\src\Dependencies\windows\ROK_Data\Managed\Assembly-CSharp.dll

#nullable disable
namespace BlueRaja.PriorityQueue
{
  public class PriorityQueueNode<T>
  {
    public T value;

    public PriorityQueueNode(T value) => this.value = value;

    public double Priority { get; set; }

    public long InsertionIndex { get; set; }

    public int QueueIndex { get; set; }
  }
}
