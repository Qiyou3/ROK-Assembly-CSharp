﻿// Decompiled with JetBrains decompiler
// Type: BlueRaja.PriorityQueue.HeapPriorityQueue`1
// Assembly: Assembly-CSharp, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 7AE521BE-DDCA-4BB1-9869-8132CF2A08FD
// Assembly location: C:\Users\85206\Desktop\Oxide.ReignOfKings-develop\src\Dependencies\windows\ROK_Data\Managed\Assembly-CSharp.dll

using System.Collections.Generic;
using System.Diagnostics;

#nullable disable
namespace BlueRaja.PriorityQueue
{
  public sealed class HeapPriorityQueue<T>
  {
    private int _numNodes;
    private readonly PriorityQueueNode<T>[] _nodes;
    private long _numNodesEverEnqueued;

    public HeapPriorityQueue(int maxNodes)
    {
      this._numNodes = 0;
      this._nodes = new PriorityQueueNode<T>[maxNodes + 1];
      this._numNodesEverEnqueued = 0L;
    }

    public int Count => this._numNodes;

    public int MaxSize => this._nodes.Length - 1;

    public void Clear()
    {
      for (int index = 1; index < this._nodes.Length; ++index)
        this._nodes[index] = (PriorityQueueNode<T>) null;
      this._numNodes = 0;
    }

    public bool Contains(PriorityQueueNode<T> node) => this._nodes[node.QueueIndex] == node;

    public PriorityQueueNode<T> Enqueue(T value, double priority)
    {
      if (this._numNodes >= this._nodes.Length - 1)
        return (PriorityQueueNode<T>) null;
      PriorityQueueNode<T> priorityQueueNode = new PriorityQueueNode<T>(value);
      priorityQueueNode.Priority = priority;
      ++this._numNodes;
      this._nodes[this._numNodes] = priorityQueueNode;
      priorityQueueNode.QueueIndex = this._numNodes;
      priorityQueueNode.InsertionIndex = this._numNodesEverEnqueued++;
      this.CascadeUp(this._nodes[this._numNodes]);
      return priorityQueueNode;
    }

    private void Swap(PriorityQueueNode<T> node1, PriorityQueueNode<T> node2)
    {
      this._nodes[node1.QueueIndex] = node2;
      this._nodes[node2.QueueIndex] = node1;
      int queueIndex = node1.QueueIndex;
      node1.QueueIndex = node2.QueueIndex;
      node2.QueueIndex = queueIndex;
    }

    private void CascadeUp(PriorityQueueNode<T> node)
    {
      for (int index = node.QueueIndex / 2; index >= 1; index = node.QueueIndex / 2)
      {
        PriorityQueueNode<T> node1 = this._nodes[index];
        if (this.HasHigherPriority(node1, node))
          break;
        this.Swap(node, node1);
      }
    }

    private void CascadeDown(PriorityQueueNode<T> node)
    {
      int index1 = node.QueueIndex;
      while (true)
      {
        PriorityQueueNode<T> lower = node;
        int index2 = 2 * index1;
        if (index2 <= this._numNodes)
        {
          PriorityQueueNode<T> node1 = this._nodes[index2];
          if (this.HasHigherPriority(node1, lower))
            lower = node1;
          int index3 = index2 + 1;
          if (index3 <= this._numNodes)
          {
            PriorityQueueNode<T> node2 = this._nodes[index3];
            if (this.HasHigherPriority(node2, lower))
              lower = node2;
          }
          if (lower != node)
          {
            this._nodes[index1] = lower;
            int queueIndex = lower.QueueIndex;
            lower.QueueIndex = index1;
            index1 = queueIndex;
          }
          else
            goto label_10;
        }
        else
          break;
      }
      node.QueueIndex = index1;
      this._nodes[index1] = node;
      return;
label_10:
      node.QueueIndex = index1;
      this._nodes[index1] = node;
    }

    private bool HasHigherPriority(PriorityQueueNode<T> higher, PriorityQueueNode<T> lower)
    {
      if (higher == null || lower == null)
        return false;
      if (higher.Priority < lower.Priority)
        return true;
      return higher.Priority == lower.Priority && higher.InsertionIndex < lower.InsertionIndex;
    }

    public T Dequeue()
    {
      PriorityQueueNode<T> node = this._nodes[1];
      this.Remove(node);
      return node == null ? default (T) : node.value;
    }

    public PriorityQueueNode<T> First => this._nodes[1];

    public void UpdatePriority(PriorityQueueNode<T> node, double priority)
    {
      node.Priority = priority;
      this.OnNodeUpdated(node);
    }

    private void OnNodeUpdated(PriorityQueueNode<T> node)
    {
      int index = node.QueueIndex / 2;
      PriorityQueueNode<T> node1 = this._nodes[index];
      if (index > 0 && this.HasHigherPriority(node, node1))
        this.CascadeUp(node);
      else
        this.CascadeDown(node);
    }

    public void Remove(PriorityQueueNode<T> node)
    {
      if (this._numNodes <= 1)
      {
        this._nodes[1] = (PriorityQueueNode<T>) null;
        this._numNodes = 0;
      }
      else
      {
        bool flag = false;
        PriorityQueueNode<T> node1 = this._nodes[this._numNodes];
        if (node.QueueIndex != this._numNodes)
        {
          this.Swap(node, node1);
          flag = true;
        }
        --this._numNodes;
        this._nodes[node.QueueIndex] = (PriorityQueueNode<T>) null;
        if (!flag)
          return;
        this.OnNodeUpdated(node1);
      }
    }

    [DebuggerHidden]
    public IEnumerator<PriorityQueueNode<T>> GetEnumerator()
    {
      // ISSUE: object of a compiler-generated type is created
      return (IEnumerator<PriorityQueueNode<T>>) new HeapPriorityQueue<T>.\u003CGetEnumerator\u003Ec__IteratorED()
      {
        \u003C\u003Ef__this = this
      };
    }

    public bool IsValidQueue()
    {
      for (int index1 = 1; index1 < this._nodes.Length; ++index1)
      {
        if (this._nodes[index1] != null)
        {
          int index2 = 2 * index1;
          if (index2 < this._nodes.Length && this._nodes[index2] != null && this.HasHigherPriority(this._nodes[index2], this._nodes[index1]))
            return false;
          int index3 = index2 + 1;
          if (index3 < this._nodes.Length && this._nodes[index3] != null && this.HasHigherPriority(this._nodes[index3], this._nodes[index1]))
            return false;
        }
      }
      return true;
    }
  }
}
