﻿// Decompiled with JetBrains decompiler
// Type: CodeHatch.AnimatorUtilEx
// Assembly: Assembly-CSharp, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 7AE521BE-DDCA-4BB1-9869-8132CF2A08FD
// Assembly location: C:\Users\85206\Desktop\Oxide.ReignOfKings-develop\src\Dependencies\windows\ROK_Data\Managed\Assembly-CSharp.dll

using System;
using UnityEngine;

#nullable disable
namespace CodeHatch
{
  public static class AnimatorUtilEx
  {
    public static Transform GetHandTransform(this Animator animator, Side hand)
    {
      switch (hand)
      {
        case Side.Left:
          return animator.GetBoneTransform(HumanBodyBones.LeftHand);
        case Side.Right:
          return animator.GetBoneTransform(HumanBodyBones.RightHand);
        default:
          throw new ArgumentOutOfRangeException(nameof (hand));
      }
    }

    public static Transform GetShoulderTransform(this Animator animator, Side hand)
    {
      switch (hand)
      {
        case Side.Left:
          return animator.GetBoneTransform(HumanBodyBones.LeftShoulder);
        case Side.Right:
          return animator.GetBoneTransform(HumanBodyBones.RightShoulder);
        default:
          throw new ArgumentOutOfRangeException(nameof (hand));
      }
    }

    public static Transform GetUpperArmTransform(this Animator animator, Side side)
    {
      switch (side)
      {
        case Side.Left:
          return animator.GetBoneTransform(HumanBodyBones.LeftUpperArm);
        case Side.Right:
          return animator.GetBoneTransform(HumanBodyBones.RightUpperArm);
        default:
          throw new ArgumentOutOfRangeException(nameof (side));
      }
    }

    public static Transform GetLowerArmTransform(this Animator animator, Side side)
    {
      switch (side)
      {
        case Side.Left:
          return animator.GetBoneTransform(HumanBodyBones.LeftLowerArm);
        case Side.Right:
          return animator.GetBoneTransform(HumanBodyBones.RightLowerArm);
        default:
          throw new ArgumentOutOfRangeException(nameof (side));
      }
    }

    public static Transform GetUpperLegTransform(this Animator animator, Side side)
    {
      switch (side)
      {
        case Side.Left:
          return animator.GetBoneTransform(HumanBodyBones.LeftUpperLeg);
        case Side.Right:
          return animator.GetBoneTransform(HumanBodyBones.RightUpperLeg);
        default:
          throw new ArgumentOutOfRangeException(nameof (side));
      }
    }

    public static Transform GetLowerLegTransform(this Animator animator, Side side)
    {
      switch (side)
      {
        case Side.Left:
          return animator.GetBoneTransform(HumanBodyBones.LeftLowerLeg);
        case Side.Right:
          return animator.GetBoneTransform(HumanBodyBones.RightLowerLeg);
        default:
          throw new ArgumentOutOfRangeException(nameof (side));
      }
    }

    public static Transform GetFootTransform(this Animator animator, Side side)
    {
      switch (side)
      {
        case Side.Left:
          return animator.GetBoneTransform(HumanBodyBones.LeftFoot);
        case Side.Right:
          return animator.GetBoneTransform(HumanBodyBones.RightFoot);
        default:
          throw new ArgumentOutOfRangeException(nameof (side));
      }
    }

    public static Transform GetToesTransform(this Animator animator, Side side)
    {
      switch (side)
      {
        case Side.Left:
          return animator.GetBoneTransform(HumanBodyBones.LeftToes);
        case Side.Right:
          return animator.GetBoneTransform(HumanBodyBones.RightToes);
        default:
          throw new ArgumentOutOfRangeException(nameof (side));
      }
    }

    public static Transform GetArmTwistBone(this Animator animator, Side side)
    {
      Transform lowerArmTransform = animator.GetLowerArmTransform(side);
      for (int index = 0; index < lowerArmTransform.childCount; ++index)
      {
        Transform child = lowerArmTransform.GetChild(index);
        if (child.name.Contains("wist"))
          return child;
      }
      return (Transform) null;
    }

    public static void SetFootIKPosition(
      this AnimatorBehaviourManager manager,
      Side foot,
      Vector3 position)
    {
      switch (foot)
      {
        case Side.Left:
          manager.SetIKPosition(AvatarIKGoal.LeftFoot, position);
          break;
        case Side.Right:
          manager.SetIKPosition(AvatarIKGoal.RightFoot, position);
          break;
        default:
          throw new ArgumentOutOfRangeException(nameof (foot));
      }
    }

    public static void SetFootIKRotation(
      this AnimatorBehaviourManager manager,
      Side foot,
      Quaternion rotation)
    {
      switch (foot)
      {
        case Side.Left:
          manager.SetIKRotation(AvatarIKGoal.LeftFoot, rotation);
          break;
        case Side.Right:
          manager.SetIKRotation(AvatarIKGoal.RightFoot, rotation);
          break;
        default:
          throw new ArgumentOutOfRangeException(nameof (foot));
      }
    }

    public static void SetFootIKOrientation(
      this AnimatorBehaviourManager manager,
      Side foot,
      Orientation orientation)
    {
      manager.SetHandIKPosition(foot, orientation.Position);
      manager.SetHandIKRotation(foot, orientation.Rotation);
    }
  }
}
