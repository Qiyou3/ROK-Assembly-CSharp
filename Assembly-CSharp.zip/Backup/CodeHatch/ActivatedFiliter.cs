﻿// Decompiled with JetBrains decompiler
// Type: CodeHatch.ActivatedFiliter
// Assembly: Assembly-CSharp, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 7AE521BE-DDCA-4BB1-9869-8132CF2A08FD
// Assembly location: C:\Users\85206\Desktop\Oxide.ReignOfKings-develop\src\Dependencies\windows\ROK_Data\Managed\Assembly-CSharp.dll

using CodeHatch.Common;
using CodeHatch.Engine.Core.Paging;
using CodeHatch.Engine.Networking;
using CodeHatch.Engine.Serialization;

#nullable disable
namespace CodeHatch
{
  public class ActivatedFiliter : LocationFilter, ISerializable
  {
    public CodeHatch.Engine.Core.Triggers.Trigger Activator;
    private bool _isActivated;

    public override bool IsPageable() => this._isActivated;

    public void Awake()
    {
      if ((UnityEngine.Object) this.Activator == (UnityEngine.Object) null)
      {
        this.Activator = this.GetComponent<CodeHatch.Engine.Core.Triggers.Trigger>();
        if ((UnityEngine.Object) this.Activator == (UnityEngine.Object) null)
        {
          this.LogError<ActivatedFiliter>("Activated Pageable is missing a trigger: {0}.", (object) this.Entity.name);
          return;
        }
      }
      this.Activator.Activate += new System.Action(this.OnActivate);
    }

    public void OnDespawned() => this._isActivated = false;

    public void OnDestroy() => this.Activator.Activate -= new System.Action(this.OnActivate);

    private void OnActivate()
    {
      this._isActivated = true;
      if ((UnityEngine.Object) this.Parent == (UnityEngine.Object) null)
      {
        this.Parent = this.gameObject.GetComponent<PageLocatable>();
        this.Parent.SetToDefault();
      }
      this.Parent.ReEvaluatePageable();
      this.Parent.UpdateRegistry(true);
    }

    public override void GetLocation(ref Vector3Int position)
    {
      if (!this._isActivated)
        this.LogError<ActivatedFiliter>("Activated Pageable is trying to be sorted when not activated: {0}.", (object) this.Entity.name);
      else
        position = this.GetLocation(this.Entity.MainTransform);
    }

    public string Identifier => "ActivatedPage";

    public void Serialize(IStream stream) => stream.WriteBoolean(this._isActivated);

    public void Deserialize(IStream stream)
    {
      if (!stream.ReadBoolean())
        return;
      this.OnActivate();
    }
  }
}
