﻿// Decompiled with JetBrains decompiler
// Type: CodeHatch.ArmorSounds
// Assembly: Assembly-CSharp, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 7AE521BE-DDCA-4BB1-9869-8132CF2A08FD
// Assembly location: C:\Users\85206\Desktop\Oxide.ReignOfKings-develop\src\Dependencies\windows\ROK_Data\Managed\Assembly-CSharp.dll

using CodeHatch.Engine.Core.Cache;
using CodeHatch.Engine.Networking;
using CodeHatch.Inventory.Blueprints.Components;
using System;
using UnityEngine;

#nullable disable
namespace CodeHatch
{
  [RequireComponent(typeof (ArmorManager))]
  public class ArmorSounds : EntityBehaviour
  {
    public string Equip;
    [Range(0.0f, 1f)]
    public float EquipVolume = 1f;

    public void Start()
    {
      if (Player.IsLocalDedi || !this.Entity.IsLocalPlayer)
        UnityEngine.Object.Destroy((UnityEngine.Object) this);
      else
        this.GetComponent<ArmorManager>().OnArmorApplied += new Action<ArmorBlueprint.Slot, ArmorBlueprint>(this.OnArmorApplied);
    }

    private void OnArmorApplied(ArmorBlueprint.Slot slot, ArmorBlueprint blueprint)
    {
      if (!((UnityEngine.Object) blueprint != (UnityEngine.Object) null) || string.IsNullOrEmpty(this.Equip) || (double) this.EquipVolume <= 0.0)
        return;
      AudioController.Play(this.Equip, this.EquipVolume, 0.0f, 0.0f);
    }
  }
}
