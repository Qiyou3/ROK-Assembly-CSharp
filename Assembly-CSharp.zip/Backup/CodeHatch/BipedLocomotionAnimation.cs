﻿// Decompiled with JetBrains decompiler
// Type: CodeHatch.BipedLocomotionAnimation
// Assembly: Assembly-CSharp, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 7AE521BE-DDCA-4BB1-9869-8132CF2A08FD
// Assembly location: C:\Users\85206\Desktop\Oxide.ReignOfKings-develop\src\Dependencies\windows\ROK_Data\Managed\Assembly-CSharp.dll

using UnityEngine;

#nullable disable
namespace CodeHatch
{
  public class BipedLocomotionAnimation : ScriptableObject
  {
    public RuntimeAnimatorController Controller;
    public int LocomotionStateID;
    public int LocomotionStateLayerIndex;
    public string VelocityXParameterName = "Velocity X";
    public string VelocityZParameterName = "Velocity Z";
    public float AnimationBlendSmoothingTime = 0.05f;
    public float LegOffsetSmoothingTime = 0.1f;
    public BipedAnimator.Limits HeadTranslationLimits = new BipedAnimator.Limits();
    public Vector3 BaseOffset;
    public BipedAnimator.LookWeights LookWeights = new BipedAnimator.LookWeights();
    public float TorsoRotation;
  }
}
