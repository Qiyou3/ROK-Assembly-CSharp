﻿// Decompiled with JetBrains decompiler
// Type: CodeHatch.Analytics.FPSTracker
// Assembly: Assembly-CSharp, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 7AE521BE-DDCA-4BB1-9869-8132CF2A08FD
// Assembly location: C:\Users\85206\Desktop\Oxide.ReignOfKings-develop\src\Dependencies\windows\ROK_Data\Managed\Assembly-CSharp.dll

using System;
using System.Collections;
using System.Diagnostics;
using UnityEngine;

#nullable disable
namespace CodeHatch.Analytics
{
  public class FPSTracker : BaseAnalyticTracker
  {
    private float _min = float.MinValue;
    private float _max = float.MaxValue;
    private float _accum;
    private uint _frames;

    public override void Inititalize()
    {
    }

    public override void ServerUpdate()
    {
      this._accum += Time.timeScale / Time.deltaTime;
      this._min = Mathf.Max(this._min, Time.deltaTime);
      this._max = Mathf.Min(this._max, Time.deltaTime);
      ++this._frames;
    }

    public override void OnBeforeSend()
    {
      float num1 = this._accum / (float) this._frames;
      float num2 = Time.timeScale / this._min;
      float num3 = Time.timeScale / this._max;
      AnalyticManager.SetValue<float>("FPS", num1, "FPS");
      AnalyticManager.SetValue<float>("Max", num3, "FPS");
      AnalyticManager.SetValue<float>("Min", num2, "FPS");
      this._accum = 0.0f;
      this._frames = 0U;
      this._min = float.MinValue;
      this._max = float.MaxValue;
    }

    public override void Dispose()
    {
    }

    [DebuggerHidden]
    public override IEnumerator DumpTo(Action<string> writeToFile)
    {
      // ISSUE: object of a compiler-generated type is created
      return (IEnumerator) new FPSTracker.\u003CDumpTo\u003Ec__Iterator1A3()
      {
        writeToFile = writeToFile,
        \u003C\u0024\u003EwriteToFile = writeToFile,
        \u003C\u003Ef__this = this
      };
    }
  }
}
