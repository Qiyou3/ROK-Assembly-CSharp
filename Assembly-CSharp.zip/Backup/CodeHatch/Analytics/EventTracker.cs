﻿// Decompiled with JetBrains decompiler
// Type: CodeHatch.Analytics.EventTracker
// Assembly: Assembly-CSharp, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 7AE521BE-DDCA-4BB1-9869-8132CF2A08FD
// Assembly location: C:\Users\85206\Desktop\Oxide.ReignOfKings-develop\src\Dependencies\windows\ROK_Data\Managed\Assembly-CSharp.dll

using CodeHatch.Common;
using CodeHatch.Networking.Events;
using CodeHatch.Networking.Sync;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using UnityEngine;

#nullable disable
namespace CodeHatch.Analytics
{
  public class EventTracker : BaseAnalyticTracker
  {
    [SerializeField]
    private int _keepCount = 10;
    private int _prevEventSendCount;
    private int _prevEventRecieveCount;
    private int _prevSimpleSendCount;
    private int _prevSimpleRecieveCount;
    private List<Type> _topBase;
    private List<string> _simpleSend;
    private List<string> _simpleReceive;
    private List<Type> _topNetworkSend;
    private List<Type> _topNetworkReceive;
    private IterableDictionary<Type, int> _networkSendCounts;
    private IterableDictionary<Type, int> _networkSendReliableCounts;
    private IterableDictionary<Type, int> _networkSendUnreliableCounts;
    private IterableDictionary<Type, int> _networkReceiveCounts;
    private IterableDictionary<string, int> _simpleReceiveCounts;
    private IterableDictionary<string, int> _simpleSendCounts;
    private IterableDictionary<string, int> _simpleSendReliableCounts;
    private IterableDictionary<string, int> _simpleSendUnreliableCounts;
    private IterableDictionary<Type, int> _baseCounts;
    private List<Type> _topNetworkFrameSend;
    private List<Type> _topNetworkFrameReceive;
    private IterableDictionary<Type, int> _frameNetworkSendCounts;
    private IterableDictionary<Type, int> _frameNetworkSendReliableCounts;
    private IterableDictionary<Type, int> _frameNetworkSendUnreliableCounts;
    private IterableDictionary<Type, int> _frameNetworkReceiveCounts;
    private bool _subscribed;

    public override void Inititalize()
    {
    }

    public override void OnEnable()
    {
      base.OnEnable();
      this.SubscribeEvents();
    }

    public override void OnDisable()
    {
      base.OnDisable();
      this.UnsubscribeEvents();
      this._simpleReceive = (List<string>) null;
      this._simpleSend = (List<string>) null;
      this._topNetworkSend = (List<Type>) null;
      this._topNetworkReceive = (List<Type>) null;
      this._networkSendCounts = (IterableDictionary<Type, int>) null;
      this._networkSendReliableCounts = (IterableDictionary<Type, int>) null;
      this._networkSendUnreliableCounts = (IterableDictionary<Type, int>) null;
      this._networkReceiveCounts = (IterableDictionary<Type, int>) null;
      this._simpleReceiveCounts = (IterableDictionary<string, int>) null;
      this._simpleSendCounts = (IterableDictionary<string, int>) null;
      this._simpleSendReliableCounts = (IterableDictionary<string, int>) null;
      this._simpleSendUnreliableCounts = (IterableDictionary<string, int>) null;
      this._baseCounts = (IterableDictionary<Type, int>) null;
      this._topBase = (List<Type>) null;
      this._frameNetworkReceiveCounts = (IterableDictionary<Type, int>) null;
      this._frameNetworkSendCounts = (IterableDictionary<Type, int>) null;
      this._frameNetworkSendReliableCounts = (IterableDictionary<Type, int>) null;
      this._frameNetworkSendUnreliableCounts = (IterableDictionary<Type, int>) null;
    }

    private void OnBaseEvent(BaseEvent theEvent)
    {
      if (this._baseCounts == null)
        this._baseCounts = new IterableDictionary<Type, int>();
      if (this._topBase == null)
        this._topBase = new List<Type>();
      this.AlterCount<Type>(theEvent.GetType(), this._baseCounts, this._topBase);
    }

    private void OnSimpleReceive(string theEvent, SimpleEventArgs args)
    {
      if (this._simpleReceiveCounts == null)
        this._simpleReceiveCounts = new IterableDictionary<string, int>();
      if (this._simpleReceive == null)
        this._simpleReceive = new List<string>();
      this.AlterCount<string>(theEvent, this._simpleReceiveCounts, this._simpleReceive);
    }

    private void OnSimpleSend(string theEvent, SimpleEventArgs args)
    {
      if (this._simpleSendCounts == null)
        this._simpleSendCounts = new IterableDictionary<string, int>();
      if (this._simpleSendReliableCounts == null)
        this._simpleSendReliableCounts = new IterableDictionary<string, int>();
      if (this._simpleSendUnreliableCounts == null)
        this._simpleSendUnreliableCounts = new IterableDictionary<string, int>();
      if (this._simpleSend == null)
        this._simpleSend = new List<string>();
      this.AlterCount<string>(theEvent, this._simpleSendCounts, this._simpleSend);
      if (args.IsReliable)
        this.AlterCount<string>(theEvent, this._simpleSendReliableCounts, this._simpleSend);
      else
        this.AlterCount<string>(theEvent, this._simpleSendUnreliableCounts, this._simpleSend);
    }

    private void OnNetworkReceive(NetworkEvent theEvent)
    {
      if (this._networkReceiveCounts == null)
        this._networkReceiveCounts = new IterableDictionary<Type, int>((IEqualityComparer<Type>) new TypeComparer());
      if (this._topNetworkReceive == null)
        this._topNetworkReceive = new List<Type>();
      this.AlterCount<Type>(theEvent.GetType(), this._networkReceiveCounts, this._topNetworkReceive);
      if (this._topNetworkFrameReceive == null)
        this._topNetworkFrameReceive = new List<Type>();
      if (this._frameNetworkReceiveCounts == null)
        this._frameNetworkReceiveCounts = new IterableDictionary<Type, int>((IEqualityComparer<Type>) new TypeComparer());
      this.AlterCount<Type>(theEvent.GetType(), this._frameNetworkReceiveCounts, this._topNetworkFrameReceive);
    }

    private void OnNetworkSend(NetworkEvent theEvent)
    {
      Type type = theEvent.GetType();
      if (this._networkSendCounts == null)
        this._networkSendCounts = new IterableDictionary<Type, int>((IEqualityComparer<Type>) new TypeComparer());
      if (this._networkSendReliableCounts == null)
        this._networkSendReliableCounts = new IterableDictionary<Type, int>((IEqualityComparer<Type>) new TypeComparer());
      if (this._networkSendUnreliableCounts == null)
        this._networkSendUnreliableCounts = new IterableDictionary<Type, int>((IEqualityComparer<Type>) new TypeComparer());
      if (this._topNetworkSend == null)
        this._topNetworkSend = new List<Type>();
      this.AlterCount<Type>(type, this._networkSendCounts, this._topNetworkSend);
      if (theEvent.IsReliable)
        this.AlterCount<Type>(type, this._networkSendReliableCounts, this._topNetworkSend);
      else
        this.AlterCount<Type>(type, this._networkSendUnreliableCounts, this._topNetworkSend);
      if (this._topNetworkFrameSend == null)
        this._topNetworkFrameSend = new List<Type>();
      if (this._frameNetworkSendCounts == null)
        this._frameNetworkSendCounts = new IterableDictionary<Type, int>((IEqualityComparer<Type>) new TypeComparer());
      if (this._frameNetworkSendReliableCounts == null)
        this._frameNetworkSendReliableCounts = new IterableDictionary<Type, int>((IEqualityComparer<Type>) new TypeComparer());
      if (this._frameNetworkSendUnreliableCounts == null)
        this._frameNetworkSendUnreliableCounts = new IterableDictionary<Type, int>((IEqualityComparer<Type>) new TypeComparer());
      this.AlterCount<Type>(type, this._frameNetworkSendCounts, this._topNetworkFrameSend);
      if (theEvent.IsReliable)
        this.AlterCount<Type>(type, this._frameNetworkSendReliableCounts, this._topNetworkFrameSend);
      else
        this.AlterCount<Type>(type, this._frameNetworkSendUnreliableCounts, this._topNetworkFrameSend);
    }

    private void SubscribeEvents()
    {
      if (this._subscribed)
        return;
      this._subscribed = true;
      EventManager.NetworkEventSend += new Action<NetworkEvent>(this.OnNetworkSend);
      EventManager.NetworkEventRecieve += new Action<NetworkEvent>(this.OnNetworkReceive);
      EventManager.SimpleEventSend += new Action<string, SimpleEventArgs>(this.OnSimpleSend);
      EventManager.SimpleEventReceive += new Action<string, SimpleEventArgs>(this.OnSimpleReceive);
      EventManager.BaseEventAction += new Action<BaseEvent>(this.OnBaseEvent);
    }

    private void UnsubscribeEvents()
    {
      if (!this._subscribed)
        return;
      this._subscribed = false;
      EventManager.NetworkEventSend -= new Action<NetworkEvent>(this.OnNetworkSend);
      EventManager.NetworkEventRecieve -= new Action<NetworkEvent>(this.OnNetworkReceive);
      EventManager.SimpleEventSend -= new Action<string, SimpleEventArgs>(this.OnSimpleSend);
      EventManager.SimpleEventReceive -= new Action<string, SimpleEventArgs>(this.OnSimpleReceive);
      EventManager.BaseEventAction -= new Action<BaseEvent>(this.OnBaseEvent);
    }

    private void AlterCount<T>(T theType, IterableDictionary<T, int> counts, List<T> types)
    {
      int num1;
      int num2 = counts.TryGetValue(theType, out num1) ? num1 + 1 : 1;
      counts[theType] = num2;
      if (types.Contains(theType))
        return;
      types.Add(theType);
      types.Sort((Comparison<T>) ((a, b) =>
      {
        int num3;
        int num4;
        if (!counts.TryGetValue(a, out num3) || !counts.TryGetValue(b, out num4) || num3 == num4)
          return 0;
        return num3 < num4 ? -1 : 1;
      }));
      if (types.Count <= this._keepCount)
        return;
      types.RemoveAt(0);
    }

    public override void ServerUpdate()
    {
    }

    public override void OnBeforeSend()
    {
      AnalyticManager.SetValue<ulong>("Sync Send", SyncManager.SentSyncCount, "Sync Manager");
      AnalyticManager.SetValue<ulong>("Sync Send (Reliable)", SyncManager.SentSyncReliableCount, "Sync Manager");
      AnalyticManager.SetValue<ulong>("Sync Send (Unreliable)", SyncManager.SentSyncUnreliableCount, "Sync Manager");
      AnalyticManager.SetValue<ulong>("Sync Receive", SyncManager.ReceivedSyncCount, "Sync Manager");
      AnalyticManager.SetValue<ulong>("Network Send", EventManager.NetworkEventSendCount, "Network Events");
      AnalyticManager.SetValue<ulong>("Network Send (Reliable)", EventManager.NetworkEventSendReliableCount, "Network Events");
      AnalyticManager.SetValue<ulong>("Network Send (Unreliable)", EventManager.NetworkEventSendUnreliableCount, "Network Events");
      AnalyticManager.SetValue<ulong>("Network Receive", EventManager.NetworkEventReceiveCount, "Network Events");
      AnalyticManager.SetValue<ulong>("Simple Send", EventManager.SimpleEventSendCount, "Simple Events");
      AnalyticManager.SetValue<ulong>("Simple Send (Reliable)", EventManager.SimpleEventSendReliableCount, "Simple Events");
      AnalyticManager.SetValue<ulong>("Simple Send (Unreliable", EventManager.SimpleEventSendUnreliableCount, "Simple Events");
      AnalyticManager.SetValue<ulong>("Simple Receive", EventManager.SimpleEventReceiveCount, "Simple Events");
      if (this._topNetworkSend != null)
      {
        for (int index = 0; index < this._topNetworkSend.Count; ++index)
        {
          Type key = this._topNetworkSend[index];
          AnalyticManager.SetValue<int>("%s" + key.Name, this.TryGet<Type, int>((IDictionary<Type, int>) this._networkSendCounts, key), "Network Event Send Counts");
          AnalyticManager.SetValue<int>("%s" + key.Name, this.TryGet<Type, int>((IDictionary<Type, int>) this._networkSendReliableCounts, key), "Network Event Send Counts (Reliable)");
          AnalyticManager.SetValue<int>("%s" + key.Name, this.TryGet<Type, int>((IDictionary<Type, int>) this._networkSendUnreliableCounts, key), "Network Event Send Counts (Unreliable)");
        }
      }
      if (this._topNetworkFrameSend != null)
      {
        for (int index = 0; index < this._topNetworkFrameSend.Count; ++index)
        {
          Type key = this._topNetworkFrameSend[index];
          AnalyticManager.SetValue<int>("%s" + key.Name, this.TryGet<Type, int>((IDictionary<Type, int>) this._frameNetworkSendCounts, key), "Network Event Send Differences");
          AnalyticManager.SetValue<int>("%s" + key.Name, this.TryGet<Type, int>((IDictionary<Type, int>) this._frameNetworkSendReliableCounts, key), "Network Event Send Differences (Reliable)");
          AnalyticManager.SetValue<int>("%s" + key.Name, this.TryGet<Type, int>((IDictionary<Type, int>) this._frameNetworkSendUnreliableCounts, key), "Network Event Send Differences (Unreliable)");
        }
        this._topNetworkFrameSend.Clear();
        this._frameNetworkSendCounts.Clear();
        this._frameNetworkSendReliableCounts.Clear();
        this._frameNetworkSendUnreliableCounts.Clear();
      }
      if (this._topNetworkReceive != null)
      {
        for (int index = 0; index < this._topNetworkReceive.Count; ++index)
        {
          Type key = this._topNetworkReceive[index];
          AnalyticManager.SetValue<int>("%s" + key.Name, this.TryGet<Type, int>((IDictionary<Type, int>) this._networkReceiveCounts, key), "Network Event Receive Counts");
        }
      }
      if (this._topNetworkFrameReceive != null)
      {
        for (int index = 0; index < this._topNetworkFrameReceive.Count; ++index)
        {
          Type key = this._topNetworkFrameReceive[index];
          AnalyticManager.SetValue<int>("%s" + key.Name, this.TryGet<Type, int>((IDictionary<Type, int>) this._frameNetworkReceiveCounts, key), "Network Event Receive Differences");
        }
        this._topNetworkFrameReceive.Clear();
        this._frameNetworkReceiveCounts.Clear();
      }
      if (this._simpleSend != null)
      {
        for (int index = 0; index < this._simpleSend.Count; ++index)
        {
          string key = this._simpleSend[index];
          AnalyticManager.SetValue<int>("%s" + key, this.TryGet<string, int>((IDictionary<string, int>) this._simpleSendCounts, key), "Simple Event Send Counts");
          AnalyticManager.SetValue<int>("%s" + key, this.TryGet<string, int>((IDictionary<string, int>) this._simpleSendReliableCounts, key), "Simple Event Send Counts (Reliable)");
          AnalyticManager.SetValue<int>("%s" + key, this.TryGet<string, int>((IDictionary<string, int>) this._simpleSendUnreliableCounts, key), "Simple Event Send Counts (Unreliable)");
        }
      }
      if (this._simpleReceive != null)
      {
        for (int index = 0; index < this._simpleReceive.Count; ++index)
        {
          string key = this._simpleReceive[index];
          AnalyticManager.SetValue<int>("%s" + key, this.TryGet<string, int>((IDictionary<string, int>) this._simpleReceiveCounts, key), "Simple Event Receive Counts");
        }
      }
      if (this._topBase == null)
        return;
      for (int index = 0; index < this._topBase.Count; ++index)
      {
        Type key = this._topBase[index];
        AnalyticManager.SetValue<int>("%s" + key.Name, this.TryGet<Type, int>((IDictionary<Type, int>) this._baseCounts, key), "Base Events");
      }
    }

    private TVal TryGet<TKey, TVal>(IDictionary<TKey, TVal> dictionary, TKey key)
    {
      TVal val;
      dictionary.TryGetValue(key, out val);
      return val;
    }

    public override void Dispose()
    {
    }

    [DebuggerHidden]
    private IEnumerator WriteToFile<T>(
      Action<string> writeToFile,
      IterableDictionary<T, int> counts,
      string title,
      List<EventTracker.CompareData> datas)
    {
      // ISSUE: object of a compiler-generated type is created
      return (IEnumerator) new EventTracker.\u003CWriteToFile\u003Ec__Iterator1A1<T>()
      {
        writeToFile = writeToFile,
        title = title,
        datas = datas,
        counts = counts,
        \u003C\u0024\u003EwriteToFile = writeToFile,
        \u003C\u0024\u003Etitle = title,
        \u003C\u0024\u003Edatas = datas,
        \u003C\u0024\u003Ecounts = counts
      };
    }

    [DebuggerHidden]
    public override IEnumerator DumpTo(Action<string> writeToFile)
    {
      // ISSUE: object of a compiler-generated type is created
      return (IEnumerator) new EventTracker.\u003CDumpTo\u003Ec__Iterator1A2()
      {
        writeToFile = writeToFile,
        \u003C\u0024\u003EwriteToFile = writeToFile,
        \u003C\u003Ef__this = this
      };
    }

    private class CompareData : IComparable<EventTracker.CompareData>
    {
      private int _count;
      private string _name;

      public int CompareTo(EventTracker.CompareData other)
      {
        return -1 * this._count.CompareTo(other._count);
      }

      public static EventTracker.CompareData CreateData<T>(IterableDictionary<T, int>.Entry pair)
      {
        return new EventTracker.CompareData()
        {
          _count = pair.Value,
          _name = pair.Key.ToString()
        };
      }

      public override string ToString() => this._name + " " + (object) this._count;
    }
  }
}
