﻿// Decompiled with JetBrains decompiler
// Type: CodeHatch.Analytics.USpeakTracker
// Assembly: Assembly-CSharp, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 7AE521BE-DDCA-4BB1-9869-8132CF2A08FD
// Assembly location: C:\Users\85206\Desktop\Oxide.ReignOfKings-develop\src\Dependencies\windows\ROK_Data\Managed\Assembly-CSharp.dll

using CodeHatch.Engine.Core.Audio;
using System;
using System.Collections;
using System.Diagnostics;
using UnityEngine;

#nullable disable
namespace CodeHatch.Analytics
{
  public class USpeakTracker : BaseAnalyticTracker
  {
    private const string CATEGORY = "USpeak";
    private const string AVERAGE = "Average Bytes";
    private const string TOTAL = "Total Bytes";
    private const string MAX = "Max";
    private int _countThisSend;
    private int _totalSent;
    private int _maxAmount;

    public override void Inititalize()
    {
    }

    public override void OnEnable()
    {
      base.OnEnable();
      DediBitStreamUSpeakHandler.OnStreamReceive += new Action<int>(this.OnUSpeak);
    }

    public override void OnDisable()
    {
      base.OnDisable();
      DediBitStreamUSpeakHandler.OnStreamReceive -= new Action<int>(this.OnUSpeak);
    }

    public override void ServerUpdate()
    {
    }

    public override void OnBeforeSend()
    {
      if (this._countThisSend == 0)
        return;
      AnalyticManager.SetValue<int>("Average Bytes", this._totalSent / this._countThisSend, "USpeak");
      AnalyticManager.SetValue<int>("Total Bytes", this._totalSent, "USpeak");
      AnalyticManager.SetValue<int>("Max", this._maxAmount, "USpeak");
      this._countThisSend = 0;
      this._totalSent = 0;
      this._maxAmount = int.MinValue;
    }

    public override void Dispose()
    {
    }

    private void OnUSpeak(int byteCount)
    {
      try
      {
        ++this._countThisSend;
        this._totalSent += byteCount;
        this._maxAmount = Mathf.Max(byteCount, this._maxAmount);
      }
      catch (Exception ex)
      {
        this.LogException<USpeakTracker>(ex);
      }
    }

    [DebuggerHidden]
    public override IEnumerator DumpTo(Action<string> writeToFile)
    {
      // ISSUE: object of a compiler-generated type is created
      // ISSUE: variable of a compiler-generated type
      USpeakTracker.\u003CDumpTo\u003Ec__Iterator19D dumpToCIterator19D = new USpeakTracker.\u003CDumpTo\u003Ec__Iterator19D();
      return (IEnumerator) dumpToCIterator19D;
    }
  }
}
