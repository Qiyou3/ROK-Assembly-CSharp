﻿// Decompiled with JetBrains decompiler
// Type: CodeHatch.Analytics.FPSDisplay
// Assembly: Assembly-CSharp, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 7AE521BE-DDCA-4BB1-9869-8132CF2A08FD
// Assembly location: C:\Users\85206\Desktop\Oxide.ReignOfKings-develop\src\Dependencies\windows\ROK_Data\Managed\Assembly-CSharp.dll

using System;
using System.Windows.Forms;
using UnityEngine;

#nullable disable
namespace CodeHatch.Analytics
{
  public class FPSDisplay : CategoryDisplay
  {
    private const string FPS_LABEL = "FPS: {0}";
    private const string MIN_LABEL = "Min: {0}";
    private const string MAX_LABEL = "Max: {0}";
    private const string MAX_OVER_LABEL = "Max Overall: {0}";
    private const string MIN_OVER_LABEL = "Min Overall: {0}";
    private float _fps;
    private float _minFps;
    private float _maxFps;
    private float _maxOverallFPS = float.MinValue;
    private float _minOverallFPS = float.MaxValue;

    public override string Category => "FPS";

    public override void OnDoTree(DisplayInfo info, TreeView view)
    {
      info.SetValue<float>(this._maxOverallFPS, "Max Overall");
      info.SetValue<float>(this._minOverallFPS, "Min Overall");
      base.OnDoTree(info, view);
    }

    public override void OnSimple(DisplayInfo info)
    {
      if (info != null)
      {
        info.GetValue<float>("FPS", out this._fps);
        info.GetValue<float>("Min", out this._minFps);
        info.GetValue<float>("Max", out this._maxFps);
        if ((double) this._minFps >= 0.0)
          this._minOverallFPS = Math.Min(this._minOverallFPS, this._minFps);
        this._maxOverallFPS = Math.Max(this._maxOverallFPS, this._maxFps);
      }
      GUILayout.BeginHorizontal();
      GUILayout.Label(string.Format("FPS: {0}", (object) this._fps), GUILayout.ExpandWidth(false));
      GUILayout.EndHorizontal();
      GUILayout.BeginHorizontal();
      GUILayout.Label(string.Format("Max: {0}", (object) this._maxFps), GUILayout.ExpandWidth(false));
      GUILayout.EndHorizontal();
      GUILayout.BeginHorizontal();
      GUILayout.Label(string.Format("Min: {0}", (object) this._minFps), GUILayout.ExpandWidth(false));
      GUILayout.EndHorizontal();
      GUILayout.BeginHorizontal();
      GUILayout.Label(string.Format("Max Overall: {0}", (object) this._maxOverallFPS), GUILayout.ExpandWidth(false));
      GUILayout.EndHorizontal();
      GUILayout.BeginHorizontal();
      GUILayout.Label(string.Format("Min Overall: {0}", (object) this._minOverallFPS), GUILayout.ExpandWidth(false));
      GUILayout.EndHorizontal();
    }
  }
}
