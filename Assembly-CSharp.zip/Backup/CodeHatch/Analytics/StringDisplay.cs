﻿// Decompiled with JetBrains decompiler
// Type: CodeHatch.Analytics.StringDisplay
// Assembly: Assembly-CSharp, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 7AE521BE-DDCA-4BB1-9869-8132CF2A08FD
// Assembly location: C:\Users\85206\Desktop\Oxide.ReignOfKings-develop\src\Dependencies\windows\ROK_Data\Managed\Assembly-CSharp.dll

using CodeHatch.Engine.Networking;

#nullable disable
namespace CodeHatch.Analytics
{
  public class StringDisplay : ConverterBase<string>
  {
    public override byte Id => 5;

    public override IConverter CreateClone() => (IConverter) new StringDisplay();

    protected override void WriteValue(IStream stream, string value) => stream.WriteString(value);

    protected override string ReadValue(IStream stream) => stream.ReadString();
  }
}
