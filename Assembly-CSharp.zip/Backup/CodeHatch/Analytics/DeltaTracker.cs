﻿// Decompiled with JetBrains decompiler
// Type: CodeHatch.Analytics.DeltaTracker
// Assembly: Assembly-CSharp, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 7AE521BE-DDCA-4BB1-9869-8132CF2A08FD
// Assembly location: C:\Users\85206\Desktop\Oxide.ReignOfKings-develop\src\Dependencies\windows\ROK_Data\Managed\Assembly-CSharp.dll

using CodeHatch.Common;
using CodeHatch.Engine;
using JetBrains.Annotations;
using System;
using System.Collections;
using System.Diagnostics;
using UnityEngine;

#nullable disable
namespace CodeHatch.Analytics
{
  public class DeltaTracker : BaseAnalyticTracker
  {
    public const string CATEGORY = "Delta Times Per Second";
    private static string _sampleTitle;
    private static readonly Stopwatch _stopwatch = new Stopwatch();
    private static int _prevFrameCount;
    private static double _prevFrameTime;
    private static readonly IterableDictionary<string, double> _deltaTotals = new IterableDictionary<string, double>();
    private static readonly IterableDictionary<string, double> _maxDeltas = new IterableDictionary<string, double>();

    [StringFormatMethod("title")]
    [Conditional("DELTA_TRACKER")]
    public static void SetFrameDeltaTime(double deltaSeconds, string title, object obj1)
    {
      title = string.Format(title, obj1);
    }

    [Conditional("DELTA_TRACKER")]
    [StringFormatMethod("title")]
    public static void SetFrameDeltaTime(
      double deltaSeconds,
      string title,
      object obj1,
      object obj2)
    {
      title = string.Format(title, obj1, obj2);
    }

    [StringFormatMethod("title")]
    [Conditional("DELTA_TRACKER")]
    public static void SetFrameDeltaTime(
      double deltaSeconds,
      string title,
      object obj1,
      object obj2,
      object obj3)
    {
      title = string.Format(title, obj1, obj2, obj3);
    }

    [Conditional("DELTA_TRACKER")]
    public static void SetFrameDeltaTime(double deltaSeconds, string title)
    {
      double num1;
      if (DeltaTracker._deltaTotals.TryGetValue(title, out num1))
      {
        double num2;
        DeltaTracker._maxDeltas.TryGetValue(title, out num2);
        if (deltaSeconds > num2)
          DeltaTracker._maxDeltas[title] = deltaSeconds;
      }
      else
        DeltaTracker._maxDeltas[title] = deltaSeconds;
      DeltaTracker._deltaTotals[title] = num1 + deltaSeconds;
    }

    [StringFormatMethod("title")]
    [Conditional("DELTA_TRACKER")]
    public static void BeginSample(string title, object obj1) => title = string.Format(title, obj1);

    [StringFormatMethod("title")]
    [Conditional("DELTA_TRACKER")]
    public static void BeginSample(double deltaSeconds, string title, object obj1, object obj2)
    {
      title = string.Format(title, obj1, obj2);
    }

    [StringFormatMethod("title")]
    [Conditional("DELTA_TRACKER")]
    public static void BeginSample(
      double deltaSeconds,
      string title,
      object obj1,
      object obj2,
      object obj3)
    {
      title = string.Format(title, obj1, obj2, obj3);
    }

    [Conditional("DELTA_TRACKER")]
    public static void BeginSample(string title)
    {
      DeltaTracker._sampleTitle = title;
      DeltaTracker._stopwatch.Reset();
      DeltaTracker._stopwatch.Start();
    }

    [Conditional("DELTA_TRACKER")]
    public static void EndSample()
    {
      if (DeltaTracker._sampleTitle == null)
        return;
      DeltaTracker._stopwatch.Stop();
      DeltaTracker._sampleTitle = (string) null;
    }

    public override void Inititalize()
    {
      DeltaTracker._prevFrameCount = Time.frameCount;
      DeltaTracker._prevFrameTime = SafeTime.AppTime;
    }

    public override void ServerUpdate()
    {
    }

    public override void OnBeforeSend()
    {
      double appTime = SafeTime.AppTime;
      int frameCount = Time.frameCount;
      int num1 = frameCount - DeltaTracker._prevFrameCount;
      DeltaTracker._prevFrameCount = frameCount;
      double num2 = appTime - DeltaTracker._prevFrameTime;
      DeltaTracker._prevFrameTime = appTime;
      AnalyticManager.SetValue<int>("Frame Count", num1, "Delta Times Per Second");
      for (int index = 0; index < DeltaTracker._deltaTotals.Length; ++index)
      {
        IterableDictionary<string, double>.Entry entry = DeltaTracker._deltaTotals.entries[index];
        if (entry.hashCode >= 0)
        {
          string key = entry.Key;
          double num3 = entry.Value;
          AnalyticManager.SetValue<double>(key + " AVG MS", Math.Round(num3 / (double) num1 * 1000.0, 3), "Delta Times Per Second");
          AnalyticManager.SetValue<double>(key + " %", Math.Round(num3 / num2 * 100.0, 2), "Delta Times Per Second");
        }
      }
      DeltaTracker._deltaTotals.Clear();
      DeltaTracker._maxDeltas.Clear();
    }

    public override void Dispose()
    {
    }

    [DebuggerHidden]
    public override IEnumerator DumpTo(Action<string> writeToFile)
    {
      // ISSUE: object of a compiler-generated type is created
      return (IEnumerator) new DeltaTracker.\u003CDumpTo\u003Ec__Iterator19F()
      {
        writeToFile = writeToFile,
        \u003C\u0024\u003EwriteToFile = writeToFile
      };
    }
  }
}
