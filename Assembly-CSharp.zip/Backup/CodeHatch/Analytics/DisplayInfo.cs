﻿// Decompiled with JetBrains decompiler
// Type: CodeHatch.Analytics.DisplayInfo
// Assembly: Assembly-CSharp, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 7AE521BE-DDCA-4BB1-9869-8132CF2A08FD
// Assembly location: C:\Users\85206\Desktop\Oxide.ReignOfKings-develop\src\Dependencies\windows\ROK_Data\Managed\Assembly-CSharp.dll

using CodeHatch.Common;
using CodeHatch.Engine.Networking;
using System;
using System.Collections.Generic;
using System.Windows.Forms;

#nullable disable
namespace CodeHatch.Analytics
{
  public class DisplayInfo
  {
    private bool _hasData;
    public readonly string Category;
    private IterableDictionary<byte, IConverter> _converts;
    private List<IConverter> _tempConverts = new List<IConverter>();
    private TreeNode _parentNode;

    public DisplayInfo(string category) => this.Category = category;

    public bool HasData => this._hasData;

    public void UpdateView(TreeView view)
    {
      for (int i = 0; i < this._converts.Length; ++i)
      {
        IterableDictionary<byte, IConverter>.Entry atIndex = this._converts.GetAtIndex(i);
        if (!atIndex.IsInvalid())
          this.DoDefaultView(view, atIndex.Value);
      }
    }

    public void DoDefaultExcluding(TreeView view, params IConverter[] convert)
    {
      for (int i = 0; i < this._converts.Length; ++i)
      {
        IterableDictionary<byte, IConverter>.Entry atIndex = this._converts.GetAtIndex(i);
        if (!atIndex.IsInvalid() && !convert.Contains<IConverter>(atIndex.Value))
          this.DoDefaultView(view, atIndex.Value);
      }
    }

    public void DoDefaultView(TreeView view, IConverter convert)
    {
      if (this._parentNode == null)
      {
        this._parentNode = new TreeNode(this.Category);
        view.Nodes.Add(this._parentNode);
      }
      if (!view.Nodes.Contains(this._parentNode))
        view.Nodes.Add(this._parentNode);
      convert.SetNodes(this._parentNode);
    }

    public void RemoveTags()
    {
      for (int i = 0; i < this._converts.Length; ++i)
      {
        IterableDictionary<byte, IConverter>.Entry atIndex = this._converts.GetAtIndex(i);
        if (!atIndex.IsInvalid())
          atIndex.Value.RemoveTags();
      }
    }

    public void Tag()
    {
      if (this._converts == null)
        return;
      for (int i = 0; i < this._converts.Length; ++i)
      {
        IterableDictionary<byte, IConverter>.Entry atIndex = this._converts.GetAtIndex(i);
        if (!atIndex.IsInvalid())
          atIndex.Value.Tag();
      }
    }

    public void Clear()
    {
      if (this._converts == null)
        return;
      this._hasData = false;
      for (int i = 0; i < this._converts.Length; ++i)
      {
        IterableDictionary<byte, IConverter>.Entry atIndex = this._converts.GetAtIndex(i);
        if (!atIndex.IsInvalid())
          atIndex.Value.Clear();
      }
    }

    public void SetValue<T>(T value, string key) where T : IComparable<T>
    {
      for (int index = 0; index < Converts.Clones.Length; ++index)
      {
        IConverter clone = Converts.Clones[index];
        if (clone.CanUse<T>(value))
        {
          if (this._converts == null)
            this._converts = new IterableDictionary<byte, IConverter>((IEqualityComparer<byte>) new ByteComparer());
          ConverterBase<T> converterBase;
          if (!this._converts.ContainsKey(clone.Id))
          {
            converterBase = clone.CreateClone() as ConverterBase<T>;
            this._converts[clone.Id] = (IConverter) converterBase;
          }
          else
            converterBase = this._converts[clone.Id] as ConverterBase<T>;
          this._hasData = true;
          converterBase.AddValue(key, value);
          break;
        }
      }
    }

    public ConverterBase<T> GetConverter<T>() where T : IComparable<T>
    {
      byte id = Converts.ConvertToId<T>();
      return this._converts.ContainsKey(id) ? this._converts[id] as ConverterBase<T> : (ConverterBase<T>) null;
    }

    public void Serialize(IStream stream)
    {
      for (int i = 0; i < this._converts.Length; ++i)
      {
        IterableDictionary<byte, IConverter>.Entry atIndex = this._converts.GetAtIndex(i);
        if (!atIndex.IsInvalid() && atIndex.Value.HasData())
          this._tempConverts.Add(atIndex.Value);
      }
      stream.WriteInt32(this._tempConverts.Count);
      for (int index = 0; index < this._tempConverts.Count; ++index)
      {
        IConverter tempConvert = this._tempConverts[index];
        stream.WriteByte(tempConvert.Id);
        tempConvert.Serialize(stream);
      }
      this._tempConverts.Clear();
    }

    public void Deserialize(IStream stream)
    {
      int num = stream.ReadInt32();
      if (num > 0 && this._converts == null)
        this._converts = new IterableDictionary<byte, IConverter>((IEqualityComparer<byte>) new ByteComparer());
      for (int index1 = 0; index1 < num; ++index1)
      {
        byte key = stream.ReadByte();
        if (!this._converts.ContainsKey(key))
        {
          for (int index2 = 0; index2 < Converts.Clones.Length; ++index2)
          {
            IConverter clone = Converts.Clones[index2];
            if ((int) clone.Id == (int) key)
            {
              this._converts[key] = clone.CreateClone();
              break;
            }
          }
        }
        this._converts[key].Deserialize(stream);
      }
    }

    public static bool CanUseType<T>(T theValue)
    {
      for (int index = 0; index < Converts.Clones.Length; ++index)
      {
        if (Converts.Clones[index].CanUse<T>(theValue))
          return true;
      }
      return false;
    }

    public bool GetValue<T>(string key, out T value) where T : IComparable<T>
    {
      value = default (T);
      if (this._converts == null)
        return false;
      for (int i = 0; i < this._converts.Length; ++i)
      {
        IterableDictionary<byte, IConverter>.Entry atIndex = this._converts.GetAtIndex(i);
        if (!atIndex.IsInvalid() && atIndex.Value.CanUse(typeof (T)))
          return atIndex.Value is ConverterBase<T> converterBase && converterBase.GetData(key, out value);
      }
      return false;
    }
  }
}
