﻿// Decompiled with JetBrains decompiler
// Type: CodeHatch.Analytics.Converts
// Assembly: Assembly-CSharp, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 7AE521BE-DDCA-4BB1-9869-8132CF2A08FD
// Assembly location: C:\Users\85206\Desktop\Oxide.ReignOfKings-develop\src\Dependencies\windows\ROK_Data\Managed\Assembly-CSharp.dll

using System;
using System.Collections.Generic;

#nullable disable
namespace CodeHatch.Analytics
{
  public static class Converts
  {
    public const string SortKey = "%s";
    public const byte UNASSIGNED_ID = 255;
    public static readonly IConverter[] Clones = new IConverter[9]
    {
      (IConverter) new Int32Display(),
      (IConverter) new SingleDisplay(),
      (IConverter) new DoubleDisplay(),
      (IConverter) new StringDisplay(),
      (IConverter) new ByteDisplay(),
      (IConverter) new ShortDisplay(),
      (IConverter) new UInt32Display(),
      (IConverter) new Int64Display(),
      (IConverter) new UInt64Display()
    };
    public static readonly string[] SpecialKeys = new string[1]
    {
      "%s"
    };
    private static Dictionary<Type, byte> _convertTypes;

    public static byte ConvertToId<T>()
    {
      if (Converts._convertTypes == null)
      {
        Converts._convertTypes = new Dictionary<Type, byte>();
        for (int index = 0; index < Converts.Clones.Length; ++index)
        {
          IConverter clone = Converts.Clones[index];
          Converts._convertTypes[clone.GetType().GetGenericArguments()[0]] = clone.Id;
        }
      }
      return Converts._convertTypes.ContainsKey(typeof (T)) ? Converts._convertTypes[typeof (T)] : byte.MaxValue;
    }
  }
}
