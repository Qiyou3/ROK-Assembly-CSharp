﻿// Decompiled with JetBrains decompiler
// Type: CodeHatch.Analytics.CategoryDisplay
// Assembly: Assembly-CSharp, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 7AE521BE-DDCA-4BB1-9869-8132CF2A08FD
// Assembly location: C:\Users\85206\Desktop\Oxide.ReignOfKings-develop\src\Dependencies\windows\ROK_Data\Managed\Assembly-CSharp.dll

using System;
using System.Windows.Forms;

#nullable disable
namespace CodeHatch.Analytics
{
  public abstract class CategoryDisplay
  {
    public abstract string Category { get; }

    public virtual bool CanUse(DisplayInfo info)
    {
      return info.Category.Equals(this.Category, StringComparison.InvariantCultureIgnoreCase);
    }

    public virtual void OnDoTree(DisplayInfo info, TreeView view) => info.UpdateView(view);

    public virtual void OnSimple(DisplayInfo info)
    {
    }
  }
}
