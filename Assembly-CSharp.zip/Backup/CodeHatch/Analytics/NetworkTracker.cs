﻿// Decompiled with JetBrains decompiler
// Type: CodeHatch.Analytics.NetworkTracker
// Assembly: Assembly-CSharp, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 7AE521BE-DDCA-4BB1-9869-8132CF2A08FD
// Assembly location: C:\Users\85206\Desktop\Oxide.ReignOfKings-develop\src\Dependencies\windows\ROK_Data\Managed\Assembly-CSharp.dll

using System;
using System.Collections;
using System.Diagnostics;
using uLink;
using UnityEngine;

#nullable disable
namespace CodeHatch.Analytics
{
  public class NetworkTracker : BaseAnalyticTracker
  {
    public const string CATEGORY = "Network Socket";
    public const string EXPIRED = "Expired Messages";
    public const string EXPIRED_DIFF = "Expired Messages Diff";
    public const string SOCKET_QUEUE = "Socket Queued Message Count";
    public const string SOCKET_QUEUE_DIFF = "Socket Queued Message Diff";
    public const string HANDLE_QUEUE = "Handle Queued Message Count";
    public const string HANDLE_QUEUE_DIFF = "Handle Queued Message Diff";
    public const string MESSAGE_SENT = "Messages Sent";
    public const string MESSAGE_SENT_RELIABLE = "Messages Sent (Reliable)";
    public const string MESSAGE_SENT_UNRELIABLE = "Messages Sent (Unreliable)";
    public const string MESSAGE_SENT_DIFF = "Messages Sent Diff";
    public const string MESSAGE_SENT_DIFF_RELIABLE = "Messages Sent Diff (Reliable)";
    public const string MESSAGE_SENT_DIFF_UNRELIABLE = "Messages Sent Diff (Unreliable)";
    public const string MESSAGE_BATCH = "Messages Batched";
    public const string MESSAGE_BATCH_RELIABLE = "Messages Batched (Reliable)";
    public const string MESSAGE_BATCH_UNRELIABLE = "Messages Batched (Unreliable";
    public const string MESSAGE_BATCH_DIFF = "Messages Batched Diff";
    public const string MESSAGE_BATCH_DIFF_RELIABLE = "Messages Batched Diff (Reliable)";
    public const string MESSAGE_BATCH_DIFF_UNRELIABLE = "Messages Batched Diff (Unreliable)";
    public const string MESSAGE_BATCH_SYSTEM = "{0} Messages Batched";
    public const string MESSAGE_BATCH_SYSTEM_RELIABLE = "{0} Messages Batched (Reliable)";
    public const string MESSAGE_BATCH_SYSTEM_UNRELIABLE = "{0} Messages Batched (Unreliable)";
    public const string MESSAGE_BATCH_SYSTEM_DIFF = "{0} Messages Batched";
    public const string MESSAGE_BATCH_SYSTEM_DIFF_RELIABLE = "{0} Messages Batched (Reliable)";
    public const string MESSAGE_BATCH_SYSTEM_DIFF_UNRELIABLE = "{0} Messages Batched (Unreliable)";
    public const string MESSAGE_BATCH_SYSTEM_SIZE = "{0} Messages Batched Bytes";
    public const string MESSAGE_BATCH_SYSTEM_SIZE_RELIABLE = "{0} Messages Batched Bytes (Reliable)";
    public const string MESSAGE_BATCH_SYSTEM_SIZE_UNRELIABLE = "{0} Messages Batched Bytes (Unreliable)";
    public const string MESSAGE_BATCH_SYSTEM_SIZE_DIFF = "{0} Messages Batched Bytes Diff";
    public const string MESSAGE_BATCH_SYSTEM_SIZE_DIFF_RELIABLE = "{0} Messages Batched Bytes Diff (Reliable)";
    public const string MESSAGE_BATCH_SYSTEM_SIZE_DIFF_UNRELIABLE = "{0} Messages Batched Bytes Diff (Unreliable)";
    public const string MESSAGE_BATCH_SYSTEM_SIZE_DIFF_AVG = "{0} Messages Batched Bytes Diff Average";
    public const string MESSAGE_BATCH_SYSTEM_SIZE_DIFF_AVG_RELIABLE = "{0} Messages Batched Bytes Diff Average (Reliable)";
    public const string MESSAGE_BATCH_SYSTEM_SIZE_DIFF_AVG_UNRELIABLE = "{0} Messages Batched Bytes Diff Average (Unreliable)";
    public const string MESSAGE_RECIEVED = "Messages Recieved";
    public const string MESSAGE_RECIEVED_RELIABLE = "Messages Recieved (Reliable)";
    public const string MESSAGE_RECIEVED_UNRELIABLE = "Messages Recieved (Unreliable)";
    public const string MESSAGE_RECIEVED_DIFF = "Messages Recieved Diff";
    public const string MESSAGE_RECIEVED_DIFF_RELIABLE = "Messages Recieved Diff (Reliable)";
    public const string MESSAGE_RECIEVED_DIFF_UNRELIABLE = "Messages Recieved Diff (Unreliable)";
    private const NetworkFlags RELIABLE_FLAGS = NetworkFlags.Unencrypted;
    private const NetworkFlags RELIABLE_ENCRYPTED_FLAGS = NetworkFlags.Normal;
    private const NetworkFlags UNRELIABLE_FLAGS = NetworkFlags.Unreliable | NetworkFlags.Unencrypted;
    private const NetworkFlags UNRELIABLE_ENCRYPTED_FLAGS = NetworkFlags.Unreliable;
    private int _prevSocketQueueCount;
    private int _prevHandleQueueCount;
    private long _prevReceiveCount;
    private long _prevReceiveReliableCount;
    private long _prevReceiveUnreliableCount;
    private long _prevSendCount;
    private long _prevSendReliableCount;
    private long _prevSendUnreliableCount;
    private int _prevExpired;
    private long _prevBatchedCount;
    private long _prevBatchedReliableCount;
    private long _prevBatchedUnreliableCount;
    private int[] _systemIDs;

    public override void Inititalize()
    {
    }

    public override void ServerUpdate()
    {
    }

    public override void OnDisable()
    {
      base.OnDisable();
      this._prevSocketQueueCount = 0;
      this._prevHandleQueueCount = 0;
      this._prevReceiveCount = 0L;
    }

    public override void OnBeforeSend()
    {
      int receiveQueueCount = uLinkIntegration.ReceiveQueueCount;
      AnalyticManager.SetValue<int>("Handle Queued Message Count", receiveQueueCount, "Network Socket");
      AnalyticManager.SetValue<int>("Handle Queued Message Diff", Mathf.Clamp(receiveQueueCount - this._prevHandleQueueCount, 0, int.MaxValue), "Network Socket");
      this._prevHandleQueueCount = receiveQueueCount;
      ThreadedULinkSocket instance = ThreadedULinkSocket.Instance;
      AnalyticManager.SetValue<int>("Expired Messages", instance.ExpiredMessageCount, "Network Socket");
      AnalyticManager.SetValue<int>("Expired Messages Diff", Mathf.Clamp(instance.ExpiredMessageCount - this._prevExpired, 0, int.MaxValue), "Network Socket");
      this._prevExpired = instance.ExpiredMessageCount;
      int queuedMessageCount = instance.QueuedMessageCount;
      AnalyticManager.SetValue<int>("Socket Queued Message Count", queuedMessageCount, "Network Socket");
      AnalyticManager.SetValue<int>("Socket Queued Message Diff", Mathf.Clamp(queuedMessageCount - this._prevSocketQueueCount, 0, int.MaxValue), "Network Socket");
      AnalyticManager.SetValue<int>("Messages Sent", instance.MessageSendCount, "Network Socket");
      AnalyticManager.SetValue<int>("Messages Sent (Reliable)", instance.ReliableSendCount, "Network Socket");
      AnalyticManager.SetValue<int>("Messages Sent (Unreliable)", instance.UnreliableSendCount, "Network Socket");
      AnalyticManager.SetValue<float>("Messages Sent Diff", Mathf.Clamp((float) ((long) instance.MessageSendCount - this._prevSendCount), 0.0f, (float) int.MaxValue), "Network Socket");
      AnalyticManager.SetValue<float>("Messages Sent Diff (Reliable)", Mathf.Clamp((float) ((long) instance.ReliableSendCount - this._prevSendReliableCount), 0.0f, (float) int.MaxValue), "Network Socket");
      AnalyticManager.SetValue<float>("Messages Sent Diff (Unreliable)", Mathf.Clamp((float) ((long) instance.UnreliableSendCount - this._prevSendUnreliableCount), 0.0f, (float) int.MaxValue), "Network Socket");
      AnalyticManager.SetValue<int>("Messages Recieved", instance.MessageReceiveCount, "Network Socket");
      AnalyticManager.SetValue<int>("Messages Recieved (Reliable)", instance.ReliableRecieveCount, "Network Socket");
      AnalyticManager.SetValue<int>("Messages Recieved (Unreliable)", instance.UnreliableRecieveCount, "Network Socket");
      AnalyticManager.SetValue<float>("Messages Recieved Diff", Mathf.Clamp((float) ((long) instance.MessageReceiveCount - this._prevReceiveCount), 0.0f, (float) int.MaxValue), "Network Socket");
      AnalyticManager.SetValue<float>("Messages Recieved Diff (Reliable)", Mathf.Clamp((float) ((long) instance.ReliableRecieveCount - this._prevReceiveReliableCount), 0.0f, (float) int.MaxValue), "Network Socket");
      AnalyticManager.SetValue<float>("Messages Recieved Diff (Unreliable)", Mathf.Clamp((float) ((long) instance.UnreliableRecieveCount - this._prevReceiveUnreliableCount), 0.0f, (float) int.MaxValue), "Network Socket");
      this._prevSocketQueueCount = queuedMessageCount;
      this._prevSendCount = (long) instance.MessageSendCount;
      this._prevSendReliableCount = (long) instance.ReliableSendCount;
      this._prevSendUnreliableCount = (long) instance.UnreliableSendCount;
      this._prevReceiveCount = (long) instance.MessageReceiveCount;
      this._prevReceiveReliableCount = (long) instance.ReliableRecieveCount;
      this._prevReceiveUnreliableCount = (long) instance.UnreliableRecieveCount;
      AnalyticManager.SetValue<int>("Messages Batched", uLinkIntegration.SendBatchCount, "Network Socket");
      AnalyticManager.SetValue<int>("Messages Batched (Reliable)", uLinkIntegration.SendBatchReliableCount, "Network Socket");
      AnalyticManager.SetValue<int>("Messages Batched (Unreliable", uLinkIntegration.SendBatchUnreliableCount, "Network Socket");
      AnalyticManager.SetValue<float>("Messages Batched Diff", Mathf.Clamp((float) ((long) uLinkIntegration.SendBatchCount - this._prevBatchedCount), 0.0f, (float) int.MaxValue), "Network Socket");
      AnalyticManager.SetValue<float>("Messages Batched Diff (Reliable)", Mathf.Clamp((float) ((long) uLinkIntegration.SendBatchReliableCount - this._prevBatchedReliableCount), 0.0f, (float) int.MaxValue), "Network Socket");
      AnalyticManager.SetValue<float>("Messages Batched Diff (Unreliable)", Mathf.Clamp((float) ((long) uLinkIntegration.SendBatchUnreliableCount - this._prevBatchedUnreliableCount), 0.0f, (float) int.MaxValue), "Network Socket");
      this._prevBatchedCount = (long) uLinkIntegration.SendBatchCount;
      this._prevBatchedReliableCount = (long) uLinkIntegration.SendBatchReliableCount;
      this._prevBatchedUnreliableCount = (long) uLinkIntegration.SendBatchUnreliableCount;
    }

    public override void Dispose()
    {
    }

    [DebuggerHidden]
    public override IEnumerator DumpTo(Action<string> writeToFile)
    {
      // ISSUE: object of a compiler-generated type is created
      return (IEnumerator) new NetworkTracker.\u003CDumpTo\u003Ec__Iterator19E()
      {
        writeToFile = writeToFile,
        \u003C\u0024\u003EwriteToFile = writeToFile,
        \u003C\u003Ef__this = this
      };
    }
  }
}
