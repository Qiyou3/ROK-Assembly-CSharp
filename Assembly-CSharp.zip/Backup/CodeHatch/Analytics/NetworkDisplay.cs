﻿// Decompiled with JetBrains decompiler
// Type: CodeHatch.Analytics.NetworkDisplay
// Assembly: Assembly-CSharp, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 7AE521BE-DDCA-4BB1-9869-8132CF2A08FD
// Assembly location: C:\Users\85206\Desktop\Oxide.ReignOfKings-develop\src\Dependencies\windows\ROK_Data\Managed\Assembly-CSharp.dll

using System;
using System.Windows.Forms;
using UnityEngine;

#nullable disable
namespace CodeHatch.Analytics
{
  public class NetworkDisplay : CategoryDisplay
  {
    private const string SEND_LABEL = "Network Sends: {0}{1}{2} (R:{3}{4}{5}, U:{6}{7}{8})";
    private const string RECEIVE_LABEL = "Network Receives: {0}{1}{2} (R:{3}{4}{5}, U:{6}{7}{8})";
    private const string HANDLE_QUEUE_LABEL = "Handle Queue: {0}{1}{2}";
    private const string SOCKET_QUEUE_LABEL = "Socket Queue: {0}{1}{2}";
    private int _handleQueueCount;
    private int _socketQueueCount;
    private int _sendCount;
    private int _sendReliableCount;
    private int _sendUnreliableCount;
    private int _receiveCount;
    private int _receiveReliableCount;
    private int _receiveUnreliableCount;
    private int _lastFrameHandleQueueCount;
    private int _lastFrameSocketQueueCount;
    private int _lastFrameSend;
    private int _lastFrameSendReliable;
    private int _lastFrameSendUnreliable;
    private int _lastFrameReceive;
    private int _lastFrameReceiveReliable;
    private int _lastFrameReceiveUnreliable;

    public override string Category => "Network Socket";

    public override void OnDoTree(DisplayInfo info, TreeView view)
    {
      info.SetValue<int>(this._handleQueueCount - this._lastFrameHandleQueueCount, "Handle Queued Message Diff");
      info.SetValue<int>(this._socketQueueCount - this._lastFrameSocketQueueCount, "Socket Queued Message Diff");
      info.SetValue<int>(this._sendCount - this._lastFrameSend, "Messages Sent Diff");
      info.SetValue<int>(this._sendReliableCount - this._lastFrameSendReliable, "Messages Sent Diff (Reliable)");
      info.SetValue<int>(this._sendUnreliableCount - this._lastFrameSendUnreliable, "Messages Sent Diff (Unreliable)");
      info.SetValue<int>(this._receiveCount - this._lastFrameReceive, "Messages Recieved Diff");
      info.SetValue<int>(this._receiveReliableCount - this._lastFrameReceiveReliable, "Messages Recieved Diff (Reliable)");
      info.SetValue<int>(this._receiveUnreliableCount - this._lastFrameReceiveUnreliable, "Messages Recieved Diff (Unreliable)");
      this._lastFrameHandleQueueCount = this._handleQueueCount;
      this._lastFrameSocketQueueCount = this._socketQueueCount;
      this._lastFrameSend = this._sendCount;
      this._lastFrameSendReliable = this._sendReliableCount;
      this._lastFrameSendUnreliable = this._sendUnreliableCount;
      this._lastFrameReceive = this._receiveCount;
      this._lastFrameReceiveReliable = this._receiveReliableCount;
      this._lastFrameReceiveUnreliable = this._receiveUnreliableCount;
      base.OnDoTree(info, view);
    }

    public override void OnSimple(DisplayInfo info)
    {
      int num1 = 0;
      int num2 = 0;
      int num3 = 0;
      int num4 = 0;
      int num5 = 0;
      int num6 = 0;
      int num7 = 0;
      int num8 = 0;
      if (info != null)
      {
        info.GetValue<int>("Handle Queued Message Count", out this._handleQueueCount);
        info.GetValue<int>("Socket Queued Message Count", out this._socketQueueCount);
        info.GetValue<int>("Messages Sent", out this._sendCount);
        info.GetValue<int>("Messages Sent (Reliable)", out this._sendReliableCount);
        info.GetValue<int>("Messages Sent (Unreliable)", out this._sendUnreliableCount);
        info.GetValue<int>("Messages Recieved", out this._receiveCount);
        info.GetValue<int>("Messages Recieved (Reliable)", out this._receiveReliableCount);
        info.GetValue<int>("Messages Recieved (Unreliable)", out this._receiveUnreliableCount);
        num1 = this._handleQueueCount - this._lastFrameHandleQueueCount;
        num2 = this._socketQueueCount - this._lastFrameSocketQueueCount;
        num3 = this._sendCount - this._lastFrameSend;
        num4 = this._sendReliableCount - this._lastFrameSendReliable;
        num5 = this._sendUnreliableCount - this._lastFrameSendUnreliable;
        num6 = this._receiveCount - this._lastFrameReceive;
        num7 = this._receiveReliableCount - this._lastFrameReceiveReliable;
        num8 = this._receiveUnreliableCount - this._lastFrameReceiveUnreliable;
      }
      string str1 = num1 >= 0 ? "+" : "-";
      string str2 = num2 >= 0 ? "+" : "-";
      string str3 = num3 >= 0 ? "+" : "-";
      string str4 = num4 >= 0 ? "+" : "-";
      string str5 = num5 >= 0 ? "+" : "-";
      string str6 = num6 >= 0 ? "+" : "-";
      string str7 = num7 >= 0 ? "+" : "-";
      string str8 = num8 >= 0 ? "+" : "-";
      GUILayout.BeginHorizontal();
      GUILayout.Label(string.Format("Network Sends: {0}{1}{2} (R:{3}{4}{5}, U:{6}{7}{8})", (object) this._sendCount, (object) str3, (object) num3, (object) this._sendReliableCount, (object) str4, (object) num4, (object) this._sendUnreliableCount, (object) str5, (object) num5), GUILayout.ExpandWidth(false));
      GUILayout.EndHorizontal();
      GUILayout.BeginHorizontal();
      GUILayout.Label(string.Format("Network Receives: {0}{1}{2} (R:{3}{4}{5}, U:{6}{7}{8})", (object) this._receiveCount, (object) str6, (object) Math.Abs(num6), (object) this._receiveReliableCount, (object) str7, (object) Math.Abs(num7), (object) this._receiveUnreliableCount, (object) str8, (object) Math.Abs(num8)), GUILayout.ExpandWidth(false));
      GUILayout.EndHorizontal();
      GUILayout.BeginHorizontal();
      GUILayout.Label(string.Format("Handle Queue: {0}{1}{2}", (object) this._handleQueueCount, (object) str1, (object) Math.Abs(num1)), GUILayout.ExpandWidth(false));
      GUILayout.EndHorizontal();
      GUILayout.BeginHorizontal();
      GUILayout.Label(string.Format("Socket Queue: {0}{1}{2}", (object) this._socketQueueCount, (object) str2, (object) Math.Abs(num2)), GUILayout.ExpandWidth(false));
      GUILayout.EndHorizontal();
    }
  }
}
