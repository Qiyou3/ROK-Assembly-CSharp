﻿// Decompiled with JetBrains decompiler
// Type: CodeHatch.Analytics.IConverter
// Assembly: Assembly-CSharp, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 7AE521BE-DDCA-4BB1-9869-8132CF2A08FD
// Assembly location: C:\Users\85206\Desktop\Oxide.ReignOfKings-develop\src\Dependencies\windows\ROK_Data\Managed\Assembly-CSharp.dll

using CodeHatch.Engine.Networking;
using System;
using System.Windows.Forms;

#nullable disable
namespace CodeHatch.Analytics
{
  public interface IConverter
  {
    byte Id { get; }

    bool CanUse<T>(T value);

    bool CanUse(Type value);

    IConverter CreateClone();

    void SetNodes(TreeNode parent);

    bool HasData();

    void Tag();

    void RemoveTags();

    void Clear();

    void Serialize(IStream stream);

    void Deserialize(IStream stream);
  }
}
