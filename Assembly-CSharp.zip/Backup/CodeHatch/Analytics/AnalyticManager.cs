﻿// Decompiled with JetBrains decompiler
// Type: CodeHatch.Analytics.AnalyticManager
// Assembly: Assembly-CSharp, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 7AE521BE-DDCA-4BB1-9869-8132CF2A08FD
// Assembly location: C:\Users\85206\Desktop\Oxide.ReignOfKings-develop\src\Dependencies\windows\ROK_Data\Managed\Assembly-CSharp.dll

using CodeHatch.Common;
using CodeHatch.Core;
using CodeHatch.Engine;
using CodeHatch.Engine.Core.Gaming;
using CodeHatch.Engine.Networking;
using CodeHatch.Networking.Events;
using CodeHatch.Networking.Events.Players;
using FullInspector;
using JetBrains.Annotations;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.Linq;
using UnityEngine;

#nullable disable
namespace CodeHatch.Analytics
{
  public class AnalyticManager : BaseBehavior
  {
    public const string UNKNOWN_CATEGORY = "";
    public const string FILE_NAME = "ServerInfo";
    private IterableDictionary<string, DisplayInfo> _infos = new IterableDictionary<string, DisplayInfo>((IEqualityComparer<string>) StringComparer.Create(CultureInfo.CurrentCulture, true));
    private static readonly int SendId = typeof (AnalyticManager).Name.GetHashCode();
    private static AnalyticManager _instance;
    private AnalyticDisplay _display;
    private List<Player> _sendTo;
    [UsedImplicitly]
    [SerializeField]
    public List<CategoryDisplay> _Displays;
    private readonly CategoryDisplay _defaultDisplay = (CategoryDisplay) new DefaultView();
    [SerializeField]
    [UsedImplicitly]
    public BaseAnalyticTracker[] _trackers;
    [SerializeField]
    [UsedImplicitly]
    public float _updateFrequency = 1f;
    private List<DisplayInfo> _tempDisplays = new List<DisplayInfo>();
    private bool _sendAll;
    private bool _recording;
    private bool _enabled;
    private bool _wroteDate;
    private float _currentTime;
    public static bool Tagging;
    private bool _dumping;

    public event Action OnBeforeSend;

    public event Action OnEnabled;

    public event Action OnDisabled;

    public event Action<DisplayInfo, CategoryDisplay> OnUpdateView;

    protected AnalyticDisplay Display
    {
      get
      {
        if ((Object) this._display == (Object) null)
        {
          this._display = new GameObject("AnalyticDisplay", new Type[1]
          {
            typeof (AnalyticDisplay)
          }).GetComponent<AnalyticDisplay>();
          this._display.SetManager(this);
        }
        return this._display;
      }
    }

    public static void SetValue<T>(string key, T value) where T : struct, IComparable<T>
    {
      AnalyticManager.SetValue<T>(key, value, string.Empty);
    }

    public static void SetValue<T>(string key, T value, string category) where T : IComparable<T>
    {
      if ((Object) AnalyticManager._instance == (Object) null)
        Logger.Error("Analytic Manager instance was not set");
      else
        AnalyticManager._instance.InnerSetValue<T>(key, value, category);
    }

    public static void DumpState()
    {
      if ((Object) AnalyticManager._instance == (Object) null)
        Logger.Error("Analytic Manager instance was not set");
      else
        AnalyticManager._instance.InnerDump();
    }

    public static void ToggleSendAll()
    {
      if ((Object) AnalyticManager._instance == (Object) null)
        Logger.Error("Analytic Manager instance was not set");
      else
        AnalyticManager._instance.InnerToggleAll();
    }

    public static void ToggleSend(params Player[] togglePlayers)
    {
      if ((Object) AnalyticManager._instance == (Object) null)
        Logger.Error("Analytic Manager instance was not set");
      else
        AnalyticManager._instance.InnerToggleSend(togglePlayers);
    }

    public static void ToggleRecord()
    {
      if ((Object) AnalyticManager._instance == (Object) null)
        Logger.Error("Analytic Manager instance was not set");
      else
        AnalyticManager._instance.InnerToggleRecord();
    }

    public override void Awake()
    {
      base.Awake();
      AnalyticManager._instance = this;
      if (Game.IsHosting)
      {
        EventManager.Subscribe<PlayerLeaveEvent>(new EventSubscriber<PlayerLeaveEvent>(this.OnPlayerLeave));
        if (this._trackers == null)
          return;
        for (int i = this._trackers.Length - 1; i >= 0; --i)
        {
          BaseAnalyticTracker tracker = this._trackers[i];
          if (tracker != null)
          {
            tracker.Inititalize();
          }
          else
          {
            this._trackers = ((IEnumerable<BaseAnalyticTracker>) this._trackers).Where<BaseAnalyticTracker>((Func<BaseAnalyticTracker, int, bool>) ((val, inx) => inx != i)).ToArray<BaseAnalyticTracker>();
            this.LogError<AnalyticManager>("Index {0} is null and is being removing", (object) i);
          }
        }
      }
      else
      {
        AnalyticManager.Tagging = true;
        if (Server.Instance == null)
          Coroutiner.RunNextUpdateUntilFalse((Func<bool>) (() =>
          {
            if (Server.Instance == null)
              return true;
            Server.OnNetworkReceive += new Action<int, IStream, MessageFlags, Player>(this.OnReceive);
            return false;
          }));
        else
          Server.OnNetworkReceive += new Action<int, IStream, MessageFlags, Player>(this.OnReceive);
      }
    }

    public void Update()
    {
      if (!this._enabled)
        return;
      if (this._trackers != null)
      {
        for (int index = 0; index < this._trackers.Length; ++index)
          this._trackers[index].ServerUpdate();
      }
      this._currentTime -= Time.deltaTime;
      if ((double) this._currentTime >= 0.0)
        return;
      this._currentTime = this._updateFrequency;
      AnalyticManager.Tagging = true;
      this.TagDisplays();
      if (this._trackers != null)
      {
        for (int index = 0; index < this._trackers.Length; ++index)
          this._trackers[index].OnBeforeSend();
      }
      if (this.OnBeforeSend != null)
        this.OnBeforeSend();
      if (!this.HasData())
        return;
      this.RemoveTags();
      this.SendData(false, this._sendTo);
      AnalyticManager.Tagging = false;
    }

    public void OnDestroy()
    {
      AnalyticManager._instance = (AnalyticManager) null;
      if (Game.IsHosting)
      {
        EventManager.Unsubscribe<PlayerLeaveEvent>(new EventSubscriber<PlayerLeaveEvent>(this.OnPlayerLeave));
        if (this._trackers != null)
        {
          for (int index = 0; index < this._trackers.Length; ++index)
            this._trackers[index]?.Dispose();
        }
      }
      Server.OnNetworkReceive -= new Action<int, IStream, MessageFlags, Player>(this.OnReceive);
      if (!((Object) this._display != (Object) null))
        return;
      Object.Destroy((Object) this._display);
      this._display = (AnalyticDisplay) null;
    }

    private void SendData(bool turnOff, List<Player> recips)
    {
      IStream stream = StreamFactory.Instance.Create();
      this.WriteData(stream, turnOff);
      Server.SendStream(AnalyticManager.SendId, stream, (IList<Player>) recips, MessageFlags.Default);
    }

    private bool HasData()
    {
      for (int i = 0; i < this._infos.Length; ++i)
      {
        IterableDictionary<string, DisplayInfo>.Entry atIndex = this._infos.GetAtIndex(i);
        if (!atIndex.IsInvalid() && atIndex.Value.HasData)
          return true;
      }
      return false;
    }

    private void OnReceive(int id, IStream stream, MessageFlags flags, Player sender)
    {
      if (id != AnalyticManager.SendId)
        return;
      this.TagDisplays();
      this.ReadData(stream);
    }

    private void TagDisplays()
    {
      if (this._infos == null)
        return;
      for (int i = 0; i < this._infos.Length; ++i)
      {
        IterableDictionary<string, DisplayInfo>.Entry atIndex = this._infos.GetAtIndex(i);
        if (!atIndex.IsInvalid())
          atIndex.Value.Tag();
      }
    }

    private void RemoveTags()
    {
      if (this._infos == null)
        return;
      for (int i = 0; i < this._infos.Length; ++i)
      {
        IterableDictionary<string, DisplayInfo>.Entry atIndex = this._infos.GetAtIndex(i);
        if (!atIndex.IsInvalid())
          atIndex.Value.RemoveTags();
      }
    }

    private void ReadData(IStream stream)
    {
      int num = stream.ReadInt32();
      if (num == 0)
      {
        this._infos.Clear();
        this.Display.Clear();
      }
      else
      {
        this.Display.SetState(true);
        for (int index1 = 0; index1 < num; ++index1)
        {
          string str = stream.ReadString();
          if (!this._infos.ContainsKey(str))
            this._infos[str] = new DisplayInfo(str);
          DisplayInfo info = this._infos[str];
          info.Deserialize(stream);
          try
          {
            info.RemoveTags();
            if (this.OnUpdateView != null)
            {
              CategoryDisplay categoryDisplay = this._defaultDisplay;
              if (this._Displays != null)
              {
                for (int index2 = 0; index2 < this._Displays.Count; ++index2)
                {
                  CategoryDisplay display = this._Displays[index2];
                  if (display.CanUse(info))
                  {
                    categoryDisplay = display;
                    break;
                  }
                }
              }
              this.OnUpdateView(info, categoryDisplay);
            }
          }
          catch (Exception ex)
          {
            this.LogException<AnalyticManager>(ex);
          }
        }
      }
    }

    private void WriteData(IStream stream, bool off)
    {
      if (off)
      {
        stream.WriteInt32(0);
      }
      else
      {
        for (int i = 0; i < this._infos.Length; ++i)
        {
          IterableDictionary<string, DisplayInfo>.Entry atIndex = this._infos.GetAtIndex(i);
          if (!atIndex.IsInvalid())
          {
            DisplayInfo displayInfo = atIndex.Value;
            if (displayInfo.HasData)
              this._tempDisplays.Add(displayInfo);
          }
        }
        stream.WriteInt32(this._tempDisplays.Count);
        if (this._tempDisplays.Count == 0)
          return;
        for (int index = 0; index < this._tempDisplays.Count; ++index)
        {
          try
          {
            DisplayInfo tempDisplay = this._tempDisplays[index];
            stream.WriteString(tempDisplay.Category);
            tempDisplay.Serialize(stream);
          }
          catch (Exception ex)
          {
            this.LogException<AnalyticManager>(ex);
          }
        }
        this._tempDisplays.Clear();
      }
    }

    private void OnPlayerLeave(PlayerLeaveEvent theevent) => this.GivePlayer(theevent.Player, true);

    private void OnPlayerJoin(PlayerJoinEvent theEvent) => this.GivePlayer(theEvent.Player);

    private void InnerToggleSend(params Player[] thePlayers)
    {
      for (int index = 0; index < thePlayers.Length; ++index)
        this.GivePlayer(thePlayers[index]);
    }

    private void InnerToggleAll()
    {
      List<Player> playerList = (List<Player>) null;
      this._sendAll = !this._sendAll;
      if (this._sendAll)
      {
        playerList = this._sendTo == null || this._sendTo.Count <= 0 ? new List<Player>((IEnumerable<Player>) Server.ClientPlayers) : Server.AllPlayersExcept(this._sendTo);
        EventManager.Subscribe<PlayerJoinEvent>(new EventSubscriber<PlayerJoinEvent>(this.OnPlayerJoin), EventHandlerOrder.Late);
      }
      else
      {
        EventManager.Unsubscribe<PlayerJoinEvent>(new EventSubscriber<PlayerJoinEvent>(this.OnPlayerJoin));
        if (this._sendTo != null && this._sendTo.Count > 0)
          playerList = new List<Player>((IEnumerable<Player>) this._sendTo);
      }
      if (playerList == null)
        return;
      for (int index = 0; index < playerList.Count; ++index)
        this.GivePlayer(playerList[index]);
    }

    private void GivePlayer(Player thePlayer, bool removeOnly = false)
    {
      if (thePlayer == null || !thePlayer.HasPermission("rok.command.admin.serverfps"))
        return;
      if (this._sendTo != null)
      {
        bool flag = false;
        for (int index = this._sendTo.Count - 1; index >= 0; --index)
        {
          Player player = this._sendTo[index];
          if (!player.Connection.IsConnected)
            this._sendTo.RemoveAt(index);
          else if ((long) player.Id == (long) thePlayer.Id)
          {
            flag = true;
            this._sendTo.RemoveAt(index);
            if (!removeOnly)
            {
              this.SendData(true, new List<Player>()
              {
                thePlayer
              });
              break;
            }
            break;
          }
        }
        if (flag)
        {
          if (this._sendTo.Count != 0)
            return;
          this._sendTo = (List<Player>) null;
          this.SetState(false);
          return;
        }
      }
      if (removeOnly)
        return;
      if (this._sendTo == null)
        this._sendTo = new List<Player>();
      this._sendTo.Add(thePlayer);
      if (this._sendTo.Count <= 0)
        return;
      this.SetState(true);
    }

    private void InnerToggleRecord()
    {
      this._recording = !this._recording;
      this.SetState(this._recording);
    }

    private void SetState(bool theState)
    {
      if (!theState)
      {
        if (this._recording || this._sendTo != null && this._sendTo.Count != 0)
          return;
        this._currentTime = -1f;
        this.enabled = false;
        this._enabled = false;
        if (this.OnDisabled != null)
          this.OnDisabled();
        if (this._trackers == null)
          return;
        for (int index = 0; index < this._trackers.Length; ++index)
          this._trackers[index]?.OnDisable();
      }
      else
      {
        if (this._enabled)
          return;
        this.enabled = true;
        this._enabled = true;
        if (this.OnEnabled != null)
          this.OnEnabled();
        if (this._trackers == null)
          return;
        for (int index = 0; index < this._trackers.Length; ++index)
          this._trackers[index]?.OnEnable();
      }
    }

    private void InnerSetValue<T>(string key, T value, string category) where T : IComparable<T>
    {
      if (!this._infos.ContainsKey(category))
        this._infos[category] = new DisplayInfo(category);
      this._infos[category].SetValue<T>(value, key);
    }

    private void InnerDump()
    {
      if (this._trackers == null || this._dumping)
        return;
      if (!this._wroteDate)
      {
        LogFileUtil.LogTextToFile("ServerInfo", string.Format("Date {0}\n\r", (object) string.Format("{0:d/M/yyyy HH:mm:ss}", (object) SafeTime.UnsafeLocalDate)));
        this._wroteDate = true;
      }
      Coroutiner.StartStaticCoroutine(this.DumpOverTime());
    }

    [DebuggerHidden]
    private IEnumerator DumpOverTime()
    {
      // ISSUE: object of a compiler-generated type is created
      return (IEnumerator) new AnalyticManager.\u003CDumpOverTime\u003Ec__Iterator19C()
      {
        \u003C\u003Ef__this = this
      };
    }

    private void WriteToFile(string line)
    {
      if (!line.Contains("\n"))
        line += "\n";
      LogFileUtil.LogTextToFile("ServerInfo", line);
    }

    public string Identifier => "Analytics";

    public void Serialize(IStream stream)
    {
    }

    public void Deserialize(IStream stream)
    {
    }

    public void DoSimpleDisplay()
    {
      if (this._Displays == null)
        return;
      for (int index = 0; index < this._Displays.Count; ++index)
      {
        CategoryDisplay display = this._Displays[index];
        if (this._infos.ContainsKey(display.Category))
          display.OnSimple(this._infos[display.Category]);
        else
          display.OnSimple((DisplayInfo) null);
      }
    }
  }
}
