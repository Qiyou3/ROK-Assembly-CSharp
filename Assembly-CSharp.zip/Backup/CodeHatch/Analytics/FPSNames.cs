﻿// Decompiled with JetBrains decompiler
// Type: CodeHatch.Analytics.FPSNames
// Assembly: Assembly-CSharp, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 7AE521BE-DDCA-4BB1-9869-8132CF2A08FD
// Assembly location: C:\Users\85206\Desktop\Oxide.ReignOfKings-develop\src\Dependencies\windows\ROK_Data\Managed\Assembly-CSharp.dll

#nullable disable
namespace CodeHatch.Analytics
{
  public static class FPSNames
  {
    public const string MIN_NAME = "Min";
    public const string FPS_NAME = "FPS";
    public const string MAX_NAME = "Max";
    public const string MAX_OVERALL = "Max Overall";
    public const string MIN_OVERALL = "Min Overall";
    public const string CATERGORY = "FPS";
  }
}
