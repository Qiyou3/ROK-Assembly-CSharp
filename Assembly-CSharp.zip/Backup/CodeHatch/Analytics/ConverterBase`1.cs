﻿// Decompiled with JetBrains decompiler
// Type: CodeHatch.Analytics.ConverterBase`1
// Assembly: Assembly-CSharp, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 7AE521BE-DDCA-4BB1-9869-8132CF2A08FD
// Assembly location: C:\Users\85206\Desktop\Oxide.ReignOfKings-develop\src\Dependencies\windows\ROK_Data\Managed\Assembly-CSharp.dll

using CodeHatch.Engine.Networking;
using System;
using System.Collections.Generic;
using System.Windows.Forms;

#nullable disable
namespace CodeHatch.Analytics
{
  public abstract class ConverterBase<T> : IConverter where T : IComparable<T>
  {
    public List<ConvertData<T>> Datas;

    public abstract byte Id { get; }

    public bool CanUse<T1>(T1 value) => this.CanUse(typeof (T1));

    public virtual bool CanUse(Type value) => value == typeof (T);

    public abstract IConverter CreateClone();

    public void SetNodes(TreeNode parent)
    {
      if (this.Datas == null)
        return;
      for (int index = 0; index < this.Datas.Count; ++index)
        this.Datas[index].UpdateNode(parent);
      this.CheckSorts(parent, this.Datas);
    }

    private void CheckSorts(TreeNode parent, List<ConvertData<T>> converts)
    {
      bool flag = false;
      for (int index = 0; index < converts.Count; ++index)
      {
        if (converts[index].ContainsSpecial("%s"))
        {
          flag = true;
          break;
        }
      }
      if (!flag)
        return;
      TreeNodeCollection nodes = parent.Nodes;
      converts.Sort((Comparison<ConvertData<T>>) ((a, b) =>
      {
        if (!a.ContainsSpecial("%s"))
          return -1;
        int num = a.Value.CompareTo(b.Value);
        return num != 0 ? num : string.Compare(a.Name, b.Name, StringComparison.Ordinal);
      }));
      for (int index = 0; index < converts.Count; ++index)
      {
        ConvertData<T> convert = converts[index];
        nodes.Remove(convert.Node);
      }
      for (int index = converts.Count - 1; index >= 0; --index)
      {
        ConvertData<T> convert = converts[index];
        nodes.Add(convert.Node);
      }
    }

    public bool HasData() => this.Datas != null && this.Datas.Count > 0;

    public void Tag()
    {
      for (int index = this.Datas.Count - 1; index >= 0; --index)
        ++this.Datas[index].TagCount;
    }

    public void RemoveTags()
    {
      for (int index = this.Datas.Count - 1; index >= 0; --index)
      {
        ConvertData<T> data = this.Datas[index];
        if (data.TagCount >= (short) 1)
        {
          this.Datas.RemoveAt(index);
          if (data.Node != null)
            data.Node.Remove();
        }
      }
    }

    public virtual void Clear()
    {
      if (this.Datas == null)
        return;
      this.Datas.Clear();
    }

    public bool TryGetDataValue(string key, out T value)
    {
      value = default (T);
      if (this.Datas == null)
        return false;
      for (int index = 0; index < this.Datas.Count; ++index)
      {
        if (string.Equals(this.Datas[index].Key, key, StringComparison.InvariantCultureIgnoreCase))
        {
          value = this.Datas[index].Value;
          return true;
        }
      }
      return false;
    }

    public ConvertData<T> GetData(string key)
    {
      if (this.Datas == null)
        return (ConvertData<T>) null;
      for (int index = 0; index < this.Datas.Count; ++index)
      {
        if (string.Equals(this.Datas[index].Key, key, StringComparison.InvariantCultureIgnoreCase))
          return this.Datas[index];
      }
      return (ConvertData<T>) null;
    }

    public bool GetData(string key, out T data)
    {
      data = default (T);
      if (this.Datas == null)
        return false;
      for (int index = 0; index < this.Datas.Count; ++index)
      {
        if (string.Equals(this.Datas[index].Key, key, StringComparison.InvariantCultureIgnoreCase))
        {
          data = this.Datas[index].Value;
          return true;
        }
      }
      return false;
    }

    public void Serialize(IStream stream)
    {
      if (this.Datas == null)
      {
        stream.WriteInt32(0);
      }
      else
      {
        stream.WriteInt32(this.Datas.Count);
        for (int index = 0; index < this.Datas.Count; ++index)
        {
          ConvertData<T> data = this.Datas[index];
          stream.WriteString(data.Key);
          this.WriteValue(stream, data.Value);
        }
      }
    }

    public void Deserialize(IStream stream)
    {
      int num = stream.ReadInt32();
      if (num > 0 && this.Datas == null)
        this.Datas = new List<ConvertData<T>>();
      for (int index1 = 0; index1 < num; ++index1)
      {
        string key = stream.ReadString();
        int index2 = this.Datas.FindIndex((Predicate<ConvertData<T>>) (a => a.Key.Equals(key, StringComparison.InvariantCultureIgnoreCase)));
        if (index2 == -1)
        {
          this.Datas.Add(new ConvertData<T>()
          {
            Key = key,
            Value = this.ReadValue(stream)
          });
        }
        else
        {
          this.Datas[index2].TagCount = this.GetTagCount();
          this.Datas[index2].Value = this.ReadValue(stream);
        }
      }
    }

    public void AddValue(string key, T value)
    {
      if (this.Datas == null)
        this.Datas = new List<ConvertData<T>>();
      int index = this.Datas.FindIndex((Predicate<ConvertData<T>>) (a => a.Key.Equals(key, StringComparison.InvariantCultureIgnoreCase)));
      if (index == -1)
      {
        this.Datas.Add(new ConvertData<T>()
        {
          Key = key,
          Value = value
        });
      }
      else
      {
        this.Datas[index].TagCount = this.GetTagCount();
        this.Datas[index].Value = value;
      }
    }

    private short GetTagCount() => AnalyticManager.Tagging ? (short) 0 : (short) -1;

    protected abstract void WriteValue(IStream stream, T value);

    protected abstract T ReadValue(IStream stream);
  }
}
