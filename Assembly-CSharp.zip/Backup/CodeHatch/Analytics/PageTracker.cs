﻿// Decompiled with JetBrains decompiler
// Type: CodeHatch.Analytics.PageTracker
// Assembly: Assembly-CSharp, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 7AE521BE-DDCA-4BB1-9869-8132CF2A08FD
// Assembly location: C:\Users\85206\Desktop\Oxide.ReignOfKings-develop\src\Dependencies\windows\ROK_Data\Managed\Assembly-CSharp.dll

using System;
using System.Collections;
using System.Diagnostics;

#nullable disable
namespace CodeHatch.Analytics
{
  public class PageTracker : BaseAnalyticTracker
  {
    public override void Inititalize()
    {
    }

    public override void ServerUpdate()
    {
    }

    public override void OnBeforeSend()
    {
    }

    public override void Dispose()
    {
    }

    [DebuggerHidden]
    public override IEnumerator DumpTo(Action<string> writeToFile)
    {
      // ISSUE: object of a compiler-generated type is created
      // ISSUE: variable of a compiler-generated type
      PageTracker.\u003CDumpTo\u003Ec__Iterator1A0 dumpToCIterator1A0 = new PageTracker.\u003CDumpTo\u003Ec__Iterator1A0();
      return (IEnumerator) dumpToCIterator1A0;
    }
  }
}
