﻿// Decompiled with JetBrains decompiler
// Type: CodeHatch.Analytics.AnalyticDisplay
// Assembly: Assembly-CSharp, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 7AE521BE-DDCA-4BB1-9869-8132CF2A08FD
// Assembly location: C:\Users\85206\Desktop\Oxide.ReignOfKings-develop\src\Dependencies\windows\ROK_Data\Managed\Assembly-CSharp.dll

using Assets.CodeHatch.Merica.Scripts.Social.Supplier.Analytics;
using System;
using System.Windows.Forms;
using UnityEngine;

#nullable disable
namespace CodeHatch.Analytics
{
  public class AnalyticDisplay : MonoBehaviour
  {
    private AnalyticManager _manager;
    private AnalyticsForm _displayForm;
    private bool _showing;
    private TreeView _displayTree;

    protected AnalyticsForm DisplayForm
    {
      get
      {
        if (this._displayForm == null)
          this.CreateForm();
        return this._displayForm;
      }
    }

    protected TreeView DisplayTree => this.DisplayForm.displayView;

    private void CreateForm()
    {
      this._displayForm = new AnalyticsForm();
      this._displayForm.FormClosing += new FormClosingEventHandler(this.OnFormClose);
    }

    public void SetManager(AnalyticManager manager)
    {
      this._manager = manager;
      this._manager.OnUpdateView += new Action<DisplayInfo, CategoryDisplay>(this.OnViewUpdate);
    }

    public void Clear() => this.SetState(false);

    public void SetState(bool value)
    {
      this.enabled = value;
      if (this.enabled)
        return;
      this.ShowDetailed(false);
      this.DisplayTree.Nodes.Clear();
    }

    public void OnViewUpdate(DisplayInfo info, CategoryDisplay display)
    {
      this.DisplayTree.BeginUpdate();
      try
      {
        display.OnDoTree(info, this.DisplayTree);
      }
      catch (Exception ex)
      {
        this.LogException<AnalyticDisplay>(ex);
      }
      this.DisplayTree.EndUpdate();
    }

    private void ShowDetailed(bool value)
    {
      this._showing = value;
      this.DisplayForm.Visible = this._showing;
    }

    public void OnGUI()
    {
      if ((Object) this._manager == (Object) null || !this.enabled)
        return;
      GUILayout.BeginArea(new Rect(0.0f, 100f, (float) Screen.width, (float) Screen.height));
      this._manager.DoSimpleDisplay();
      if (GUILayout.Button("Detailed", GUILayout.Width((float) Screen.width * 0.2f)))
        this.ShowDetailed(!this._showing);
      GUILayout.EndArea();
    }

    private void OnFormClose(object sender, FormClosingEventArgs e) => this._showing = false;
  }
}
