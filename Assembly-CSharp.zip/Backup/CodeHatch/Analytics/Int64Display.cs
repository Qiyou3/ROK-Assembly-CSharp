﻿// Decompiled with JetBrains decompiler
// Type: CodeHatch.Analytics.Int64Display
// Assembly: Assembly-CSharp, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 7AE521BE-DDCA-4BB1-9869-8132CF2A08FD
// Assembly location: C:\Users\85206\Desktop\Oxide.ReignOfKings-develop\src\Dependencies\windows\ROK_Data\Managed\Assembly-CSharp.dll

using CodeHatch.Engine.Networking;

#nullable disable
namespace CodeHatch.Analytics
{
  public class Int64Display : ConverterBase<long>
  {
    public override byte Id => 7;

    public override IConverter CreateClone() => (IConverter) new Int64Display();

    protected override void WriteValue(IStream stream, long value) => stream.WriteInt64(value);

    protected override long ReadValue(IStream stream) => stream.ReadInt64();
  }
}
