﻿// Decompiled with JetBrains decompiler
// Type: CodeHatch.Analytics.ConvertData`1
// Assembly: Assembly-CSharp, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 7AE521BE-DDCA-4BB1-9869-8132CF2A08FD
// Assembly location: C:\Users\85206\Desktop\Oxide.ReignOfKings-develop\src\Dependencies\windows\ROK_Data\Managed\Assembly-CSharp.dll

using System;
using System.Collections.Generic;
using System.Windows.Forms;

#nullable disable
namespace CodeHatch.Analytics
{
  public class ConvertData<T>
  {
    private const string FORMATTER = "{0} {1}";
    private List<string> _specialKeys;
    private string _key;
    public string Name;
    public T Value;
    public TreeNode Node;
    public short TagCount;

    public string Key
    {
      get => this._key;
      set
      {
        this._key = value;
        this.Name = this.ParseSpecials(value);
      }
    }

    public bool HasSpecial => this._specialKeys != null && this._specialKeys.Count > 0;

    private string ParseSpecials(string value)
    {
      for (int index = 0; index < Converts.SpecialKeys.Length; ++index)
      {
        string specialKey = Converts.SpecialKeys[index];
        int startIndex = value.IndexOf(specialKey, StringComparison.InvariantCultureIgnoreCase);
        if (startIndex >= 0)
        {
          value = value.Remove(startIndex, specialKey.Length);
          if (this._specialKeys == null)
            this._specialKeys = new List<string>();
          this._specialKeys.Add(specialKey);
        }
      }
      return value;
    }

    public bool ContainsSpecial(string key)
    {
      return this._specialKeys != null && this._specialKeys.Contains(key);
    }

    public void UpdateNode(TreeNode parent)
    {
      if (this.Node != null)
      {
        this.Node.Text = this.FullName();
      }
      else
      {
        this.Node = new TreeNode(this.FullName())
        {
          Tag = (object) this.Key
        };
        parent.Nodes.Add(this.Node);
      }
    }

    public string FullName()
    {
      return string.Format("{0} {1}", (object) this.Name, (object) this.Value.ToString());
    }

    public override string ToString()
    {
      return string.Format("{0} {1}", (object) this.Key, (object) this.Value.ToString());
    }
  }
}
