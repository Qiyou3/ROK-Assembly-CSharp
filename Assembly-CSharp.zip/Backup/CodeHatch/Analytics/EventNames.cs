﻿// Decompiled with JetBrains decompiler
// Type: CodeHatch.Analytics.EventNames
// Assembly: Assembly-CSharp, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 7AE521BE-DDCA-4BB1-9869-8132CF2A08FD
// Assembly location: C:\Users\85206\Desktop\Oxide.ReignOfKings-develop\src\Dependencies\windows\ROK_Data\Managed\Assembly-CSharp.dll

#nullable disable
namespace CodeHatch.Analytics
{
  public static class EventNames
  {
    public const string SYNC_SENDS = "Sync Send";
    public const string SYNC_SENDS_RELIABLE = "Sync Send (Reliable)";
    public const string SYNC_SENDS_UNRELIABLE = "Sync Send (Unreliable)";
    public const string SYNC_RECEIVES = "Sync Receive";
    public const string NETWORK_SENDS = "Network Send";
    public const string NETWORK_SENDS_RELIABLE = "Network Send (Reliable)";
    public const string NETWORK_SENDS_UNRELIABLE = "Network Send (Unreliable)";
    public const string NETWORK_RECEIVE = "Network Receive";
    public const string SIMPLE_SEND = "Simple Send";
    public const string SIMPLE_SEND_RELIABLE = "Simple Send (Reliable)";
    public const string SIMPLE_SEND_UNRELIABLE = "Simple Send (Unreliable";
    public const string SIMPLE_RECEIVE = "Simple Receive";
    public const string NETWORK_CATEGORY = "Network Events";
    public const string SYNC_CATEGORY = "Sync Manager";
    public const string NETWORK_SEND_COUNT_CATEGORY = "Network Event Send Counts";
    public const string NETWORK_SEND_RELIABLE_COUNT_CATEGORY = "Network Event Send Counts (Reliable)";
    public const string NETWORK_SEND_UNRELIABLE_COUNT_CATEGORY = "Network Event Send Counts (Unreliable)";
    public const string NETWORK_SEND_DIFF_CATEGORY = "Network Event Send Differences";
    public const string NETWORK_SEND_RELIABLE_DIFF_CATEGORY = "Network Event Send Differences (Reliable)";
    public const string NETWORK_SEND_UNRELIABLE_DIFF_CATEGORY = "Network Event Send Differences (Unreliable)";
    public const string SIMPLE_SEND_COUNT_CATEGORY = "Simple Event Send Counts";
    public const string SIMPLE_SEND_RELIABLE_COUNT_CATEGORY = "Simple Event Send Counts (Reliable)";
    public const string SIMPLE_SEND_UNRELIABLE_COUNT_CATEGORY = "Simple Event Send Counts (Unreliable)";
    public const string NETWORK_RECEIVE_COUNT_CATEGORY = "Network Event Receive Counts";
    public const string NETWORK_RECEIVE_DIFF_CATEGORY = "Network Event Receive Differences";
    public const string SIMPLE_RECEIVE_COUNT_CATEGORY = "Simple Event Receive Counts";
    public const string BASE_CATEGORY_CATEGORY = "Base Events";
    public const string SIMPLE_CATEGORY = "Simple Events";
    public const string DIFF_SEND = "Diff Sends";
    public const string DIFF_SEND_RELIABLE = "Diff Sends";
    public const string DIFF_SEND_UNRELIABLE = "Diff Sends";
    public const string DIFF_RECEIVE = "Diff Receive";
    public const string DIFF_RECEIVE_RELIABLE = "Diff Receive";
    public const string DIFF_RECEIVE_UNRELIABLE = "Diff Receive";
  }
}
