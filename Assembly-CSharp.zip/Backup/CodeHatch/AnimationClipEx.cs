﻿// Decompiled with JetBrains decompiler
// Type: CodeHatch.AnimationClipEx
// Assembly: Assembly-CSharp, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 7AE521BE-DDCA-4BB1-9869-8132CF2A08FD
// Assembly location: C:\Users\85206\Desktop\Oxide.ReignOfKings-develop\src\Dependencies\windows\ROK_Data\Managed\Assembly-CSharp.dll

using System;
using System.Collections.Generic;
using UnityEngine;

#nullable disable
namespace CodeHatch
{
  public class AnimationClipEx : ScriptableObject
  {
    public RuntimeAnimatorController Controller;
    public int AnimationStateID;
    public int AnimationLayerIndex = 6;
    public AnimationClip AnimationClip;
    public bool Looping;
    public AnimationCurve TimeRemapping = new AnimationCurve(new Keyframe[2]
    {
      new Keyframe(0.0f, 0.0f),
      new Keyframe(1f, 1f)
    });
    public AnimationCurve WeightOverProgress = new AnimationCurve(new Keyframe[4]
    {
      new Keyframe(0.0f, 0.0f),
      new Keyframe(0.1f, 1f),
      new Keyframe(0.9f, 1f),
      new Keyframe(1f, 0.0f)
    });
    public List<float> Divisions = new List<float>();
    public BipedAnimator.Limits HeadTranslationLimits = new BipedAnimator.Limits();
    public BipedAnimator.LookWeights LookWeights = new BipedAnimator.LookWeights();
    public BipedAnimator.LookCurves LookCurves = new BipedAnimator.LookCurves();
    public bool UseLookCurves;
    public AnimationCurve LookSpeedLimitationWeight = new AnimationCurve();
    public AnimationCurve MoveSpeedLimitationWeight = new AnimationCurve();

    public float Length
    {
      get
      {
        if (!((UnityEngine.Object) this.AnimationClip == (UnityEngine.Object) null))
          return this.AnimationClip.length;
        this.LogError<AnimationClipEx>("AnimationClip == null");
        return 1f;
      }
    }

    public int SegmentCount => this.Divisions.Count + 1;

    public int LastSegment => this.Divisions.Count;

    public float MinProgress => 0.0f;

    public float MaxProgress => (float) this.SegmentCount;

    public void GetSegmentAnimationRange(int segment, out float start, out float end)
    {
      if (segment >= this.SegmentCount || segment < 0)
        throw new ArgumentOutOfRangeException(nameof (segment));
      start = segment != 0 ? this.Divisions[segment - 1] : 0.0f;
      if (segment == this.LastSegment)
        end = 1f;
      else
        end = this.Divisions[segment];
    }

    public void GetSegmentCurveRange(int segment, out float start, out float end)
    {
      if (segment >= this.SegmentCount || segment < 0)
        throw new ArgumentOutOfRangeException(nameof (segment));
      start = segment != 0 ? (float) segment : 0.0f;
      if (segment == this.LastSegment)
        end = (float) this.SegmentCount;
      else
        end = (float) (segment + 1);
    }

    public float GetClipSampleProgress(float progress)
    {
      float remappedProgress = this.GetTimeRemappedProgress(progress);
      int segment = Mathf.FloorToInt(remappedProgress);
      if (segment > this.LastSegment)
        segment = this.LastSegment;
      if (segment < 0)
        segment = 0;
      float t = Mathf.Clamp01(remappedProgress - (float) segment);
      float start;
      float end;
      this.GetSegmentAnimationRange(segment, out start, out end);
      return Mathf.Lerp(start, end, t);
    }

    public float GetTimeRemappedProgress(float progress) => this.TimeRemapping.Evaluate(progress);

    public float GetWeight(float progress)
    {
      return this.WeightOverProgress.Evaluate(this.GetTimeRemappedProgress(progress));
    }

    public void Play(Animator animator, float progress, float weightMultiplier)
    {
      animator.Play(this.AnimationStateID, this.AnimationLayerIndex, this.GetClipSampleProgress(progress));
      animator.SetLayerWeight(this.AnimationLayerIndex, this.GetWeight(progress) * weightMultiplier);
    }

    public void Stop(Animator animator) => animator.SetLayerWeight(this.AnimationLayerIndex, 0.0f);

    public float GetLoopedProgress(float progress)
    {
      return Mathf.Repeat(progress - this.MinProgress, this.MaxProgress) + this.MinProgress;
    }

    public bool IsProgressWithinRange(float progress)
    {
      if (this.Looping)
        return true;
      return (double) progress >= (double) this.MinProgress && (double) progress <= (double) this.MaxProgress;
    }

    public float GetLookSpeedLimitationWeight(float progress)
    {
      return this.LookSpeedLimitationWeight.Evaluate(this.GetTimeRemappedProgress(progress));
    }

    public float GetMoveSpeedLimitationWeight(float progress)
    {
      return this.MoveSpeedLimitationWeight.Evaluate(this.GetTimeRemappedProgress(progress));
    }
  }
}
