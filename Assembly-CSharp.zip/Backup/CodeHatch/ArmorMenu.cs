﻿// Decompiled with JetBrains decompiler
// Type: CodeHatch.ArmorMenu
// Assembly: Assembly-CSharp, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 7AE521BE-DDCA-4BB1-9869-8132CF2A08FD
// Assembly location: C:\Users\85206\Desktop\Oxide.ReignOfKings-develop\src\Dependencies\windows\ROK_Data\Managed\Assembly-CSharp.dll

using UnityEngine;

#nullable disable
namespace CodeHatch
{
  public abstract class ArmorMenu : MonoBehaviour
  {
    protected static ArmorMenu Instance;

    public void Awake()
    {
      if ((Object) ArmorMenu.Instance == (Object) null)
        ArmorMenu.Instance = this;
      else
        Logger.Error(string.Format("{0} instance is already awake, this instance was not assigned.", (object) this.GetType()));
    }

    public void OnDestroy()
    {
      if ((Object) ArmorMenu.Instance == (Object) this)
        ArmorMenu.Instance = (ArmorMenu) null;
      else
        Logger.Error(string.Format("{0} instance was already awake, this instance was not removed.", (object) this.GetType()));
    }

    public static void UpdateDefense()
    {
      if ((Object) ArmorMenu.Instance == (Object) null)
        return;
      ArmorMenu.Instance.UpdateDefenseInstance();
    }

    public abstract void UpdateDefenseInstance();
  }
}
