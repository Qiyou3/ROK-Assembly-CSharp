﻿// Decompiled with JetBrains decompiler
// Type: CodeHatch.Blocks.BlockManager
// Assembly: Assembly-CSharp, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 7AE521BE-DDCA-4BB1-9869-8132CF2A08FD
// Assembly location: C:\Users\85206\Desktop\Oxide.ReignOfKings-develop\src\Dependencies\windows\ROK_Data\Managed\Assembly-CSharp.dll

using CodeHatch.Blocks.Geometry;
using CodeHatch.Common;
using System.Collections.Generic;
using UnityEngine;

#nullable disable
namespace CodeHatch.Blocks
{
  public class BlockManager : Singleton<BlockManager>
  {
    private const string NON_TAG = "NonOctPrefab";
    public const float BLOCK_SIZE = 1.2f;
    public const float BLOCK_SIZE_HALF = 0.6f;
    public const float BLOCK_SIZE_SQR = 1.44f;
    private static List<RootCubeGrid> _AllCubeGrids;
    private Transform _RLEParent;
    private Transform _GridPool;
    private List<RLECollider> _ColliderPool;
    private List<RLERenderer> _RendererPool;
    [SerializeField]
    private RLECollider _ColliderPrefab;
    [SerializeField]
    private RLERenderer _RendererPrefab;
    private CubeDelayProvider _DelayProvider;
    [SerializeField]
    private float[] _LODLevels = new float[3]
    {
      25f,
      50f,
      100f
    };
    [SerializeField]
    private int _maxPoolSize = 400;
    private static int _cubeLayer = -1;

    public static bool IsTaggedNonOctPrefab(GameObject theObject)
    {
      return theObject.tag == "NonOctPrefab";
    }

    public static Vector3 ToWorld(Vector3Int position)
    {
      return BlockManager.ToWorld(position, BlockManager.DefaultCubeGrid);
    }

    public static Vector3 ToWorld(Vector3Int position, RootCubeGrid grid)
    {
      return grid.LocalToWorldCoordinate(position);
    }

    public static Vector3Int FromWorld(Vector3 position)
    {
      return BlockManager.FromWorld(position, BlockManager.DefaultCubeGrid);
    }

    public static Vector3Int FromWorld(Vector3 position, RootCubeGrid grid)
    {
      return grid.WorldToLocalCoordinate(position);
    }

    public static bool IsBlockOrDoor(Collider collider)
    {
      return !((Object) collider == (Object) null) && BlockManager.IsBlockOrDoor(collider.gameObject);
    }

    public static bool IsBlockOrDoor(GameObject theObject)
    {
      if ((Object) theObject == (Object) null)
        return false;
      bool flag = (Object) theObject.FirstComponentAncestor<OctPrefab>() != (Object) null;
      if (!flag && theObject.layer == BlockManager.CubeLayer && theObject.tag != "NonOctPrefab")
        flag = true;
      return flag;
    }

    public static List<RootCubeGrid> AllCubeGrids
    {
      get
      {
        if (BlockManager._AllCubeGrids == null)
          BlockManager._AllCubeGrids = new List<RootCubeGrid>();
        return BlockManager._AllCubeGrids;
      }
    }

    public static RootCubeGrid DefaultCubeGrid => BlockManager.GetGrid((ushort) 0);

    public Transform RLEParent
    {
      get
      {
        if ((Object) this._RLEParent == (Object) null)
        {
          this._RLEParent = new GameObject("RLE Pool").transform;
          this._RLEParent.transform.parent = this.transform;
          this._RLEParent.transform.localPosition = Vector3.zero;
          this._RLEParent.transform.localRotation = Quaternion.identity;
          this._RLEParent.transform.localScale = Vector3.one;
        }
        return this._RLEParent;
      }
    }

    public Transform GridPool
    {
      get
      {
        if ((Object) this._GridPool == (Object) null)
        {
          this._GridPool = new GameObject("Cube Grids").transform;
          this._GridPool.transform.parent = this.transform;
          this._GridPool.transform.localPosition = Vector3.zero;
          this._GridPool.transform.localRotation = Quaternion.identity;
          this._GridPool.transform.localScale = Vector3.one;
        }
        return this._GridPool;
      }
    }

    protected List<RLECollider> ColliderPool
    {
      get
      {
        if (this._ColliderPool == null)
          this._ColliderPool = new List<RLECollider>();
        return this._ColliderPool;
      }
    }

    protected List<RLERenderer> RendererPool
    {
      get
      {
        if (this._RendererPool == null)
          this._RendererPool = new List<RLERenderer>();
        return this._RendererPool;
      }
    }

    public CubeDelayProvider DelayProvider
    {
      get
      {
        if ((Object) this._DelayProvider == (Object) null)
          this._DelayProvider = this.GetComponent<CubeDelayProvider>();
        return this._DelayProvider;
      }
    }

    public float[] LODLevels => this._LODLevels;

    public static int CubeLayer
    {
      get
      {
        if (BlockManager._cubeLayer < 0)
          BlockManager._cubeLayer = LayerMask.NameToLayer("Blocks");
        return BlockManager._cubeLayer;
      }
    }

    public static int TotalBlockCount
    {
      get
      {
        int totalBlockCount = 0;
        foreach (RootCubeGrid allCubeGrid in BlockManager.AllCubeGrids)
        {
          if ((Object) allCubeGrid != (Object) null)
            totalBlockCount += allCubeGrid.GetTotalBlockCount();
        }
        return totalBlockCount;
      }
    }

    public override void OnDestroy()
    {
      base.OnDestroy();
      BlockManager._AllCubeGrids = (List<RootCubeGrid>) null;
      BlockMessaging.Instance.Dispose();
    }

    public static RootCubeGrid GetGrid(ushort gridID)
    {
      RootCubeGrid grid = (RootCubeGrid) null;
      if (BlockManager.AllCubeGrids.Count > (int) gridID)
        grid = BlockManager.AllCubeGrids[(int) gridID];
      return grid;
    }

    public RLECollider GetPooledRLECollider()
    {
      if (this.ColliderPool.Count > 0)
      {
        RLECollider pooledRleCollider = this.ColliderPool[this.ColliderPool.Count - 1];
        this.ColliderPool.RemoveAt(this.ColliderPool.Count - 1);
        return pooledRleCollider;
      }
      RLECollider pooledRleCollider1 = Object.Instantiate<RLECollider>(this._ColliderPrefab);
      pooledRleCollider1.transform.parent = this.RLEParent;
      pooledRleCollider1.transform.localScale = Vector3.one;
      pooledRleCollider1.transform.localRotation = Quaternion.identity;
      return pooledRleCollider1;
    }

    public void ReturnRLECollider(RLECollider areaToReturn)
    {
      if (this.ColliderPool.Count + 1 > this._maxPoolSize)
      {
        Object.Destroy((Object) areaToReturn.gameObject);
      }
      else
      {
        areaToReturn.PoolObj();
        this.ColliderPool.Add(areaToReturn);
      }
    }

    public RLERenderer GetPooledRLERenderer()
    {
      if (this.RendererPool.Count > 0)
      {
        RLERenderer pooledRleRenderer = this.RendererPool[this.RendererPool.Count - 1];
        this.RendererPool.RemoveAt(this.RendererPool.Count - 1);
        return pooledRleRenderer;
      }
      RLERenderer pooledRleRenderer1 = Object.Instantiate<RLERenderer>(this._RendererPrefab);
      pooledRleRenderer1.transform.parent = this.RLEParent;
      pooledRleRenderer1.transform.localScale = Vector3.one;
      pooledRleRenderer1.transform.localRotation = Quaternion.identity;
      return pooledRleRenderer1;
    }

    public void ReturnRLERenderer(RLERenderer areaToReturn)
    {
      if (this.RendererPool.Count + 1 > this._maxPoolSize)
      {
        Object.Destroy((Object) areaToReturn.gameObject);
      }
      else
      {
        areaToReturn.PoolObj();
        this.RendererPool.Add(areaToReturn);
      }
    }
  }
}
