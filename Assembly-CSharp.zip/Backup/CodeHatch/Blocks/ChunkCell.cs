﻿// Decompiled with JetBrains decompiler
// Type: CodeHatch.Blocks.ChunkCell
// Assembly: Assembly-CSharp, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 7AE521BE-DDCA-4BB1-9869-8132CF2A08FD
// Assembly location: C:\Users\85206\Desktop\Oxide.ReignOfKings-develop\src\Dependencies\windows\ROK_Data\Managed\Assembly-CSharp.dll

using CodeHatch.Common;
using CodeHatch.UnityQualitySettings;
using System.Collections;
using System.Diagnostics;
using UnityEngine;

#nullable disable
namespace CodeHatch.Blocks
{
  public class ChunkCell : RootCell
  {
    private bool _HasInitedArray;

    public CubeInfo[,,] CubeGrid { get; set; }

    public int LODLevel { get; set; }

    private float LODBias
    {
      get
      {
        return (Object) LODBiasQuality.Instance != (Object) null ? LODBiasQuality.Instance.BlockBias : QualitySettings.lodBias;
      }
    }

    protected override void InitCubeArray()
    {
      if (this._HasInitedArray)
        return;
      this._HasInitedArray = true;
      int cellSize = SingletonMonoBehaviour<ChunkSettings>.Instance.CellSize;
      this.CubeGrid = new CubeInfo[cellSize, cellSize, cellSize];
    }

    protected override CubeInfo[,,] GetArrayAtPoint(Vector3Int coordinate, bool forceCreate)
    {
      return this.CubeGrid;
    }

    [DebuggerHidden]
    protected override IEnumerator CleanupRoutine()
    {
      // ISSUE: object of a compiler-generated type is created
      // ISSUE: variable of a compiler-generated type
      ChunkCell.\u003CCleanupRoutine\u003Ec__Iterator15 routineCIterator15 = new ChunkCell.\u003CCleanupRoutine\u003Ec__Iterator15();
      return (IEnumerator) routineCIterator15;
    }

    protected override int GetLODAtCoord(Vector3Int coordinate) => this.LODLevel;

    public override long GetEstimatedMemoryConsumption()
    {
      return (long) (this.CubeGrid.GetLength(0) * this.CubeGrid.GetLength(1) * this.CubeGrid.GetLength(2) * 23);
    }
  }
}
