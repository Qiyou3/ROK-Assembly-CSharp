﻿// Decompiled with JetBrains decompiler
// Type: CodeHatch.Blocks.BlockHealth
// Assembly: Assembly-CSharp, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 7AE521BE-DDCA-4BB1-9869-8132CF2A08FD
// Assembly location: C:\Users\85206\Desktop\Oxide.ReignOfKings-develop\src\Dependencies\windows\ROK_Data\Managed\Assembly-CSharp.dll

using CodeHatch.Common.Attributes;
using CodeHatch.Damaging;
using CodeHatch.Engine.Modding.Abstract;
using CodeHatch.Engine.Networking;
using CodeHatch.Engine.Serialization;
using CodeHatch.Thrones.Weapons.Salvage;
using System.Collections.Generic;
using UnityEngine;

#nullable disable
namespace CodeHatch.Blocks
{
  public class BlockHealth : MonoBehaviour, IHealth, IModable, ISerializable
  {
    private const DamageType SEIGE_ONLY_DAMAGE_TYPE = DamageType.Projectile | DamageType.Pierce | DamageType.Bash | DamageType.Slash;
    [Designer]
    [MinValue(0.0f)]
    [SerializeField]
    [Tooltip("Maximum possible health of this object. CurrentHealth is reset to this on load/on instantiate.")]
    private float _MaxHealth = 50f;
    [SerializeField]
    [Tooltip("Current health of this object. Is reset to MaxHealth on load/instantiate.")]
    [MinValue(0.0f)]
    private float _CurrentHealth;
    [Tooltip("If true the block cannot take damage.")]
    [SerializeField]
    private bool _isInvincible;
    [SerializeField]
    [Tooltip("If true the block cannot be killed. Only Destroyed.")]
    private bool _preventDeath;

    public float MaxHealth
    {
      get => this._MaxHealth;
      set
      {
        this._MaxHealth = (double) value >= 0.0 ? value : 0.0f;
        this.CurrentHealth = this._CurrentHealth;
      }
    }

    public float CurrentHealth
    {
      get => this._CurrentHealth;
      set
      {
        this._CurrentHealth = (double) value >= 0.0 ? ((double) value <= (double) this.MaxHealth ? value : this.MaxHealth) : 0.0f;
        if ((double) value > 0.0)
          return;
        this.Kill();
      }
    }

    public float CurrentHealthPercent
    {
      get
      {
        return (double) this.MaxHealth > (double) Mathf.Epsilon ? this.CurrentHealth / this.MaxHealth : 0.0f;
      }
    }

    public bool IsInvincible
    {
      get => this._isInvincible;
      set => this._isInvincible = value;
    }

    public bool PreventDeath
    {
      get => this._preventDeath;
      set => this._preventDeath = value;
    }

    public bool IsDead => (double) this.CurrentHealth == 0.0;

    public bool IsAlive => !this.IsDead;

    public void OnValidate()
    {
      if (!Application.isPlaying)
        this.CurrentHealth = this.MaxHealth;
      else
        this.CurrentHealth = this._CurrentHealth;
    }

    public void Revive() => this.Revive(this.MaxHealth);

    public void Revive(float newHealth) => this.CurrentHealth = newHealth;

    public void SetHealth(float newHealth) => this.CurrentHealth = newHealth;

    public void UpdateMaxHealth(float newMax, bool updateHealth)
    {
      this.MaxHealth = newMax;
      if (!updateHealth)
        return;
      this.Revive(this.MaxHealth);
    }

    public bool Kill() => this.Kill((Damage) null);

    public bool Kill(Damage killingDamage)
    {
      if (this.PreventDeath)
        return false;
      if (killingDamage != null)
        killingDamage.IsFatal = true;
      return true;
    }

    public string Identifier { get; private set; }

    public void Serialize(IStream stream) => stream.Write<float>(this.CurrentHealth);

    public void Deserialize(IStream stream) => this.CurrentHealth = stream.ReadSingle();

    public string ModHandlerName => "Health";

    public void GetModDefaults(IList<ModEntry> defaultModEntries)
    {
      defaultModEntries.Add(new ModEntry("MaxHealth", (object) this.MaxHealth));
      defaultModEntries.Add(new ModEntry("IsInvincible", (object) this.IsInvincible));
      DamageTypeModifier damageTypeModifier = this.GetComponent<DamageTypeModifier>();
      if ((Object) damageTypeModifier == (Object) null)
        damageTypeModifier = this.gameObject.AddComponent<DamageTypeModifier>();
      if (damageTypeModifier.ModifyTypes == null)
        damageTypeModifier.ModifyTypes = new DamageVulnerability[0];
      bool flag = true;
      for (int index = 0; index < damageTypeModifier.ModifyTypes.Length; ++index)
      {
        DamageVulnerability modifyType = damageTypeModifier.ModifyTypes[index];
        if (modifyType.TheType == (DamageType.Projectile | DamageType.Pierce | DamageType.Bash | DamageType.Slash) && (double) modifyType.DamageModifier == 0.0)
        {
          flag = false;
          break;
        }
      }
      defaultModEntries.Add(new ModEntry("DamagedByWeapons", (object) flag));
      SalvageModifier component = this.GetComponent<SalvageModifier>();
      if (!((Object) component != (Object) null))
        return;
      defaultModEntries.Add(new ModEntry("IsSalvageable", (object) !component.info.NotSalvageable));
      defaultModEntries.Add(new ModEntry("SalvageDamageMultiplier", (object) component.info.Modifier));
      defaultModEntries.Add(new ModEntry("ResourceSalvagePercent", (object) (float) ((double) component.info.SalvageAmount * 100.0), "The percent of the resources that can be salvaged. (0 to 100)"));
    }

    public void ApplyMod(string key, object value)
    {
      if (value == null)
        return;
      string key1 = key;
      if (key1 == null)
        return;
      // ISSUE: reference to a compiler-generated field
      if (BlockHealth.\u003C\u003Ef__switch\u0024map0 == null)
      {
        // ISSUE: reference to a compiler-generated field
        BlockHealth.\u003C\u003Ef__switch\u0024map0 = new Dictionary<string, int>(6)
        {
          {
            "MaxHealth",
            0
          },
          {
            "IsInvincible",
            1
          },
          {
            "DamagedByWeapons",
            2
          },
          {
            "IsSalvageable",
            3
          },
          {
            "SalvageDamageMultiplier",
            4
          },
          {
            "ResourceSalvagePercent",
            5
          }
        };
      }
      int num;
      // ISSUE: reference to a compiler-generated field
      if (!BlockHealth.\u003C\u003Ef__switch\u0024map0.TryGetValue(key1, out num))
        return;
      switch (num)
      {
        case 0:
          float maxHealth = this._MaxHealth;
          this._MaxHealth = (float) value;
          this._CurrentHealth *= this._MaxHealth / maxHealth;
          break;
        case 1:
          this.IsInvincible = (bool) value;
          break;
        case 2:
          DamageTypeModifier component1 = this.GetComponent<DamageTypeModifier>();
          if (!((Object) component1 != (Object) null))
            break;
          if ((bool) value)
          {
            for (int index = 0; index < component1.ModifyTypes.Length; ++index)
            {
              DamageVulnerability modifyType = component1.ModifyTypes[index];
              if (modifyType.TheType == (DamageType.Projectile | DamageType.Pierce | DamageType.Bash | DamageType.Slash) && (double) modifyType.DamageModifier == 0.0)
              {
                List<DamageVulnerability> damageVulnerabilityList = new List<DamageVulnerability>((IEnumerable<DamageVulnerability>) component1.ModifyTypes);
                damageVulnerabilityList.Remove(modifyType);
                component1.ModifyTypes = damageVulnerabilityList.ToArray();
                break;
              }
            }
            break;
          }
          bool flag = false;
          for (int index = 0; index < component1.ModifyTypes.Length; ++index)
          {
            DamageVulnerability modifyType = component1.ModifyTypes[index];
            if (modifyType.TheType == (DamageType.Projectile | DamageType.Pierce | DamageType.Bash | DamageType.Slash) && (double) modifyType.DamageModifier == 0.0)
            {
              flag = true;
              break;
            }
          }
          if (flag)
            break;
          List<DamageVulnerability> damageVulnerabilityList1 = new List<DamageVulnerability>((IEnumerable<DamageVulnerability>) component1.ModifyTypes);
          DamageVulnerability damageVulnerability = new DamageVulnerability();
          damageVulnerabilityList1.Add(damageVulnerability);
          component1.ModifyTypes = damageVulnerabilityList1.ToArray();
          damageVulnerability.TheType = DamageType.Projectile | DamageType.Pierce | DamageType.Bash | DamageType.Slash;
          damageVulnerability.DamageModifier = 0.0f;
          break;
        case 3:
          SalvageModifier component2 = this.GetComponent<SalvageModifier>();
          if (!((Object) component2 != (Object) null))
            break;
          component2.info.NotSalvageable = !(bool) value;
          break;
        case 4:
          SalvageModifier component3 = this.GetComponent<SalvageModifier>();
          if (!((Object) component3 != (Object) null))
            break;
          component3.info.Modifier = Mathf.Clamp((float) value, 0.0f, float.MaxValue);
          break;
        case 5:
          SalvageModifier component4 = this.GetComponent<SalvageModifier>();
          if (!((Object) component4 != (Object) null))
            break;
          component4.info.SalvageAmount = Mathf.Clamp((float) value, 0.0f, 1000000f) / 100f;
          break;
      }
    }
  }
}
