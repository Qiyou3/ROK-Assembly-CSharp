﻿// Decompiled with JetBrains decompiler
// Type: CodeHatch.Blocks.CubeDelayProvider
// Assembly: Assembly-CSharp, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 7AE521BE-DDCA-4BB1-9869-8132CF2A08FD
// Assembly location: C:\Users\85206\Desktop\Oxide.ReignOfKings-develop\src\Dependencies\windows\ROK_Data\Managed\Assembly-CSharp.dll

using CodeHatch.Blocks.Geometry;
using UnityEngine;

#nullable disable
namespace CodeHatch.Blocks
{
  public class CubeDelayProvider : MonoBehaviour
  {
    public bool InstantBuild;
    public float BlockRemovalTime = 0.5f;

    public virtual float GetDelay(byte materialID, byte prefabID)
    {
      if (this.InstantBuild)
        return 0.0f;
      if ((int) materialID == (int) CubeInfo.Air.MaterialID)
        return this.InstantBuild ? 0.0f : this.BlockRemovalTime;
      OctTileset tilesetWithId = TilesetLibrary.GetTilesetWithID(materialID);
      if (!((Object) tilesetWithId != (Object) null))
        return 0.0f;
      if (prefabID == (byte) 0)
        return tilesetWithId.BuildTime;
      OctPrefab prefabWithId = tilesetWithId.GetPrefabWithID((int) prefabID);
      return (Object) prefabWithId != (Object) null && !Mathf.Approximately(0.0f, prefabWithId.BuildTime) && (double) prefabWithId.BuildTime >= 0.0 ? prefabWithId.BuildTime : tilesetWithId.BuildTime;
    }
  }
}
