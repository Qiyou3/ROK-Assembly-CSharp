﻿// Decompiled with JetBrains decompiler
// Type: CodeHatch.Blocks.BlockMessaging
// Assembly: Assembly-CSharp, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 7AE521BE-DDCA-4BB1-9869-8132CF2A08FD
// Assembly location: C:\Users\85206\Desktop\Oxide.ReignOfKings-develop\src\Dependencies\windows\ROK_Data\Managed\Assembly-CSharp.dll

using CodeHatch.Blocks.Collapsing;
using CodeHatch.Blocks.Networking.Events;
using CodeHatch.Blocks.Networking.Events.Local;
using CodeHatch.Common;
using CodeHatch.Core;
using CodeHatch.Engine.Core.Paging;
using CodeHatch.Engine.Networking;
using CodeHatch.Networking;
using CodeHatch.Networking.Events;
using CodeHatch.Thrones.SocialSystem.Objects;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using UnityEngine;

#nullable disable
namespace CodeHatch.Blocks
{
  public class BlockMessaging
  {
    private const int JUST_HANDLE_COUNT = 10;
    private Dictionary<Vector3Int, List<BaseEvent>> _heldEvents = new Dictionary<Vector3Int, List<BaseEvent>>((IEqualityComparer<Vector3Int>) new Vector3IntEqualityComparer());
    private static BlockMessaging _instance;

    public static BlockMessaging Instance
    {
      get
      {
        if (BlockMessaging._instance == null)
        {
          BlockMessaging._instance = new BlockMessaging();
          BlockMessaging._instance.Init();
        }
        return BlockMessaging._instance;
      }
    }

    public void Init()
    {
      if (Player.IsLocalServer)
        return;
      EventManager.Subscribe<CubePlaceLocalEvent>(new EventSubscriber<CubePlaceLocalEvent>(this.OnCubePlaceLocal), EventHandlerOrder.VeryEarly);
      EventManager.Subscribe<CubePlaceEvent>(new EventSubscriber<CubePlaceEvent>(this.OnCubePlace), EventHandlerOrder.VeryEarly);
      EventManager.Subscribe<CubeCollectEvent>(new EventSubscriber<CubeCollectEvent>(this.OnCubeCollect), EventHandlerOrder.VeryEarly);
      EventManager.Subscribe<CubeColorEvent>(new EventSubscriber<CubeColorEvent>(this.OnCubeColor), EventHandlerOrder.VeryEarly);
      EventManager.Subscribe<CubeDamageEvent>(new EventSubscriber<CubeDamageEvent>(this.OnCubeDamage), EventHandlerOrder.VeryEarly);
      EventManager.Subscribe<CubeDestroyEvent>(new EventSubscriber<CubeDestroyEvent>(this.OnCubeDestroy), EventHandlerOrder.VeryEarly);
      EventManager.Subscribe<MassCubeDestroyEvent>(new EventSubscriber<MassCubeDestroyEvent>(this.OnMassCubeDestroy), EventHandlerOrder.VeryEarly);
      EventManager.Subscribe<ObjectUseEvent>(new EventSubscriber<ObjectUseEvent>(this.OnObjectUse), EventHandlerOrder.VeryEarly);
      EventManager.Subscribe<FloatingChunkDetectedEvent>(new EventSubscriber<FloatingChunkDetectedEvent>(this.OnFloatingChunk), EventHandlerOrder.VeryEarly);
    }

    public void Dispose()
    {
      if (Player.IsLocalServer)
        return;
      BlockMessaging._instance = (BlockMessaging) null;
      EventManager.Unsubscribe<CubePlaceLocalEvent>(new EventSubscriber<CubePlaceLocalEvent>(this.OnCubePlaceLocal));
      EventManager.Unsubscribe<CubePlaceEvent>(new EventSubscriber<CubePlaceEvent>(this.OnCubePlace));
      EventManager.Unsubscribe<CubeCollectEvent>(new EventSubscriber<CubeCollectEvent>(this.OnCubeCollect));
      EventManager.Unsubscribe<CubeColorEvent>(new EventSubscriber<CubeColorEvent>(this.OnCubeColor));
      EventManager.Unsubscribe<CubeDamageEvent>(new EventSubscriber<CubeDamageEvent>(this.OnCubeDamage));
      EventManager.Unsubscribe<CubeDestroyEvent>(new EventSubscriber<CubeDestroyEvent>(this.OnCubeDestroy));
      EventManager.Unsubscribe<MassCubeDestroyEvent>(new EventSubscriber<MassCubeDestroyEvent>(this.OnMassCubeDestroy));
      EventManager.Unsubscribe<ObjectUseEvent>(new EventSubscriber<ObjectUseEvent>(this.OnObjectUse));
      EventManager.Unsubscribe<FloatingChunkDetectedEvent>(new EventSubscriber<FloatingChunkDetectedEvent>(this.OnFloatingChunk));
    }

    private void OnFloatingChunk(FloatingChunkDetectedEvent theEvent)
    {
      FloatingChunk floatingChunk = theEvent.FloatingChunk;
      if (floatingChunk == null || floatingChunk.BlockCoords == null)
        return;
      Vector3 zero = Vector3.zero;
      for (int index = 0; index < floatingChunk.BlockCoords.Length; ++index)
        zero += (Vector3) floatingChunk.BlockCoords[index];
      if (!this.ShouldWait(BlockManager.DefaultCubeGrid.LocalToWorldCoordinate(new Vector3Int(zero / (float) floatingChunk.BlockCoords.Length)), (BaseEvent) theEvent))
        return;
      theEvent.Cancel();
    }

    private void OnObjectUse(ObjectUseEvent theEvent)
    {
      if (!this.ShouldWait(theEvent.Position, (BaseEvent) theEvent))
        return;
      theEvent.Cancel();
    }

    private void OnMassCubeDestroy(MassCubeDestroyEvent theEvent)
    {
      if (!this.ShouldWait(theEvent.Position[0], (BaseEvent) theEvent))
        return;
      theEvent.Cancel();
    }

    private void OnCubeDestroy(CubeDestroyEvent theEvent)
    {
      if (!this.ShouldWait(theEvent.Position, (BaseEvent) theEvent))
        return;
      theEvent.Cancel();
    }

    private static Vector3Int BlockToPage(Vector3Int blockCoord)
    {
      return PagingAPI.WorldToPageCoords(BlockManager.ToWorld(blockCoord));
    }

    private void OnCubeDamage(CubeDamageEvent theEvent)
    {
      if (!this.ShouldWait(theEvent.Position, (BaseEvent) theEvent))
        return;
      theEvent.Cancel();
    }

    private void OnCubeColor(CubeColorEvent theEvent)
    {
      if (!this.ShouldWait(theEvent.Position, (BaseEvent) theEvent))
        return;
      theEvent.Cancel();
    }

    private void OnCubeCollect(CubeCollectEvent theEvent)
    {
      if (!this.ShouldWait(theEvent.Position, (BaseEvent) theEvent))
        return;
      theEvent.Cancel();
    }

    private void OnCubePlace(CubePlaceEvent theEvent)
    {
      if (!this.ShouldWait(theEvent.Position, (BaseEvent) theEvent))
        return;
      theEvent.Cancel();
    }

    private void OnCubePlaceLocal(CubePlaceLocalEvent theEvent)
    {
      if (!this.ShouldWait(theEvent.PlaceEvent.Position, (BaseEvent) theEvent))
        return;
      theEvent.Cancel();
    }

    public bool ShouldWait(Vector3 blockCoord, BaseEvent theEvent)
    {
      return this.ShouldWaitPage(PagingAPI.WorldToPageCoords(blockCoord), theEvent);
    }

    public bool ShouldWait(Vector3Int blockCoord, BaseEvent theEvent)
    {
      return this.ShouldWaitPage(BlockMessaging.BlockToPage(blockCoord), theEvent);
    }

    public bool ShouldWaitPage(Vector3Int pageCoord, BaseEvent theEvent)
    {
      if (!this._heldEvents.ContainsKey(pageCoord))
        return false;
      this._heldEvents[pageCoord].Add(theEvent);
      return true;
    }

    public static void Start(ControlType control, Vector3Int pageCoord)
    {
      try
      {
        BlockMessaging instance = BlockMessaging.Instance;
        if (instance._heldEvents.ContainsKey(pageCoord))
          return;
        instance._heldEvents[pageCoord] = new List<BaseEvent>();
      }
      catch (Exception ex)
      {
        Logger.Exception(ex);
      }
    }

    public static void End(ControlType control, Vector3Int pageCoord)
    {
      BlockMessaging instance = BlockMessaging.Instance;
      try
      {
        if (!instance._heldEvents.ContainsKey(pageCoord))
          return;
        List<BaseEvent> heldEvent = instance._heldEvents[pageCoord];
        instance._heldEvents.Remove(pageCoord);
        instance.HandleEvents(heldEvent);
      }
      catch (Exception ex)
      {
        Logger.Exception(ex);
      }
      finally
      {
        instance._heldEvents.Remove(pageCoord);
      }
    }

    private void HandleEvents(List<BaseEvent> events)
    {
      if (events.Count == 0)
        return;
      if (events.Count > 10)
      {
        Coroutiner.StartStaticCoroutine(this.HandleOverTime(events));
      }
      else
      {
        for (int index = 0; index < events.Count; ++index)
        {
          BaseEvent theEvent = events[index];
          theEvent.Uncancel();
          EventManager.HandleEvent(theEvent);
        }
      }
    }

    [DebuggerHidden]
    private IEnumerator HandleOverTime(List<BaseEvent> events)
    {
      // ISSUE: object of a compiler-generated type is created
      return (IEnumerator) new BlockMessaging.\u003CHandleOverTime\u003Ec__Iterator0()
      {
        events = events,
        \u003C\u0024\u003Eevents = events
      };
    }
  }
}
