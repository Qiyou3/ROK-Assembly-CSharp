﻿// Decompiled with JetBrains decompiler
// Type: CodeHatch.Blocks.ChunkGrid
// Assembly: Assembly-CSharp, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 7AE521BE-DDCA-4BB1-9869-8132CF2A08FD
// Assembly location: C:\Users\85206\Desktop\Oxide.ReignOfKings-develop\src\Dependencies\windows\ROK_Data\Managed\Assembly-CSharp.dll

using CodeHatch.Common;
using System;
using System.Collections.Generic;
using UnityEngine;

#nullable disable
namespace CodeHatch.Blocks
{
  public class ChunkGrid : RootCubeGrid
  {
    private Dictionary<Vector3Int, ChunkCell> _CellGrid;
    private List<ChunkCell> _InactivePool;
    private Transform _InactiveParent;

    public Dictionary<Vector3Int, ChunkCell> CellGrid
    {
      get
      {
        if (this._CellGrid == null)
          this._CellGrid = new Dictionary<Vector3Int, ChunkCell>((IEqualityComparer<Vector3Int>) new Vector3IntEqualityComparer());
        return this._CellGrid;
      }
    }

    public List<ChunkCell> InactivePool
    {
      get
      {
        if (this._InactivePool == null)
          this._InactivePool = new List<ChunkCell>();
        return this._InactivePool;
      }
    }

    public Transform InactiveParent
    {
      get
      {
        if ((UnityEngine.Object) this._InactiveParent == (UnityEngine.Object) null)
        {
          this._InactiveParent = new GameObject("Inactive Cells").transform;
          this._InactiveParent.parent = this.CachedTransform;
        }
        return this._InactiveParent;
      }
    }

    internal override RootCell GetCellAt(
      Vector3Int localCoordinate,
      bool shouldCreate,
      bool required = false)
    {
      Vector3Int cellCoord = this.GetCellCoord(localCoordinate);
      if (!this.CellGrid.ContainsKey(cellCoord))
      {
        ChunkCell pooledChunk = this.GetPooledChunk();
        int cellSize = SingletonMonoBehaviour<ChunkSettings>.Instance.CellSize;
        int num1 = cellSize;
        int num2 = cellSize;
        pooledChunk.Init((RootCubeGrid) this, new Vector3Int(cellCoord.x * cellSize, cellCoord.y * num1, cellCoord.z * num2), new Vector3Int((cellCoord.x + 1) * cellSize, (cellCoord.y + 1) * num1, (cellCoord.z + 1) * num2) - Vector3Int.One);
        this.CellGrid.Add(cellCoord, pooledChunk);
      }
      return (RootCell) this.CellGrid[cellCoord];
    }

    public Vector3Int GetCellCoord(Vector3Int localCoordinate)
    {
      int cellSize = SingletonMonoBehaviour<ChunkSettings>.Instance.CellSize;
      int num1 = cellSize;
      int num2 = cellSize;
      Vector3Int cellCoord = new Vector3Int(localCoordinate.x / cellSize, localCoordinate.y / num1, localCoordinate.z / num2);
      if (localCoordinate.x < 0 && localCoordinate.x % cellSize != 0)
        --cellCoord.x;
      if (localCoordinate.y < 0 && localCoordinate.y % num1 != 0)
        --cellCoord.y;
      if (localCoordinate.z < 0 && localCoordinate.z % num2 != 0)
        --cellCoord.z;
      return cellCoord;
    }

    public ChunkCell GetPooledChunk() => (ChunkCell) null;

    public void ReturnPooledCell(ChunkCell cell) => throw new NotImplementedException();
  }
}
