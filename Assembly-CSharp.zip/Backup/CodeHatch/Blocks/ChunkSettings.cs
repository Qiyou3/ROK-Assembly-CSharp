﻿// Decompiled with JetBrains decompiler
// Type: CodeHatch.Blocks.ChunkSettings
// Assembly: Assembly-CSharp, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 7AE521BE-DDCA-4BB1-9869-8132CF2A08FD
// Assembly location: C:\Users\85206\Desktop\Oxide.ReignOfKings-develop\src\Dependencies\windows\ROK_Data\Managed\Assembly-CSharp.dll

using UnityEngine;

#nullable disable
namespace CodeHatch.Blocks
{
  public class ChunkSettings : SingletonMonoBehaviour<ChunkSettings>
  {
    [SerializeField]
    private int _CellSize = 16;
    [SerializeField]
    private float _LODTimestep = 1f;

    public int CellSize => this._CellSize;

    public float LODTimestep => this._LODTimestep;
  }
}
