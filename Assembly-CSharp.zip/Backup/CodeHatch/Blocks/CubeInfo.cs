﻿// Decompiled with JetBrains decompiler
// Type: CodeHatch.Blocks.CubeInfo
// Assembly: Assembly-CSharp, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 7AE521BE-DDCA-4BB1-9869-8132CF2A08FD
// Assembly location: C:\Users\85206\Desktop\Oxide.ReignOfKings-develop\src\Dependencies\windows\ROK_Data\Managed\Assembly-CSharp.dll

using CodeHatch.Blocks.Geometry;
using CodeHatch.Common;
using CodeHatch.Engine.Networking;
using CodeHatch.Engine.Serialization;
using CodeHatch.Engine.Structures;
using System.Collections.Generic;
using UnityEngine;

#nullable disable
namespace CodeHatch.Blocks
{
  public struct CubeInfo
  {
    public const byte NormalBlockID = 0;
    public const int EST_MEM_SIZE = 23;
    public const byte MultiBlockID = 255;
    public const byte AirID = 0;
    public const byte ErrorID = 255;
    public const string IDENTIFIER = "CubeInfo";
    public static readonly Quaternion[] PossibleRotations = new Quaternion[24]
    {
      Quaternion.Euler(0.0f, 0.0f, 0.0f),
      Quaternion.Euler(0.0f, 90f, 0.0f),
      Quaternion.Euler(0.0f, 180f, 0.0f),
      Quaternion.Euler(0.0f, 270f, 0.0f),
      Quaternion.Euler(180f, 0.0f, 0.0f),
      Quaternion.Euler(180f, 90f, 0.0f),
      Quaternion.Euler(180f, 180f, 0.0f),
      Quaternion.Euler(180f, 270f, 0.0f),
      Quaternion.Euler(0.0f, 90f, 90f),
      Quaternion.Euler(90f, 90f, 90f),
      Quaternion.Euler(180f, 90f, 90f),
      Quaternion.Euler(270f, 90f, 90f),
      Quaternion.Euler(0.0f, -90f, 90f),
      Quaternion.Euler(-90f, -90f, 90f),
      Quaternion.Euler(0.0f, 90f, -90f),
      Quaternion.Euler(90f, 180f, 0.0f),
      Quaternion.Euler(0.0f, 180f, 90f),
      Quaternion.Euler(-90f, 270f, 0.0f),
      Quaternion.Euler(0.0f, 0.0f, -90f),
      Quaternion.Euler(90f, 0.0f, -90f),
      Quaternion.Euler(0.0f, 0.0f, 90f),
      Quaternion.Euler(-90f, 0.0f, 90f),
      Quaternion.Euler(0.0f, 180f, -90f),
      Quaternion.Euler(90f, 180f, -90f)
    };
    private TilesetColliderCube _CentralPrefab;
    private byte _RotationIndex;
    public List<OctAtom> CornerRefs;

    public static bool IsAirBlock(byte materialId) => materialId == (byte) 0;

    public static bool IsMultiBlock(byte materialId, byte prefabId)
    {
      return !CubeInfo.IsAirBlock(materialId) && !CubeInfo.IsErrorBlock(materialId, prefabId) && prefabId == byte.MaxValue;
    }

    public static bool IsOctPrefab(byte material, byte prefab)
    {
      return prefab != (byte) 0 && material != (byte) 0 && !CubeInfo.IsErrorBlock(material, prefab);
    }

    public static bool IsNormalBlock(byte material, byte prefab)
    {
      return prefab == (byte) 0 && material != (byte) 0 && !CubeInfo.IsErrorBlock(material, prefab);
    }

    public static bool IsErrorBlock(byte material, byte prefab)
    {
      return material == byte.MaxValue && prefab == byte.MaxValue;
    }

    public static bool IsPrefabTypeDoor(byte prefabID)
    {
      return CubeInfo.IsPrefabTypeDoor((CubeInfo.PrefabType) prefabID);
    }

    public static bool IsPrefabTypeDoor(CubeInfo.PrefabType prefabType)
    {
      switch (prefabType)
      {
        case CubeInfo.PrefabType.Door:
        case CubeInfo.PrefabType.GarageDoor:
        case CubeInfo.PrefabType.Window:
        case CubeInfo.PrefabType.DoorVar1:
        case CubeInfo.PrefabType.DoorVar2:
          return true;
        default:
          return false;
      }
    }

    public static bool IsPrefabTypeSingleBlock(byte prefabID)
    {
      return CubeInfo.IsPrefabTypeSingleBlock((CubeInfo.PrefabType) prefabID);
    }

    private static bool IsPrefabTypeSingleBlock(CubeInfo.PrefabType prefabType)
    {
      switch (prefabType)
      {
        case CubeInfo.PrefabType.Block:
        case CubeInfo.PrefabType.Stair:
        case CubeInfo.PrefabType.Ramp:
        case CubeInfo.PrefabType.RampVar1:
        case CubeInfo.PrefabType.RampVar2:
        case CubeInfo.PrefabType.RampVar3:
        case CubeInfo.PrefabType.RampVar4:
        case CubeInfo.PrefabType.RampVar5:
        case CubeInfo.PrefabType.RampVar6:
        case CubeInfo.PrefabType.Peak:
        case CubeInfo.PrefabType.ThinWall:
          return true;
        case CubeInfo.PrefabType.Door:
        case CubeInfo.PrefabType.GarageDoor:
        case CubeInfo.PrefabType.Window:
        case CubeInfo.PrefabType.DoorVar1:
        case CubeInfo.PrefabType.DoorVar2:
        case CubeInfo.PrefabType.MultiBlock:
          return false;
        default:
          return false;
      }
    }

    public static CubeInfo Air => new CubeInfo();

    public static CubeInfo Error
    {
      get
      {
        return new CubeInfo()
        {
          MaterialID = byte.MaxValue,
          PrefabID = byte.MaxValue
        };
      }
    }

    public byte MaterialID { get; set; }

    public byte PrefabID { get; set; }

    public CubeInfo.PrefabType Prefab
    {
      get => (CubeInfo.PrefabType) this.PrefabID;
      set => this.PrefabID = (byte) value;
    }

    public Color32 CubeColor { get; set; }

    public Quaternion Rotation
    {
      get => CubeInfo.PossibleRotations[(int) this._RotationIndex];
      set => this._RotationIndex = CubeInfo.GetIndexOfRotation(value);
    }

    public TilesetColliderCube CentralPrefab
    {
      get
      {
        if ((Object) this._CentralPrefab == (Object) null && (int) this.MaterialID != (int) CubeInfo.Air.MaterialID && this.PrefabID != byte.MaxValue)
        {
          this._CentralPrefab = this.PrefabID != (byte) 0 ? Object.Instantiate<GameObject>(TilesetLibrary.GetTilesetWithID(this.MaterialID).GetPrefabWithID((int) this.PrefabID).gameObject).GetComponent<TilesetColliderCube>() : Object.Instantiate<GameObject>(TilesetLibrary.GetCubePrefab(this.MaterialID)).GetComponent<TilesetColliderCube>();
          OctPrefab prefabInfo = this._CentralPrefab.PrefabInfo;
          if ((Object) prefabInfo != (Object) null)
            prefabInfo.SetColor((Color) this.CubeColor);
        }
        return this._CentralPrefab;
      }
      set => this._CentralPrefab = value;
    }

    public RLECollider ContainingArea { get; set; }

    public RLERenderer BoxRenderer { get; set; }

    public bool RenderersExist() => this.CornerRefs != null && this.CornerRefs.Count > 0;

    public bool CentralPrefabExists() => (Object) this._CentralPrefab != (Object) null;

    public bool UpdateMaterial(byte materialID)
    {
      return this.UpdateMaterial(materialID, (byte) 0, Quaternion.identity);
    }

    public bool UpdateMaterial(byte materialID, byte prefabID, Quaternion rotation)
    {
      if ((double) rotation.x == 0.0 && (double) rotation.y == 0.0 && (double) rotation.z == 0.0 && (double) rotation.w == 0.0)
        rotation = Quaternion.identity;
      bool flag = false;
      if ((int) this.MaterialID != (int) materialID || (int) this.PrefabID != (int) prefabID || this.Rotation != rotation)
      {
        flag = true;
        if (prefabID != byte.MaxValue)
          this.ClearPrefabs();
      }
      this.MaterialID = materialID;
      this.PrefabID = prefabID;
      this.Rotation = rotation;
      if (flag && (int) materialID != (int) CubeInfo.Air.MaterialID)
      {
        OctTileset tilesetWithId = TilesetLibrary.GetTilesetWithID(this.MaterialID);
        if ((Object) tilesetWithId != (Object) null)
          this.CubeColor = (Color32) tilesetWithId.DefaultColor;
      }
      return flag;
    }

    public bool SetColor(Color32 newColor, int corner)
    {
      if (corner == 0)
      {
        if ((int) newColor.r == (int) this.CubeColor.r && (int) newColor.g == (int) this.CubeColor.g && (int) newColor.b == (int) this.CubeColor.b && (int) newColor.a == (int) this.CubeColor.a)
          return true;
        this.CubeColor = newColor;
        if (this.PrefabID != byte.MaxValue && this.CentralPrefabExists())
        {
          OctPrefab prefabInfo = this.CentralPrefab.PrefabInfo;
          if ((Object) prefabInfo != (Object) null)
            prefabInfo.SetColor((Color) newColor);
        }
      }
      if (this.CornerRefs != null)
      {
        for (int index = this.CornerRefs.Count - 1; index >= 0; --index)
        {
          OctAtom cornerRef = this.CornerRefs[index];
          if ((Object) cornerRef != (Object) null)
            cornerRef.SetColor(corner, (Color) newColor);
          else
            this.CornerRefs.RemoveAt(index);
        }
      }
      return false;
    }

    public bool HasLod(int lod)
    {
      if (this.CornerRefs != null)
      {
        for (int index = this.CornerRefs.Count - 1; index >= 0; --index)
        {
          OctAtom cornerRef = this.CornerRefs[index];
          if ((Object) cornerRef != (Object) null)
          {
            if (cornerRef.LODHandler.HasLOD(lod))
              return true;
          }
          else
            this.CornerRefs.RemoveAt(index);
        }
      }
      return (Object) this._CentralPrefab != (Object) null && (Object) this._CentralPrefab.LODInfo != (Object) null && this._CentralPrefab.LODInfo.HasLOD(lod);
    }

    public void SetLod(int lod)
    {
      if (this.CornerRefs != null)
      {
        for (int index = this.CornerRefs.Count - 1; index >= 0; --index)
        {
          OctAtom cornerRef = this.CornerRefs[index];
          if ((Object) cornerRef != (Object) null)
            cornerRef.LODHandler.SetLOD(lod);
          else
            this.CornerRefs.RemoveAt(index);
        }
      }
      if (!((Object) this._CentralPrefab != (Object) null) || !((Object) this._CentralPrefab.LODInfo != (Object) null))
        return;
      this._CentralPrefab.LODInfo.SetLOD(lod);
    }

    public void ClearPrefabs()
    {
      if (this.PrefabID == byte.MaxValue)
        return;
      this.ClearRenderers();
      if (!((Object) this._CentralPrefab != (Object) null))
        return;
      this.DestroyPrefab();
    }

    public void TryCollapsePrefab()
    {
      if (!((Object) this._CentralPrefab != (Object) null) || !this._CentralPrefab.CanCollapse())
        return;
      this.DestroyPrefab();
    }

    internal void DestroyPrefab()
    {
      if (this.PrefabID == byte.MaxValue)
        return;
      Object.Destroy((Object) this._CentralPrefab.gameObject);
      this._CentralPrefab = (TilesetColliderCube) null;
    }

    public void ClearRenderers()
    {
      if (this.CornerRefs == null)
        return;
      for (int index = this.CornerRefs.Count - 1; index >= 0; --index)
      {
        OctAtom cornerRef = this.CornerRefs[index];
        if ((Object) cornerRef != (Object) null)
          OctTileset.ReturnPooledAtom(cornerRef);
      }
      this.CornerRefs.Clear();
    }

    public void InitRenderers(List<OctAtom> cornerRefs)
    {
      if (this.CornerRefs != null)
        this.ClearRenderers();
      this.CornerRefs = cornerRefs;
    }

    public void Reset()
    {
      this.ClearPrefabs();
      this.MaterialID = (byte) 0;
      this.PrefabID = (byte) 0;
      this.Rotation = Quaternion.identity;
      this.CubeColor = (Color32) Color.white;
      this.ContainingArea = (RLECollider) null;
      this.BoxRenderer = (RLERenderer) null;
    }

    public static bool IsError(CubeInfo info)
    {
      return info.MaterialID == byte.MaxValue && info.PrefabID == byte.MaxValue;
    }

    public static byte GetIndexOfRotation(Quaternion rotation)
    {
      for (int indexOfRotation = 0; indexOfRotation < CubeInfo.PossibleRotations.Length; ++indexOfRotation)
      {
        if ((double) Quaternion.Angle(CubeInfo.PossibleRotations[indexOfRotation], rotation) < 10.0)
          return (byte) indexOfRotation;
      }
      Logger.ErrorFormat("Unable to find rotation index matching rotation: {0}", (object) rotation.eulerAngles.ToString());
      return 0;
    }

    public override string ToString()
    {
      return "Cube MaterialId" + (object) this.MaterialID + " PrefabId " + (object) this.PrefabID + " Color " + (object) this.CubeColor;
    }

    public string Identifier => nameof (CubeInfo);

    public void Serialize(IStream stream)
    {
      byte num = 0;
      if (this.PrefabID == byte.MaxValue)
      {
        stream.WriteByte(num);
      }
      else
      {
        if (this.CentralPrefabExists())
        {
          if (this.CentralPrefab.Health is ISerializable)
            num |= (byte) 1;
          if (this.CentralPrefab.ObjectSecurity is ISerializable)
            num |= (byte) 2;
          if ((Object) this.CentralPrefab.GetComponent<Door>() != (Object) null)
            num |= (byte) 4;
        }
        stream.WriteByte(num);
        if (!this.CentralPrefabExists())
          return;
        if (this.CentralPrefab.Health is ISerializable)
          this.CentralPrefab.Health.Serialize(stream);
        if (this.CentralPrefab.ObjectSecurity is ISerializable)
          ((ISerializable) this.CentralPrefab.ObjectSecurity).Serialize(stream);
        Door component = this.CentralPrefab.GetComponent<Door>();
        if (!((Object) component != (Object) null))
          return;
        component.Serialize(stream);
      }
    }

    public void Deserialize(IStream stream, RootCubeGrid parentGrid, Vector3Int position)
    {
      byte num = stream.ReadByte();
      if (((int) num & 1) != 0)
      {
        TilesetColliderCube centralPrefabAtLocal = parentGrid.GetCentralPrefabAtLocal(position);
        if ((Object) centralPrefabAtLocal != (Object) null)
          centralPrefabAtLocal.Health.Deserialize(stream);
      }
      if (((int) num & 2) != 0)
      {
        TilesetColliderCube centralPrefabAtLocal = parentGrid.GetCentralPrefabAtLocal(position);
        if ((Object) centralPrefabAtLocal != (Object) null)
          ((ISerializable) centralPrefabAtLocal.ObjectSecurity).Deserialize(stream);
      }
      if (((int) num & 4) == 0)
        return;
      TilesetColliderCube centralPrefabAtLocal1 = parentGrid.GetCentralPrefabAtLocal(position);
      if (!((Object) centralPrefabAtLocal1 != (Object) null))
        return;
      centralPrefabAtLocal1.GetComponent<Door>().Deserialize(stream);
    }

    public enum PrefabType : byte
    {
      Block = 0,
      Stair = 1,
      Ramp = 2,
      RampVar1 = 3,
      RampVar2 = 4,
      RampVar3 = 5,
      RampVar4 = 6,
      RampVar5 = 7,
      RampVar6 = 8,
      Peak = 9,
      Door = 10, // 0x0A
      GarageDoor = 11, // 0x0B
      Window = 12, // 0x0C
      DoorVar1 = 13, // 0x0D
      DoorVar2 = 14, // 0x0E
      ThinWall = 15, // 0x0F
      DoorVertical = 16, // 0x10
      MultiBlock = 255, // 0xFF
    }
  }
}
