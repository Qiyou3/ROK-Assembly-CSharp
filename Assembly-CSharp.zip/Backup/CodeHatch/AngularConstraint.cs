﻿// Decompiled with JetBrains decompiler
// Type: CodeHatch.AngularConstraint
// Assembly: Assembly-CSharp, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 7AE521BE-DDCA-4BB1-9869-8132CF2A08FD
// Assembly location: C:\Users\85206\Desktop\Oxide.ReignOfKings-develop\src\Dependencies\windows\ROK_Data\Managed\Assembly-CSharp.dll

using CodeHatch.Common;
using System;
using UnityEngine;

#nullable disable
namespace CodeHatch
{
  [Serializable]
  public class AngularConstraint
  {
    public bool Enabled = true;
    public float RotationSpring;
    public float VelocitySpring;
    public float Damper;

    public Vector3 GetTorque(
      Quaternion currentRotation,
      Vector3 currentVelocity,
      Quaternion targetRotation,
      Vector3 targetVelocity)
    {
      return !this.Enabled ? Vector3.zero : (targetRotation * Quaternion.Inverse(currentRotation)).ToAngleAxis() * this.RotationSpring + targetVelocity * this.VelocitySpring + currentVelocity * -this.Damper;
    }

    public Vector3 GetTorque(
      Vector3 curretDirection,
      Vector3 currentVelocity,
      Vector3 targetDirection,
      Vector3 targetVelocity)
    {
      return !this.Enabled ? Vector3.zero : Quaternion.FromToRotation(curretDirection, targetDirection).ToAngleAxis() * this.RotationSpring + targetVelocity * this.VelocitySpring + currentVelocity * -this.Damper;
    }
  }
}
