﻿// Decompiled with JetBrains decompiler
// Type: CodeHatch.AIValueBundle
// Assembly: Assembly-CSharp, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 7AE521BE-DDCA-4BB1-9869-8132CF2A08FD
// Assembly location: C:\Users\85206\Desktop\Oxide.ReignOfKings-develop\src\Dependencies\windows\ROK_Data\Managed\Assembly-CSharp.dll

using CodeHatch.Damaging;
using UnityEngine;

#nullable disable
namespace CodeHatch
{
  public class AIValueBundle : ScriptableObject
  {
    [Tooltip("The creatures max Health value")]
    public float Health;
    [Tooltip("Should the creature start walking slower when at a specified health percentage")]
    public bool walkOnLowHealth;
    [Tooltip("The percentage of health at which the creature should start walking slower")]
    [Range(0.0f, 1f)]
    public float lowHealthPercentage;
    public float speedDecreaseMultiplier;
    public float AttackDamage;
    public float AttackForce;
    public DamageType damageType;
    public float noticePlayerDistance;
    public float forgetAboutPlayerDistance;
    public float distanceToRunAwayFromPlayer;
    public AnimationCurve velocityToRunFromPlayer;
  }
}
