﻿// Decompiled with JetBrains decompiler
// Type: CodeHatch.AI.TargetFilterCombine
// Assembly: Assembly-CSharp, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 7AE521BE-DDCA-4BB1-9869-8132CF2A08FD
// Assembly location: C:\Users\85206\Desktop\Oxide.ReignOfKings-develop\src\Dependencies\windows\ROK_Data\Managed\Assembly-CSharp.dll

using UnityEngine;

#nullable disable
namespace CodeHatch.AI
{
  public class TargetFilterCombine : TargetFilterBase
  {
    public TargetFilterCombineMode combine;
    public TargetFilterBase[] filters;

    protected override bool TestInternal(Targetable target)
    {
      switch (this.combine)
      {
        case TargetFilterCombineMode.And:
          for (int index = 0; index < this.filters.Length; ++index)
          {
            if (!((Object) this.filters[index] == (Object) null) && !this.filters[index].Test(target))
              return false;
          }
          return true;
        case TargetFilterCombineMode.Or:
          for (int index = 0; index < this.filters.Length; ++index)
          {
            if (this.filters[index].Test(target))
              return true;
          }
          return false;
        default:
          this.LogError<TargetFilterCombine>("Invalid combine mode: {0}", (object) this.combine);
          return false;
      }
    }
  }
}
