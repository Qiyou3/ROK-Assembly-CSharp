﻿// Decompiled with JetBrains decompiler
// Type: CodeHatch.AI.WaypointResponder
// Assembly: Assembly-CSharp, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 7AE521BE-DDCA-4BB1-9869-8132CF2A08FD
// Assembly location: C:\Users\85206\Desktop\Oxide.ReignOfKings-develop\src\Dependencies\windows\ROK_Data\Managed\Assembly-CSharp.dll

using CodeHatch.Common;
using CodeHatch.Networking.Events;
using UnityEngine;

#nullable disable
namespace CodeHatch.AI
{
  public class WaypointResponder : AIBehaviour
  {
    public float UpdateIntervalMin = 0.75f;
    public float UpdateIntervalMax = 1.25f;
    private bool _hasWaypoint;
    private Vector3 _waypoint;
    private float _nextUpdateTime;

    public void Awake()
    {
      EventManager.Subscribe<WaypointEvent>(new EventSubscriber<WaypointEvent>(this.NewWaypoint));
    }

    public void OnDestroy()
    {
      EventManager.Unsubscribe<WaypointEvent>(new EventSubscriber<WaypointEvent>(this.NewWaypoint));
    }

    private void NewWaypoint(WaypointEvent e)
    {
      if ((Object) e.Entity != (Object) this.Entity)
        return;
      this._hasWaypoint = true;
      this._waypoint = e.waypoint;
      this.SetCurrentLocation(this._waypoint);
    }

    public void OnDisable() => this._hasWaypoint = false;

    public void Update()
    {
      if (!this._hasWaypoint || !TimeUtil.ExceededTime(this._nextUpdateTime))
        return;
      this.SetCurrentLocation(this._waypoint);
      this._nextUpdateTime = TimeUtil.ResetTimer(Random.Range(this.UpdateIntervalMin, this.UpdateIntervalMax));
    }
  }
}
