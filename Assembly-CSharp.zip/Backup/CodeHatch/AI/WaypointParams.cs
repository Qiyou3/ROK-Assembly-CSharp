﻿// Decompiled with JetBrains decompiler
// Type: CodeHatch.AI.WaypointParams
// Assembly: Assembly-CSharp, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 7AE521BE-DDCA-4BB1-9869-8132CF2A08FD
// Assembly location: C:\Users\85206\Desktop\Oxide.ReignOfKings-develop\src\Dependencies\windows\ROK_Data\Managed\Assembly-CSharp.dll

using System;
using UnityEngine;

#nullable disable
namespace CodeHatch.AI
{
  [Serializable]
  public class WaypointParams
  {
    [Designer]
    [Tooltip("The velocity the creature will try to reach while approaching it's waypoint")]
    public AnimationCurve ApproachVelocity;
    public float approachSlowdownDistance;
    public float approachStopDistance;
    [Tooltip("The velocity the creature will try to reach while avoiding it's waypoint")]
    [Designer]
    public AnimationCurve AvoidVelocity;
    public float avoidSlowdownDistance;
    public float avoidStopDistance;
    public Vector3 offset;

    public void OnValidate()
    {
      if ((double) this.avoidStopDistance > (double) this.approachStopDistance)
        this.avoidStopDistance = this.approachStopDistance;
      if ((double) this.approachSlowdownDistance < (double) this.approachStopDistance)
        this.approachSlowdownDistance = this.approachStopDistance;
      if ((double) this.avoidSlowdownDistance <= (double) this.avoidStopDistance)
        return;
      this.avoidSlowdownDistance = this.avoidStopDistance;
    }

    public float GetDesiredVelocity(float distance)
    {
      if ((double) distance > (double) this.approachSlowdownDistance)
        return this.ApproachVelocity.Evaluate(distance);
      if ((double) distance > (double) this.approachStopDistance)
        return this.ApproachVelocity.Evaluate(distance) * Mathf.InverseLerp(this.approachStopDistance, this.approachSlowdownDistance, distance);
      if ((double) distance < (double) this.avoidSlowdownDistance)
        return this.AvoidVelocity.Evaluate(distance);
      return (double) distance < (double) this.avoidStopDistance ? this.AvoidVelocity.Evaluate(distance) * Mathf.InverseLerp(this.avoidStopDistance, this.avoidSlowdownDistance, distance) : 0.0f;
    }
  }
}
