﻿// Decompiled with JetBrains decompiler
// Type: CodeHatch.AI.TargetChangedEvent
// Assembly: Assembly-CSharp, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 7AE521BE-DDCA-4BB1-9869-8132CF2A08FD
// Assembly location: C:\Users\85206\Desktop\Oxide.ReignOfKings-develop\src\Dependencies\windows\ROK_Data\Managed\Assembly-CSharp.dll

using CodeHatch.Engine.Core.Cache;
using CodeHatch.Engine.Networking;
using CodeHatch.Networking.Events;
using CodeHatch.Networking.Events.Entities;
using System;

#nullable disable
namespace CodeHatch.AI
{
  public class TargetChangedEvent : EntityEvent
  {
    public Targetable Targetable;

    public TargetChangedEvent()
      : this((Entity) null, (Targetable) null)
    {
    }

    public TargetChangedEvent(
      Entity entity,
      Targetable targetable,
      Action<BaseEvent> cancelCallback = null)
      : base(entity, cancelCallback)
    {
      this.Targetable = targetable;
    }

    public override void Write(IStream stream)
    {
      base.Write(stream);
      stream.Write<Entity>(!((UnityEngine.Object) this.Targetable != (UnityEngine.Object) null) ? (Entity) null : this.Targetable.Entity);
    }

    public override void Read(IStream stream)
    {
      base.Read(stream);
      Entity entity = stream.Read<Entity>();
      this.Targetable = !((UnityEngine.Object) entity != (UnityEngine.Object) null) ? (Targetable) null : entity.Get<Targetable>();
    }
  }
}
