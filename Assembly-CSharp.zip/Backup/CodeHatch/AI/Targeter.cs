﻿// Decompiled with JetBrains decompiler
// Type: CodeHatch.AI.Targeter
// Assembly: Assembly-CSharp, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 7AE521BE-DDCA-4BB1-9869-8132CF2A08FD
// Assembly location: C:\Users\85206\Desktop\Oxide.ReignOfKings-develop\src\Dependencies\windows\ROK_Data\Managed\Assembly-CSharp.dll

using CodeHatch.Common;
using CodeHatch.Networking.Events;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using UnityEngine;

#nullable disable
namespace CodeHatch.AI
{
  public class Targeter : AIBehaviour
  {
    public TargetFilterBase filter;
    public TargetPrioritizerBase prioritizer;
    public TargetFilterBase detargetFilter;
    private Team _team;
    [SerializeField]
    private Targeter.TargetMode _CurrentTargetMode;
    protected List<int> _shuffleIndices = new List<int>();
    protected bool _started;
    private Targetable _previousTarget;

    private TargetFilterBase Filter
    {
      get
      {
        if ((Object) this.filter == (Object) null)
          this.filter = this.Entity.Get<TargetFilterBase>();
        return this.filter;
      }
    }

    private TargetPrioritizerBase Prioritizer
    {
      get
      {
        if ((Object) this.prioritizer == (Object) null)
          this.prioritizer = this.Entity.Get<TargetPrioritizerBase>();
        return this.prioritizer;
      }
    }

    private TargetFilterBase DetargetFilter
    {
      get
      {
        if ((Object) this.detargetFilter == (Object) null)
          this.detargetFilter = this.Entity.TryGet<TargetFilterBase>();
        return this.detargetFilter;
      }
    }

    private Team MyTeam
    {
      get
      {
        if ((Object) this._team == (Object) null)
          this._team = this.Entity.Get<Team>();
        return this._team;
      }
    }

    protected virtual List<Targetable> Targets => Targetable.GetEnemies(this.MyTeam.TeamColor);

    protected void UpdateShuffleList()
    {
      int count = this.Targets.Count;
      if (this._shuffleIndices.Count == count)
        return;
      this.OnNumTargetsChanged(count);
    }

    private void OnNumTargetsChanged(int newTargetCount)
    {
      if (this._shuffleIndices.Count < newTargetCount)
        this.OnNumTargetsIncreased(newTargetCount);
      else if (this._shuffleIndices.Count > newTargetCount)
        this.OnNumTargetsDecreased(newTargetCount);
      if (this._shuffleIndices.Count > newTargetCount)
        this.LogError<Targeter>("Failed");
      for (int index = 0; index < newTargetCount; ++index)
      {
        if (!this._shuffleIndices.Contains(index))
          this.LogError<Targeter>("Failed");
      }
    }

    private void OnNumTargetsIncreased(int newTargetCount)
    {
      for (int count = this._shuffleIndices.Count; count < newTargetCount; ++count)
        this._shuffleIndices.Add(count);
    }

    private void OnNumTargetsDecreased(int newTargetCount)
    {
      for (int index1 = this._shuffleIndices.Count - 1; index1 >= 0; --index1)
      {
        if (this._shuffleIndices[index1] >= newTargetCount)
        {
          int index2 = this._shuffleIndices.Count - 1;
          if (index1 < index2)
            this._shuffleIndices[index1] = this._shuffleIndices[index2];
          this._shuffleIndices.RemoveAt(index2);
        }
      }
    }

    public virtual void Start()
    {
      this._started = true;
      this.StartCoroutineWithExceptionHandling(new CoroutineUtil.CoroutineDelegate(this.TargetingRoutine));
    }

    public virtual void OnEnable()
    {
      if (!this._started)
        return;
      this.Start();
    }

    public virtual void OnDisable()
    {
      if (!this._started)
        return;
      this.SendEventIfTargetChanged();
    }

    [DebuggerHidden]
    public virtual IEnumerator TargetingRoutine()
    {
      // ISSUE: object of a compiler-generated type is created
      return (IEnumerator) new Targeter.\u003CTargetingRoutine\u003Ec__IteratorD2()
      {
        \u003C\u003Ef__this = this
      };
    }

    [DebuggerHidden]
    private IEnumerator GetHighestPriorityValidTarget()
    {
      // ISSUE: object of a compiler-generated type is created
      return (IEnumerator) new Targeter.\u003CGetHighestPriorityValidTarget\u003Ec__IteratorD3()
      {
        \u003C\u003Ef__this = this
      };
    }

    protected virtual void OnTargetSwapped()
    {
    }

    private void SendEventIfTargetChanged()
    {
      if ((Object) this._previousTarget == (Object) this.CurrentTarget)
        return;
      this.OnTargetSwapped();
      this._previousTarget = this.CurrentTarget;
      if ((Object) this.CurrentTarget != (Object) null)
        EventManager.CallEvent((BaseEvent) new TargetChangedEvent(this.Entity, this.CurrentTarget));
      else
        EventManager.CallEvent((BaseEvent) new TargetLostEvent(this.Entity));
    }

    protected enum TargetMode
    {
      Standard,
      Lock,
    }
  }
}
