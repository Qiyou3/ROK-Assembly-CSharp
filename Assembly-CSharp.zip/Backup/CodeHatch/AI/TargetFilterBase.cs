﻿// Decompiled with JetBrains decompiler
// Type: CodeHatch.AI.TargetFilterBase
// Assembly: Assembly-CSharp, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 7AE521BE-DDCA-4BB1-9869-8132CF2A08FD
// Assembly location: C:\Users\85206\Desktop\Oxide.ReignOfKings-develop\src\Dependencies\windows\ROK_Data\Managed\Assembly-CSharp.dll

using CodeHatch.Engine.Core.Cache;
using System.Diagnostics;
using UnityEngine;

#nullable disable
namespace CodeHatch.AI
{
  public abstract class TargetFilterBase : EntityBehaviour
  {
    public bool Test(Targetable target)
    {
      if ((Object) target == (Object) null)
      {
        this.LogWarning<TargetFilterBase>("Target provided is null.");
        return false;
      }
      if (!((Object) target.Entity == (Object) null))
        return this.TestInternal(target);
      this.LogError<TargetFilterBase>("Target provided is not an entity. This is required.");
      return false;
    }

    protected abstract bool TestInternal(Targetable target);

    [Conditional("UNITY_EDITOR")]
    protected void SetTestFailrureReason(TargetFilterBase reason)
    {
    }

    [Conditional("UNITY_EDITOR")]
    protected void SetTestFailrureReason(string reason)
    {
    }

    [Conditional("UNITY_EDITOR")]
    private void AddResultToDictionary(Targetable target, bool result)
    {
    }
  }
}
