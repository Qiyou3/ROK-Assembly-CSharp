﻿// Decompiled with JetBrains decompiler
// Type: CodeHatch.AI.StateTogglerBase`1
// Assembly: Assembly-CSharp, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 7AE521BE-DDCA-4BB1-9869-8132CF2A08FD
// Assembly location: C:\Users\85206\Desktop\Oxide.ReignOfKings-develop\src\Dependencies\windows\ROK_Data\Managed\Assembly-CSharp.dll

using CodeHatch.Common;
using System;
using System.Collections.Generic;

#nullable disable
namespace CodeHatch.AI
{
  public abstract class StateTogglerBase<T> : StateListener<T> where T : struct, IConvertible
  {
    private readonly List<UnityEngine.Object> _allObjects = new List<UnityEngine.Object>();

    protected abstract int ToggleGroupCount { get; }

    protected abstract StateToggleGroup<T> GetToggleGroup(int index);

    public new void Awake()
    {
      base.Awake();
      this.PopulateAllObjectList();
      this.PopulateToggleOffLists();
    }

    private void PopulateAllObjectList()
    {
      for (int index1 = 0; index1 < this.ToggleGroupCount; ++index1)
      {
        StateToggleGroup<T> toggleGroup = this.GetToggleGroup(index1);
        for (int index2 = 0; index2 < toggleGroup.objects.Length; ++index2)
          this._allObjects.AddDistinct<UnityEngine.Object>(toggleGroup.objects[index2]);
      }
    }

    private void PopulateToggleOffLists()
    {
      for (int index1 = 0; index1 < this.ToggleGroupCount; ++index1)
      {
        StateToggleGroup<T> toggleGroup = this.GetToggleGroup(index1);
        toggleGroup.objectsToDisable = new List<UnityEngine.Object>();
        for (int index2 = 0; index2 < this._allObjects.Count; ++index2)
        {
          UnityEngine.Object allObject = this._allObjects[index2];
          if (!toggleGroup.objects.Contains<UnityEngine.Object>(allObject))
            toggleGroup.objectsToDisable.Add(allObject);
        }
      }
    }

    protected override void OnStateChanged(T newState)
    {
      for (int index = 0; index < this.ToggleGroupCount; ++index)
      {
        StateToggleGroup<T> toggleGroup = this.GetToggleGroup(index);
        if (toggleGroup.state.Equals((object) newState))
        {
          toggleGroup.ToggleOn();
          return;
        }
      }
      this.ToggleAllOff();
    }

    private void ToggleAllOff()
    {
      for (int index = 0; index < this._allObjects.Count; ++index)
        this._allObjects[index].SetEnable(false);
    }
  }
}
