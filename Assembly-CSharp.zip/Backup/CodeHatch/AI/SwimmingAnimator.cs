﻿// Decompiled with JetBrains decompiler
// Type: CodeHatch.AI.SwimmingAnimator
// Assembly: Assembly-CSharp, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 7AE521BE-DDCA-4BB1-9869-8132CF2A08FD
// Assembly location: C:\Users\85206\Desktop\Oxide.ReignOfKings-develop\src\Dependencies\windows\ROK_Data\Managed\Assembly-CSharp.dll

using CodeHatch.Common;
using CodeHatch.Engine.Core.Cache;
using System;
using UnityEngine;

#nullable disable
namespace CodeHatch.AI
{
  public class SwimmingAnimator : AnimatorBehaviour
  {
    public SwimmingAnimator.SwimLayerWeightsLocomotion[] LocomotionSwimWeights;
    public SwimmingAnimator.SwimLayerWeights DefaultSwimWeights = new SwimmingAnimator.SwimLayerWeights();
    private PlanarBuoyancy[] _buoyancyComponents;
    private MotorBridge _motorBridge;
    private BipedAnimator _bipedAnimator;
    public int LowerLayerIndex = 2;
    public int UpperLayerIndex = 3;
    public float Smoothing = 0.15f;
    private float _smoothUpperLayerWeight;
    private float _smoothLowerLayerWeight;

    public SwimmingAnimator.SwimLayerWeights SwimWeights
    {
      get
      {
        if (this.LocomotionSwimWeights == null || this.LocomotionSwimWeights.Length <= 0 || (UnityEngine.Object) this.BipedAnimator == (UnityEngine.Object) null)
          return this.DefaultSwimWeights;
        BipedLocomotionAnimation bipedLocomotionToUse = this.BipedAnimator.BipedLocomotionToUse;
        if ((UnityEngine.Object) bipedLocomotionToUse == (UnityEngine.Object) null)
          return this.DefaultSwimWeights;
        for (int index = 0; index < this.LocomotionSwimWeights.Length; ++index)
        {
          if ((UnityEngine.Object) this.LocomotionSwimWeights[index].Locomotion == (UnityEngine.Object) bipedLocomotionToUse)
            return this.LocomotionSwimWeights[index].Weights;
        }
        return this.DefaultSwimWeights;
      }
    }

    private PlanarBuoyancy[] BuoyancyComponents
    {
      get
      {
        if (this._buoyancyComponents == null)
          this._buoyancyComponents = this.Entity.TryGetArray<PlanarBuoyancy>();
        return this._buoyancyComponents;
      }
    }

    private MotorBridge MotorBridge
    {
      get
      {
        if ((UnityEngine.Object) this._motorBridge == (UnityEngine.Object) null)
        {
          Entity entity = this.NullCheck<Entity>(this.Entity, "Entity");
          if ((UnityEngine.Object) entity == (UnityEngine.Object) null)
            return (MotorBridge) null;
          this._motorBridge = entity.GetOrCreate<MotorBridge>();
        }
        return this._motorBridge;
      }
    }

    private BipedAnimator BipedAnimator
    {
      get
      {
        if ((UnityEngine.Object) this._bipedAnimator == (UnityEngine.Object) null)
        {
          Entity entity = this.NullCheck<Entity>(this.Entity, "Entity");
          if ((UnityEngine.Object) entity == (UnityEngine.Object) null)
            return (BipedAnimator) null;
          this._bipedAnimator = entity.TryGet<BipedAnimator>();
        }
        return this._bipedAnimator;
      }
    }

    private float Submersion
    {
      get
      {
        PlanarBuoyancy[] buoyancyComponents = this.BuoyancyComponents;
        float a = 0.0f;
        for (int index = 0; index < buoyancyComponents.Length; ++index)
          a = Mathf.Max(a, buoyancyComponents[0].Submersion);
        return a;
      }
    }

    public override void Start()
    {
      AnimatorBehaviourManager behaviourManager = this.NullCheck<AnimatorBehaviourManager>(this.Manager, "Manager");
      if ((UnityEngine.Object) behaviourManager == (UnityEngine.Object) null)
        return;
      behaviourManager.SetLayerWeight(this.LowerLayerIndex, 0.0f);
      behaviourManager.SetLayerWeight(this.UpperLayerIndex, 0.0f);
    }

    public void OnDisable()
    {
      AnimatorBehaviourManager behaviourManager = this.NullCheck<AnimatorBehaviourManager>(this.Manager, "Manager");
      if ((UnityEngine.Object) behaviourManager == (UnityEngine.Object) null)
        return;
      behaviourManager.SetLayerWeight(this.LowerLayerIndex, 0.0f);
      behaviourManager.SetLayerWeight(this.UpperLayerIndex, 0.0f);
    }

    public override void Initialize(AnimatorBehaviourManager manager)
    {
      manager.AddPass(new System.Action(this.OnAction), AnimatorBehaviourPass.PreAnimate, 1001);
    }

    private void OnAction()
    {
      AnimatorBehaviourManager behaviourManager = this.NullCheck<AnimatorBehaviourManager>(this.Manager, "Manager");
      if ((UnityEngine.Object) behaviourManager == (UnityEngine.Object) null)
        return;
      float num1 = this.Submersion * (1f - this.MotorBridge.Stability);
      SwimmingAnimator.SwimLayerWeights swimWeights = this.SwimWeights;
      float num2 = swimWeights.Upper * num1;
      float num3 = swimWeights.Lower * num1;
      this._smoothUpperLayerWeight += (num2 - this._smoothUpperLayerWeight) * HalfLife.GetRate(this.Smoothing);
      this._smoothLowerLayerWeight += (num3 - this._smoothLowerLayerWeight) * HalfLife.GetRate(this.Smoothing);
      behaviourManager.SetLayerWeight(this.UpperLayerIndex, this._smoothUpperLayerWeight);
      behaviourManager.SetLayerWeight(this.LowerLayerIndex, this._smoothLowerLayerWeight);
    }

    [Serializable]
    public class SwimLayerWeights
    {
      public float Upper = 1f;
      public float Lower = 1f;
    }

    [Serializable]
    public class SwimLayerWeightsLocomotion
    {
      public BipedLocomotionAnimation Locomotion;
      public SwimmingAnimator.SwimLayerWeights Weights;
    }
  }
}
