﻿// Decompiled with JetBrains decompiler
// Type: CodeHatch.AI.SwimmingGlueCode
// Assembly: Assembly-CSharp, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 7AE521BE-DDCA-4BB1-9869-8132CF2A08FD
// Assembly location: C:\Users\85206\Desktop\Oxide.ReignOfKings-develop\src\Dependencies\windows\ROK_Data\Managed\Assembly-CSharp.dll

using CodeHatch.Damaging;
using CodeHatch.Engine.Core.Cache;
using CodeHatch.Networking.Events;
using CodeHatch.Networking.Events.Entities;
using CodeHatch.TerrainAPI;
using UnityEngine;

#nullable disable
namespace CodeHatch.AI
{
  public class SwimmingGlueCode : EntityBehaviour
  {
    private PlanarBuoyancy[] _buoyancyComponents;
    private WaterLateralEffects[] _lateralEffects;
    private BipedSwimming[] _swimmingComponents;
    private float _damageTimer;
    private float _damage;

    private PlanarBuoyancy[] BuoyancyComponents
    {
      get
      {
        if (this._buoyancyComponents == null)
          this._buoyancyComponents = this.Entity.TryGetArray<PlanarBuoyancy>();
        return this._buoyancyComponents;
      }
    }

    private WaterLateralEffects[] LateralEffects
    {
      get
      {
        if (this._lateralEffects == null)
          this._lateralEffects = this.Entity.TryGetArray<WaterLateralEffects>();
        return this._lateralEffects;
      }
    }

    private BipedSwimming[] SwimmingComponents
    {
      get
      {
        if (this._swimmingComponents == null)
          this._swimmingComponents = this.Entity.TryGetArray<BipedSwimming>();
        return this._swimmingComponents;
      }
    }

    public void Start()
    {
      if ((Object) TerrainAPIBase.WaterController == (Object) null)
        return;
      foreach (Behaviour buoyancyComponent in this.BuoyancyComponents)
        buoyancyComponent.enabled = TerrainAPIBase.WaterController.Enabled;
      foreach (Behaviour swimmingComponent in this.SwimmingComponents)
        swimmingComponent.enabled = TerrainAPIBase.WaterController.Enabled;
      SwimmingAnimator swimmingAnimator = this.Entity.TryGet<SwimmingAnimator>();
      if ((Object) swimmingAnimator != (Object) null)
        swimmingAnimator.enabled = TerrainAPIBase.WaterController.Enabled;
      if (TerrainAPIBase.WaterController.Enabled)
        this.Update();
      else
        this.enabled = false;
    }

    public void Update()
    {
      if ((Object) TerrainAPIBase.WaterController == (Object) null || !TerrainAPIBase.WaterController.Enabled)
        return;
      float waterHeightAt = TerrainAPIBase.WaterController.GetWaterHeightAt(this.Entity.Position);
      for (int index = 0; index < this.BuoyancyComponents.Length; ++index)
      {
        PlanarBuoyancy buoyancyComponent = this.BuoyancyComponents[index];
        buoyancyComponent.PlaneDirection = Vector3.up;
        buoyancyComponent.PlanePosition = new Vector3()
        {
          y = waterHeightAt
        };
        if (TerrainAPIBase.WaterController.TypeOfLiquid == WaterControllerBase.LiquidType.Lava && (double) buoyancyComponent.Submersion > 0.0)
          this._damage += (float) ((double) buoyancyComponent.Submersion * (double) Time.deltaTime * 200.0);
      }
      for (int index = 0; index < this.LateralEffects.Length; ++index)
      {
        WaterLateralEffects lateralEffect = this.LateralEffects[index];
        lateralEffect.PlaneDirection = Vector3.up;
        lateralEffect.PlanePosition = new Vector3()
        {
          y = waterHeightAt
        };
      }
      if (TerrainAPIBase.WaterController.TypeOfLiquid == WaterControllerBase.LiquidType.Lava && ((double) Time.time > (double) this._damageTimer || (double) this._damage > 50.0))
      {
        EventManager.CallEvent((BaseEvent) new EntityDamageEvent(this.Entity, new Damage((Object) this.Entity.MainTransform, (Entity) null, HumanBodyBones.LeftLowerLeg)
        {
          DamageTypes = DamageType.Fire,
          Amount = this._damage,
          Damager = (Object) TerrainAPIBase.WaterController,
          point = new Vector3(this.Entity.Position.x, waterHeightAt, this.Entity.Position.z)
        }));
        this._damageTimer = Time.time + 1f;
        this._damage = 0.0f;
      }
      else
        this._damage = 0.0f;
    }
  }
}
