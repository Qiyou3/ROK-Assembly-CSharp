﻿// Decompiled with JetBrains decompiler
// Type: CodeHatch.AI.TimedDistanceTargetFilter
// Assembly: Assembly-CSharp, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 7AE521BE-DDCA-4BB1-9869-8132CF2A08FD
// Assembly location: C:\Users\85206\Desktop\Oxide.ReignOfKings-develop\src\Dependencies\windows\ROK_Data\Managed\Assembly-CSharp.dll

using UnityEngine;

#nullable disable
namespace CodeHatch.AI
{
  public class TimedDistanceTargetFilter : TargetFilterBase
  {
    public float maxDistance = 100f;
    public float timeout = 10f;
    private float _lastTimeWithinDistance;
    private Transform _eyesTransform;

    protected Transform EyesTransform
    {
      get
      {
        if ((Object) this._eyesTransform == (Object) null)
          this._eyesTransform = this.Entity.GetOrCreate<CharacterDefinition>().GetTransform(CharacterDefinition.Part.EyesCenter);
        return this._eyesTransform;
      }
    }

    protected override bool TestInternal(Targetable currentTarget)
    {
      if ((double) (currentTarget.Entity.Position - this.EyesTransform.position).magnitude <= (double) this.maxDistance)
      {
        this._lastTimeWithinDistance = Time.time;
        return true;
      }
      return (double) Time.time - (double) this._lastTimeWithinDistance <= (double) this.timeout;
    }
  }
}
