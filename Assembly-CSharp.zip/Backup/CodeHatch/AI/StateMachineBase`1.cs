﻿// Decompiled with JetBrains decompiler
// Type: CodeHatch.AI.StateMachineBase`1
// Assembly: Assembly-CSharp, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 7AE521BE-DDCA-4BB1-9869-8132CF2A08FD
// Assembly location: C:\Users\85206\Desktop\Oxide.ReignOfKings-develop\src\Dependencies\windows\ROK_Data\Managed\Assembly-CSharp.dll

using CodeHatch.Networking.Events;
using System;

#nullable disable
namespace CodeHatch.AI
{
  public abstract class StateMachineBase<T> : AIBehaviour where T : struct, IConvertible
  {
    protected T state;
    private T _previousState;
    private bool _broadcastedOnceAlready;

    public T State => this.state;

    protected void BroadcastStateChanges()
    {
      if (this._previousState.Equals((object) this.state) && this._broadcastedOnceAlready)
        return;
      EventManager.CallEvent((BaseEvent) new StateChangedEvent(this.Entity, (IConvertible) this.state));
      this._previousState = this.state;
      this._broadcastedOnceAlready = true;
    }
  }
}
