﻿// Decompiled with JetBrains decompiler
// Type: CodeHatch.AI.Targetable
// Assembly: Assembly-CSharp, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 7AE521BE-DDCA-4BB1-9869-8132CF2A08FD
// Assembly location: C:\Users\85206\Desktop\Oxide.ReignOfKings-develop\src\Dependencies\windows\ROK_Data\Managed\Assembly-CSharp.dll

using CodeHatch.Cache;
using CodeHatch.Common;
using CodeHatch.Engine.Core.Cache;
using System.Collections.Generic;
using UnityEngine;

#nullable disable
namespace CodeHatch.AI
{
  public class Targetable : Team, IEntityAware
  {
    public static readonly int targetableColorCount = 13;
    public static readonly List<Targetable>[] teams = new List<Targetable>[Team.teamColorCount];
    public static readonly List<Targetable>[] enemies = new List<Targetable>[Team.teamColorCount];
    private GetEntity _entity;
    public float priority = 1f;

    public static int GetTeamAliveOnlyCount(TeamColor teamColor)
    {
      int teamAliveOnlyCount = 0;
      List<Targetable> team = Targetable.GetTeam(teamColor);
      for (int index = 0; index < team.Count; ++index)
      {
        if (team[index].Health != null && !team[index].Health.IsDead)
          ++teamAliveOnlyCount;
      }
      return teamAliveOnlyCount;
    }

    public static Team GetHighestPriorityOpponent(TeamColor opponentTeamColor)
    {
      List<Targetable> team = Targetable.GetTeam(opponentTeamColor);
      Targetable priorityOpponent = (Targetable) null;
      for (int index = 0; index < team.Count; ++index)
      {
        Targetable targetable = team[index];
        if (!((Object) targetable == (Object) null))
        {
          if ((Object) priorityOpponent == (Object) null)
            priorityOpponent = targetable;
          else if ((double) targetable.priority > (double) priorityOpponent.priority)
            priorityOpponent = targetable;
        }
      }
      return (Team) priorityOpponent;
    }

    public static List<Targetable> GetTeam(TeamColor teamColor)
    {
      return Targetable.GetTeam((int) teamColor);
    }

    private static List<Targetable> GetTeam(int teamIndex)
    {
      return ListUtil.GetList<Targetable>(Targetable.teams, teamIndex);
    }

    public static List<Targetable> GetEnemies(TeamColor teamColor)
    {
      return Targetable.GetEnemies((int) teamColor);
    }

    private static List<Targetable> GetEnemies(int teamIndex)
    {
      return ListUtil.GetList<Targetable>(Targetable.enemies, teamIndex);
    }

    public static void AddTeamMember(Targetable team)
    {
      Targetable.GetTeam(team.TeamColor).AddDistinct<Targetable>(team);
    }

    public static void RemoveTeamMember(Targetable team)
    {
      Targetable.GetTeam(team.TeamColor).Remove(team);
    }

    public static void AddEnemyMember(Targetable team)
    {
      int teamColor = (int) team.TeamColor;
      for (int teamIndex = 0; teamIndex < Team.teamColorCount; ++teamIndex)
      {
        if (teamIndex != teamColor)
          Targetable.GetEnemies(teamIndex).AddDistinct<Targetable>(team);
      }
    }

    public static void RemoveEnemyMember(Targetable team)
    {
      int teamColor = (int) team.TeamColor;
      for (int teamIndex = 0; teamIndex < Team.teamColorCount; ++teamIndex)
      {
        if (teamIndex != teamColor)
          Targetable.GetEnemies(teamIndex).Remove(team);
      }
    }

    public new Entity Entity
    {
      get
      {
        if (this._entity == null)
          this._entity = new GetEntity((MonoBehaviour) this);
        return this._entity.Get();
      }
    }

    public IHealth Health => this.Entity.Get<IHealth>();

    public Transform MainTransform => this.Entity.MainTransform;

    public Vector3 Position => this.Entity.Position;

    protected override void AddToStaticList()
    {
      base.AddToStaticList();
      Targetable.AddTeamMember(this);
      Targetable.AddEnemyMember(this);
    }

    protected override void RemoveFromStaticList()
    {
      base.RemoveFromStaticList();
      Targetable.RemoveTeamMember(this);
      Targetable.RemoveEnemyMember(this);
    }

    public Vector3 ClosestPointOnColliders(Vector3 worldPoint, Vector3 distancePenaltyMultiplier)
    {
      return this.ClosestPointOnColliders(worldPoint, distancePenaltyMultiplier, out Collider _);
    }

    public Vector3 ClosestPointOnColliders(
      Vector3 worldPoint,
      Vector3 distancePenaltyMultiplier,
      out Collider closestCollider)
    {
      Vector3 vector3_1 = Vector3.zero;
      closestCollider = (Collider) null;
      float num = -1f;
      foreach (Collider collider in this.Entity.TryGetArray<Collider>())
      {
        if (collider.gameObject.layer != 2 && !collider.isTrigger)
        {
          Vector3 closest = collider.GetClosest(worldPoint);
          if ((double) num < 0.0)
          {
            Vector3 vector3_2 = closest - worldPoint;
            vector3_2.x *= distancePenaltyMultiplier.x;
            vector3_2.y *= distancePenaltyMultiplier.y;
            vector3_2.z *= distancePenaltyMultiplier.z;
            vector3_1 = closest;
            closestCollider = collider;
            num = vector3_2.sqrMagnitude;
          }
          else
          {
            Vector3 vector3_3 = closest - worldPoint;
            vector3_3.x *= distancePenaltyMultiplier.x;
            vector3_3.y *= distancePenaltyMultiplier.y;
            vector3_3.z *= distancePenaltyMultiplier.z;
            float sqrMagnitude = vector3_3.sqrMagnitude;
            if ((double) sqrMagnitude < (double) num)
            {
              closestCollider = collider;
              vector3_1 = closest;
              num = sqrMagnitude;
            }
          }
        }
      }
      if ((double) num < 0.0)
        vector3_1 = this.Entity.Position;
      return vector3_1;
    }

    public List<Targetable> GetTargetableTeam() => Targetable.GetTeam(this.TeamColor);

    public List<Targetable> GetTargetableEnemies() => Targetable.GetEnemies(this.TeamColor);

    public override void OnDestroy()
    {
      this.RemoveFromStaticList();
      base.OnDestroy();
    }

    public Targetable GetHighestPriorityOpponent()
    {
      List<Targetable> targetableEnemies = this.GetTargetableEnemies();
      Targetable priorityOpponent = (Targetable) null;
      for (int index = 0; index < targetableEnemies.Count; ++index)
      {
        Targetable targetable = targetableEnemies[index];
        if ((Object) priorityOpponent == (Object) null)
          priorityOpponent = targetable;
        else if ((double) targetable.priority > (double) priorityOpponent.priority)
          priorityOpponent = targetable;
      }
      return priorityOpponent;
    }
  }
}
