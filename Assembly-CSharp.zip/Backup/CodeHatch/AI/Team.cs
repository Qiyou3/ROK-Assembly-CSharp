﻿// Decompiled with JetBrains decompiler
// Type: CodeHatch.AI.Team
// Assembly: Assembly-CSharp, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 7AE521BE-DDCA-4BB1-9869-8132CF2A08FD
// Assembly location: C:\Users\85206\Desktop\Oxide.ReignOfKings-develop\src\Dependencies\windows\ROK_Data\Managed\Assembly-CSharp.dll

using CodeHatch.Common;
using CodeHatch.Engine.Core.Cache;
using System.Collections.Generic;

#nullable disable
namespace CodeHatch.AI
{
  public class Team : EntityBehaviour
  {
    public static readonly int teamColorCount = 13;
    public static readonly List<Team>[] teams = new List<Team>[Team.teamColorCount];
    public static readonly List<Team>[] enemies = new List<Team>[Team.teamColorCount];
    public TeamColor initialTeamColor;
    private TeamColor _teamColor;
    private bool _teamColorSet;

    public static List<Team> GetTeam(TeamColor teamColor) => Team.GetTeam((int) teamColor);

    private static List<Team> GetTeam(int teamIndex)
    {
      return ListUtil.GetList<Team>(Team.teams, teamIndex);
    }

    public static List<Team> GetEnemies(TeamColor teamColor) => Team.GetEnemies((int) teamColor);

    private static List<Team> GetEnemies(int teamIndex)
    {
      return ListUtil.GetList<Team>(Team.enemies, teamIndex);
    }

    public static void AddTeamMember(Team team)
    {
      Team.GetTeam(team.TeamColor).AddDistinct<Team>(team);
    }

    public static void RemoveTeamMember(Team team) => Team.GetTeam(team.TeamColor).Remove(team);

    public static void AddEnemyMember(Team team)
    {
      int teamColor = (int) team.TeamColor;
      for (int teamIndex = 0; teamIndex < Team.teamColorCount; ++teamIndex)
      {
        if (teamIndex != teamColor)
          Team.GetEnemies(teamIndex).AddDistinct<Team>(team);
      }
    }

    public static void RemoveEnemyMember(Team team)
    {
      int teamColor = (int) team.TeamColor;
      for (int teamIndex = 0; teamIndex < Team.teamColorCount; ++teamIndex)
      {
        if (teamIndex != teamColor)
          Team.GetEnemies(teamIndex).Remove(team);
      }
    }

    protected virtual void AddToStaticList()
    {
      Team.AddTeamMember(this);
      Team.AddEnemyMember(this);
    }

    protected virtual void RemoveFromStaticList()
    {
      Team.RemoveTeamMember(this);
      Team.RemoveEnemyMember(this);
    }

    public TeamColor TeamColor
    {
      get
      {
        if (!this._teamColorSet)
        {
          this._teamColor = this.initialTeamColor;
          this._teamColorSet = true;
          this.AddToStaticList();
        }
        return this._teamColor;
      }
      set
      {
        if (!this._teamColorSet)
        {
          this._teamColor = value;
          this._teamColorSet = true;
          this.AddToStaticList();
        }
        else
        {
          if (value == this._teamColor)
            return;
          this.RemoveFromStaticList();
          this._teamColor = value;
          this.AddToStaticList();
        }
      }
    }

    public void Awake() => this.TeamColor = this.initialTeamColor;

    public virtual void OnDestroy()
    {
      Team.RemoveTeamMember(this);
      Team.RemoveEnemyMember(this);
    }

    public bool IsFriendOf(Team other) => other.TeamColor == this.TeamColor;

    public List<Team> GetTeam() => Team.GetTeam(this.TeamColor);

    public List<Team> GetEnemies() => Team.GetEnemies(this.TeamColor);
  }
}
