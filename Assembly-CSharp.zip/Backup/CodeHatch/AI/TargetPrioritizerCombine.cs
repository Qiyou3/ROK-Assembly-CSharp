﻿// Decompiled with JetBrains decompiler
// Type: CodeHatch.AI.TargetPrioritizerCombine
// Assembly: Assembly-CSharp, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 7AE521BE-DDCA-4BB1-9869-8132CF2A08FD
// Assembly location: C:\Users\85206\Desktop\Oxide.ReignOfKings-develop\src\Dependencies\windows\ROK_Data\Managed\Assembly-CSharp.dll

#nullable disable
namespace CodeHatch.AI
{
  public class TargetPrioritizerCombine : TargetPrioritizerBase
  {
    public TargetPrioritizerCombineMode combine;
    public TargetPrioritizerBase[] prioritizers;

    protected override float GetPriorityForInternal(Targetable targetable)
    {
      switch (this.combine)
      {
        case TargetPrioritizerCombineMode.Add:
          float priorityForInternal1 = 0.0f;
          for (int index = 0; index < this.prioritizers.Length; ++index)
            priorityForInternal1 += this.prioritizers[index].GetPriorityFor(targetable);
          return priorityForInternal1;
        case TargetPrioritizerCombineMode.Multiply:
          float priorityForInternal2 = 1f;
          for (int index = 0; index < this.prioritizers.Length; ++index)
            priorityForInternal2 *= this.prioritizers[index].GetPriorityFor(targetable);
          return priorityForInternal2;
        default:
          this.LogError<TargetPrioritizerCombine>("Invalid combine mode: {0}", (object) this.combine);
          return 0.0f;
      }
    }
  }
}
