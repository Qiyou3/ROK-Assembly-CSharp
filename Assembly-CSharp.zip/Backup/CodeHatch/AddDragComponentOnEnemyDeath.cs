﻿// Decompiled with JetBrains decompiler
// Type: CodeHatch.AddDragComponentOnEnemyDeath
// Assembly: Assembly-CSharp, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 7AE521BE-DDCA-4BB1-9869-8132CF2A08FD
// Assembly location: C:\Users\85206\Desktop\Oxide.ReignOfKings-develop\src\Dependencies\windows\ROK_Data\Managed\Assembly-CSharp.dll

using CodeHatch.Engine.Core.Cache;
using CodeHatch.Networking.Events;
using CodeHatch.Networking.Events.Entities.Enemy;
using CodeHatch.Thrones.AI;
using UnityEngine;

#nullable disable
namespace CodeHatch
{
  public class AddDragComponentOnEnemyDeath : EntityBehaviour
  {
    public void Awake()
    {
      EventManager.Subscribe<EnemyDeathEvent>(new EventSubscriber<EnemyDeathEvent>(this.OnEnemyDeath));
    }

    public void OnDestroy()
    {
      EventManager.Unsubscribe<EnemyDeathEvent>(new EventSubscriber<EnemyDeathEvent>(this.OnEnemyDeath));
    }

    public void OnEnemyDeath(EnemyDeathEvent theEvent)
    {
      if (!((Object) theEvent.Entity == (Object) this.Entity))
        return;
      this.gameObject.AddComponent(typeof (CreatureDeathKinematic));
    }
  }
}
