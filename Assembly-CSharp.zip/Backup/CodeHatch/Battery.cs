﻿// Decompiled with JetBrains decompiler
// Type: CodeHatch.Battery
// Assembly: Assembly-CSharp, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 7AE521BE-DDCA-4BB1-9869-8132CF2A08FD
// Assembly location: C:\Users\85206\Desktop\Oxide.ReignOfKings-develop\src\Dependencies\windows\ROK_Data\Managed\Assembly-CSharp.dll

using UnityEngine;

#nullable disable
namespace CodeHatch
{
  public class Battery : MonoBehaviour
  {
    public bool powered;
    public Drivetrain drivetrain;
    public GameObject progressMeter;
    private UISlider progressBar;
    private AudioObject chargeLoop;
    private Drivable d;
    private VehicleSounds sounds;

    public void Start()
    {
      this.progressBar = this.progressMeter.GetComponentInChildren<UISlider>();
      this.d = this.drivetrain.gameObject.GetComponent<Drivable>();
      this.sounds = this.drivetrain.gameObject.GetComponent<VehicleSounds>();
    }

    public void Update()
    {
      if (this.powered && !this.drivetrain.started)
      {
        this.progressMeter.SetActive(true);
        this.drivetrain.charge += Time.deltaTime / this.drivetrain.chargeTime;
        this.progressBar.sliderValue = this.drivetrain.charge;
        if ((double) this.drivetrain.charge < 1.0)
          return;
        this.sounds.StopChargeLoop();
        this.drivetrain.started = true;
        this.drivetrain.gameObject.GetComponent<VehicleLights>().invalidate = true;
        this.sounds.PlayStartSound();
      }
      else
      {
        if (!this.drivetrain.started && this.powered)
          return;
        this.progressMeter.SetActive(false);
      }
    }

    public void OnDisable()
    {
      this.sounds.StopChargeLoop();
      this.progressMeter.SetActive(false);
    }
  }
}
