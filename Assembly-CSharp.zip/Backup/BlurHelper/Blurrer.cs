﻿// Decompiled with JetBrains decompiler
// Type: BlurHelper.Blurrer
// Assembly: Assembly-CSharp, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 7AE521BE-DDCA-4BB1-9869-8132CF2A08FD
// Assembly location: C:\Users\85206\Desktop\Oxide.ReignOfKings-develop\src\Dependencies\windows\ROK_Data\Managed\Assembly-CSharp.dll

using System;
using UnityEngine;

#nullable disable
namespace BlurHelper
{
  [Serializable]
  public class Blurrer
  {
    public int iterations = 3;
    public float scale = 0.25f;
    public float blurSpread = 0.6f;
    public Shader blurShader;
    private static Material m_Material;

    protected Material material
    {
      get
      {
        if ((UnityEngine.Object) Blurrer.m_Material == (UnityEngine.Object) null)
        {
          Blurrer.m_Material = new Material(this.blurShader);
          Blurrer.m_Material.hideFlags = HideFlags.DontSave;
        }
        return Blurrer.m_Material;
      }
    }

    public void FourTapCone(RenderTexture source, RenderTexture dest, int iteration)
    {
      float num = (float) (0.5 + (double) iteration * (double) this.blurSpread);
      Graphics.BlitMultiTap((Texture) source, dest, this.material, new Vector2(-num, -num), new Vector2(-num, num), new Vector2(num, num), new Vector2(num, -num));
    }

    private void DownSample4x(RenderTexture source, RenderTexture dest)
    {
      float num = 1f;
      Graphics.BlitMultiTap((Texture) source, dest, this.material, new Vector2(-num, -num), new Vector2(-num, num), new Vector2(num, num), new Vector2(num, -num));
    }

    public RenderTexture GetTemporaryBlurred(RenderTexture source)
    {
      RenderTexture temporary1 = RenderTexture.GetTemporary(Mathf.RoundToInt((float) source.width * this.scale), Mathf.RoundToInt((float) source.height * this.scale), 0);
      RenderTexture temporary2 = RenderTexture.GetTemporary(Mathf.RoundToInt((float) source.width * this.scale), Mathf.RoundToInt((float) source.height * this.scale), 0);
      Graphics.Blit((Texture) source, temporary1);
      bool flag = true;
      for (int iteration = 0; iteration < this.iterations; ++iteration)
      {
        if (flag)
          this.FourTapCone(temporary1, temporary2, iteration);
        else
          this.FourTapCone(temporary2, temporary1, iteration);
        flag = !flag;
      }
      if (flag)
      {
        RenderTexture.ReleaseTemporary(temporary2);
        return temporary1;
      }
      RenderTexture.ReleaseTemporary(temporary1);
      return temporary2;
    }
  }
}
